# Eclipse Growth OS — AI Business Growth & Intelligence Platform

A multi-tenant AI business growth platform built for **Base44**. Pilot business: **Eclipse Cosmetics** (a manufacturer and consumer brand operating in Canada and Jamaica).

It was built in two layers, in this order:

1. **Master Prompt 1** — the core platform (git commit 1): onboarding, maturity assessment, Business Health Score, growth stage, diagnostics, *What Should I Do Next?*, 30/60/90-day and annual plans, goals, sales/product/customer/inventory/marketing/event/finance intelligence, AI Business Advisor, weekly/monthly reviews, data import & quality, roles, tenant isolation and audit.
2. **Master Prompt 2** — the intelligence layer (commit 2), registered through extension points without rewriting the core: a central orchestration engine with 9 specialised agents, multi-agent collaboration, business memory, event-driven and scheduled monitoring, exception detection and alert lifecycle, opportunity ranking, forecasting, scenario simulation, an expansion readiness gate, AI Command Center, a strategy generator, AI workflows with human approval, AI usage and cost controls, and admin configuration.

## Layout
```
base44/               Base44 backend project
  config.jsonc        project config (site build → ./dist)
  entities/*.jsonc    47 entity schemas (generated; RLS denies direct client access)
  functions/
    api/              permission-checked data gateway (CRUD, members, imports, approvals, settings)
    intelligence/     analysis, recommendations, plans, reviews, agents, forecasts, scenarios, workflows
    monitor/          hourly scheduled monitoring (function.jsonc automation)
shared/               backend source of truth (copied into each function's _shared/ by scripts/sync-shared.mjs)
  p2/                 Master Prompt 2 layer (agents, exceptions, predict, workflows, settings, usage, register)
src/                  React frontend (Vite); src/pages/p2 = Prompt 2 screens
scripts/              entity generator + shared-code sync
tests/                43 automated backend tests (node --test)
preview/              offline browser preview harness + Playwright end-to-end walkthrough (not deployed)
docs/                 deployment, audit report, integrations, migration
```

## Commands
```
npm install
npm run dev            # local frontend (needs VITE_BASE44_APP_ID)
npm test               # 43 backend tests
npm run gen:entities   # after editing scripts/entity-spec*.mjs
npm run sync:shared    # after editing shared/  (required before deploying functions)
```
See **docs/DEPLOY_TO_BASE44.md** to get it running, and **docs/AUDIT_REPORT.md** for what was built and tested and what still needs work.
