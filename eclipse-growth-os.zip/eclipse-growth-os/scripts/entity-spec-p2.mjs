// PROMPT 2 · intelligence layer entities (enhancement layer; merged into ENTITIES by gen-entities.mjs)
import { DATA_BASIS, SOURCE } from './entity-spec.mjs';

export const ENTITIES_P2 = {
  BusinessSettings: {
    phase: 2, tenant: true, desc: 'Per-business admin configuration: agents, thresholds, approvals, monitoring, schedules, models.',
    fields: { agents_enabled: 'o', thresholds: 'o', escalation: 'o', approval_rules: 'o', workflow_modes: 'o', monitoring_frequency: ['e', 'hourly', 'every_6_hours', 'daily'], event_monitoring: 'b', report_schedule: 'o', ai_model_routine: 's', ai_model_complex: 's', ai_fallback_models: 'a', ai_monthly_request_cap: 'i', integrations_enabled: 'b', departments: 'a', data_retention_days: 'i' },
  },
  Alert: {
    phase: 2, tenant: true, desc: 'Proactive alert / exception with lifecycle and de-duplication fingerprint.',
    fields: { title: 's', exception_type: 's', severity: ['e', 'moderate', 'informational', 'low', 'high', 'critical'], business_area: 's', what_happened: 't', when_happened: 'dt', why_it_matters: 't', potential_impact: 't', recommended_action: 't', supporting_records: 'ao', metrics: 'o', status: ['e', 'open', 'acknowledged', 'assigned', 'closed'], assigned_to: 's', notes: 'ao', fingerprint: 's', occurrences: 'i', last_seen_at: 'dt', closed_at: 'dt', resolution: 't', detected_by: 's' },
    required: ['title', 'fingerprint'],
  },
  AgentRun: {
    phase: 2, tenant: true, desc: 'Trace of one orchestration: which agents ran, findings, synthesis, uncertainty.',
    fields: { question: 't', trigger: ['e', 'user_question', 'scheduled', 'event', 'collaboration', 'strategy', 'briefing'], agents: 'a', agent_findings: 'ao', synthesis: 'o', unresolved_uncertainty: 'a', data_used: 'ao', status: ['e', 'complete', 'partial', 'failed'], duration_ms: 'n', user_id: 's' },
  },
  ContextMemory: {
    phase: 2, tenant: true, desc: 'Business intelligence memory: dated facts the AI may use; admins can correct.',
    fields: { kind: ['e', 'fact', 'objective', 'procedure', 'supplier', 'customer_insight', 'decision', 'initiative', 'performance_change', 'recommendation_outcome'], content: 't', as_of_date: 'd', valid_until: 'd', source: 's', source_id: 's', status: ['e', 'current', 'historical', 'corrected', 'retracted'], corrected_by: 's' },
    required: ['content'],
  },
  ApprovalRequest: {
    phase: 2, tenant: true, desc: 'Human approval for consequential actions. AI may only create these, never execute them.',
    fields: { action_type: ['e', 'other', 'payment', 'purchase', 'transfer_funds', 'change_price', 'send_external_message', 'publish_marketing', 'delete_record', 'change_permissions', 'supplier_agreement', 'customer_agreement', 'purchase_order'], title: 's', description: 't', payload: 'o', requested_by: 's', requested_by_type: ['e', 'ai', 'user', 'workflow'], required_role: 's', status: ['e', 'pending', 'approved', 'rejected', 'executed', 'failed', 'expired'], decided_by: 's', decided_at: 'dt', execution_result: 't', failure_reason: 't', related_entity: 's', related_id: 's' },
    required: ['action_type', 'title'],
  },
  WorkflowRun: {
    phase: 2, tenant: true, desc: 'Run of an AI-prepared workflow (draft PO, follow-up reminders, reports...).',
    fields: { workflow_key: 's', mode: ['e', 'approval_required', 'automatic'], status: ['e', 'running', 'completed', 'failed', 'skipped_duplicate', 'awaiting_approval'], idempotency_key: 's', output: 'o', error: 't', approval_request_id: 'ref:ApprovalRequest', attempts: 'i', started_by: 's' },
    required: ['workflow_key'],
  },
  AIUsageLog: {
    phase: 2, tenant: true, desc: 'Per-call AI usage (request count, estimated tokens, model, latency, errors).',
    fields: { purpose: 's', agent_key: 's', model: 's', tier: ['e', 'routine', 'complex'], status: ['e', 'ok', 'error', 'fallback', 'rate_limited', 'blocked_cap'], prompt_chars: 'i', response_chars: 'i', est_tokens: 'i', est_cost_usd: 'n', latency_ms: 'n', error: 't', user_id: 's' },
  },
  Supplier: {
    phase: 2, tenant: true, desc: 'Supplier (materials, packaging, contract manufacturing).',
    fields: { name: 's', category: 's', country: 's', contact_name: 's', contact_email: 's', lead_time_days: 'n', payment_terms: 's', reliability_score: 'n', notes: 't', status: ['e', 'active', 'inactive'] }, required: ['name'],
  },
  ProductionRun: {
    phase: 2, tenant: true, desc: 'Manufacturing batch (Eclipse is a manufacturer and a brand).',
    fields: { product_id: 'ref:Product', variant_id: 'ref:ProductVariant', batch_number: 's', planned_date: 'd', completed_date: 'd', planned_qty: 'n', produced_qty: 'n', defect_qty: 'n', material_cost: 'n', labor_cost: 'n', overhead_cost: 'n', status: ['e', 'planned', 'in_progress', 'completed', 'delayed', 'cancelled'], delay_reason: 's', location_id: 'ref:BusinessLocation' },
  },
  Invoice: {
    phase: 2, tenant: true, desc: 'Receivable (wholesale/retail partner invoices) for overdue monitoring.',
    fields: { customer_id: 'ref:Customer', invoice_number: 's', issue_date: 'd', due_date: 'd', amount: 'n', amount_paid: 'n', status: ['e', 'open', 'paid', 'partial', 'overdue', 'written_off'] }, required: ['amount'],
  },
  PurchaseOrder: {
    phase: 2, tenant: true, desc: 'Purchase order. AI creates drafts only; sending requires approval.',
    fields: { supplier_id: 'ref:Supplier', po_number: 's', lines: 'ao', total: 'n', status: ['e', 'draft', 'pending_approval', 'approved', 'sent', 'received', 'cancelled'], approval_request_id: 'ref:ApprovalRequest', rationale: 't', created_by_type: ['e', 'user', 'ai'] },
  },
  LearningStat: {
    phase: 2, tenant: true, desc: 'Aggregated outcomes per recommendation rule (learning loop). Used only when n ≥ 3.',
    fields: { rule_key: 's', total: 'i', worked: 'i', partially: 'i', did_not_work: 'i', success_rate: 'n', last_updated: 'dt' }, required: ['rule_key'],
  },
};
