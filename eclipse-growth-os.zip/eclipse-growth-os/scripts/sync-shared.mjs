// Copies shared/ into every backend function folder so each Base44 function deploys self-contained.
// Run after editing anything in shared/:  node scripts/sync-shared.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const fnDir = path.join(root, 'base44', 'functions');
for (const fn of fs.readdirSync(fnDir)) {
  const dest = path.join(fnDir, fn, '_shared');
  fs.rmSync(dest, { recursive: true, force: true });
  fs.cpSync(path.join(root, 'shared'), dest, { recursive: true });
}
console.log('Synced shared/ into', fs.readdirSync(fnDir).join(', '));
