// Single source of truth for the data model.
// `node scripts/gen-entities.mjs` writes one Base44 entity file per entry into base44/entities/.
//
// Field shorthand:
//   's' string · 't' long text · 'n' number · 'i' integer · 'b' boolean
//   'd' date · 'dt' date-time · 'a' array of strings · 'o' free-form object · 'ao' array of objects
//   ['e', ...values] enum (first value = default)
//   'ref:Entity' string id referencing another entity (relationships, not duplication)
//
// Every entity with tenant: true gets a required `business_id` and is only reachable through the
// `api` backend function, which checks the caller's BusinessMember role. Direct client access is
// blocked by RLS (all false). Backend functions use asServiceRole and enforce access themselves.

export const DATA_BASIS = ['e', 'actual', 'estimated', 'forecast', 'assumption'];
export const SOURCE = ['e', 'manual', 'csv', 'excel', 'integration', 'onboarding', 'ai', 'demo'];

export const ENTITIES = {
  // ───────────────────────────── PROMPT 1 · core ─────────────────────────────
  Business: {
    phase: 1, tenant: false,
    desc: 'A company using the platform (tenant root). Access is controlled via BusinessMember.',
    fields: {
      name: 's', industry: 's', industry_module: ['e', 'general', 'cosmetics', 'beauty', 'retail', 'manufacturing', 'distribution', 'restaurant', 'professional_services', 'construction', 'transportation', 'ecommerce'],
      business_type: 's', business_model: 't', country: 's', province_state: 's', city: 's',
      year_established: 'i', employees: 'i', locations_count: 'i', products_services: 't', target_customers: 't',
      revenue_range: ['e', 'pre_revenue', 'under_100k', '100k_500k', '500k_1m', '1m_5m', '5m_20m', 'over_20m'],
      avg_monthly_revenue: 'n', gross_margin_pct: 'n', monthly_operating_expenses: 'n', cash_available: 'n', debt: 'n',
      major_recurring_expenses: 't', avg_transaction_value: 'n', est_customer_acquisition_cost: 'n', other_financials: 't',
      financials_basis: DATA_BASIS,
      goals: 'a', goal_timeframe_months: 'i', other_goal: 's', maturity_answers: 'o', operating_countries: 'a', sales_channels: 'a',
      current_stage: ['e', 'idea', 'startup', 'validation', 'early_revenue', 'early_growth', 'scaling', 'expansion', 'multi_location', 'mature', 'international_expansion'],
      stage_reason: 't', health_score: 'n', health_score_basis: ['e', 'insufficient_data', 'estimated', 'mixed', 'actual'],
      plan_key: ['e', 'trial', 'starter', 'growth', 'professional', 'enterprise'],
      owner_user_id: 's', currency: 's', onboarding_complete: 'b', is_demo: 'b', parent_business_id: 's', status: ['e', 'active', 'archived'],
    },
    required: ['name'],
  },
  BusinessMember: {
    phase: 1, tenant: true,
    desc: 'User role within one business (User Roles). One user may belong to many businesses.',
    fields: { user_id: 's', user_email: 's', role: ['e', 'read_only', 'employee', 'manager', 'marketing_manager', 'accountant', 'admin', 'owner'], status: ['e', 'active', 'invited', 'removed'], invited_by: 's', department: 's' },
    required: ['user_email', 'role'],
  },
  BusinessLocation: {
    phase: 1, tenant: true, desc: 'Physical or virtual location / market (e.g. Canada, Jamaica, Online).',
    fields: { name: 's', kind: ['e', 'retail_store', 'warehouse', 'production', 'office', 'online', 'market', 'popup'], country: 's', province_state: 's', city: 's', opened_date: 'd', status: ['e', 'active', 'planned', 'closed'], monthly_rent: 'n', notes: 't' },
    required: ['name'],
  },
  BusinessGoal: {
    phase: 1, tenant: true, desc: 'Measurable owner goal with pace tracking.',
    fields: { title: 's', category: ['e', 'revenue', 'profit', 'customers', 'repeat_customers', 'units', 'margin', 'locations', 'market', 'ecommerce', 'wholesale', 'hiring', 'operations', 'financing', 'other'], metric_key: 's', unit: 's', start_value: 'n', target_value: 'n', current_value: 'n', start_date: 'd', deadline: 'd', status: ['e', 'on_track', 'ahead', 'at_risk', 'behind', 'achieved', 'not_started', 'cancelled'], required_pace: 'n', progress_pct: 'n', owner_user_id: 's', notes: 't' },
    required: ['title', 'target_value'],
  },
  BusinessStageHistory: {
    phase: 1, tenant: true, desc: 'Each automatic stage classification (Business Stages).',
    fields: { stage: 's', previous_stage: 's', reason: 't', signals: 'o', classified_at: 'dt' }, required: ['stage'],
  },
  BusinessMetric: {
    phase: 1, tenant: true, desc: 'Point-in-time metric value (scorecard history, KPIs).',
    fields: { metric_key: 's', category: 's', value: 'n', period_start: 'd', period_end: 'd', period_type: ['e', 'day', 'week', 'month', 'quarter', 'year', 'snapshot'], data_basis: DATA_BASIS, location_id: 'ref:BusinessLocation', notes: 's' },
    required: ['metric_key', 'value'],
  },
  HealthAssessment: {
    phase: 1, tenant: true, desc: 'Business maturity assessment / health score snapshot.',
    fields: { overall_score: 'n', overall_basis: 's', categories: 'ao', data_coverage_pct: 'n', missing_information: 'a', assessed_at: 'dt', stage: 's' },
  },
  Product: {
    phase: 1, tenant: true, desc: 'Product or service.',
    fields: { name: 's', sku: 's', category: 's', product_line: 's', price: 'n', unit_cost: 'n', status: ['e', 'active', 'in_development', 'seasonal', 'discontinued'], launch_date: 'd', strategic_role: ['e', 'core', 'hero', 'acquisition', 'seasonal', 'test', 'other'], description: 't' },
    required: ['name'],
  },
  ProductVariant: {
    phase: 1, tenant: true, desc: 'Variant of a product, e.g. a foundation shade.',
    fields: { product_id: 'ref:Product', name: 's', sku: 's', shade_name: 's', shade_family: 's', undertone: 's', size: 's', price: 'n', unit_cost: 'n', status: ['e', 'active', 'discontinued', 'planned'], launch_date: 'd' },
    required: ['product_id', 'name'],
  },
  Customer: {
    phase: 1, tenant: true, desc: 'Customer (personal fields masked for roles without customer PII permission).',
    fields: { display_name: 's', email: 's', phone: 's', type: ['e', 'consumer', 'wholesale', 'retail_partner', 'distributor'], country: 's', city: 's', acquisition_channel: 's', acquisition_event_id: 'ref:Event', first_purchase_date: 'd', last_purchase_date: 'd', total_orders: 'i', total_spent: 'n', segment: 's', marketing_consent: 'b', notes: 't' },
  },
  Order: {
    phase: 1, tenant: true, desc: 'Order / transaction header.',
    fields: { order_number: 's', date: 'd', customer_id: 'ref:Customer', channel: ['e', 'retail', 'ecommerce', 'wholesale', 'event', 'popup', 'social', 'other'], location_id: 'ref:BusinessLocation', event_id: 'ref:Event', campaign_id: 'ref:MarketingCampaign', subtotal: 'n', discount: 'n', tax: 'n', total: 'n', status: ['e', 'completed', 'pending', 'refunded', 'cancelled'], source: SOURCE },
    required: ['date'],
  },
  Sale: {
    phase: 1, tenant: true, desc: 'Sales line (product/shade level). Revenue analytics are based on this.',
    fields: { date: 'd', order_id: 'ref:Order', product_id: 'ref:Product', variant_id: 'ref:ProductVariant', customer_id: 'ref:Customer', quantity: 'n', unit_price: 'n', revenue: 'n', unit_cost: 'n', channel: ['e', 'retail', 'ecommerce', 'wholesale', 'event', 'popup', 'social', 'other'], location_id: 'ref:BusinessLocation', event_id: 'ref:Event', campaign_id: 'ref:MarketingCampaign', currency: 's', source: SOURCE, import_batch_id: 'ref:ImportBatch' },
    required: ['date', 'quantity'],
  },
  InventoryItem: {
    phase: 1, tenant: true, desc: 'Stock position per product/variant/location.',
    fields: { product_id: 'ref:Product', variant_id: 'ref:ProductVariant', location_id: 'ref:BusinessLocation', on_hand: 'n', reserved: 'n', reorder_point: 'n', safety_stock: 'n', unit_cost: 'n', lead_time_days: 'n', supplier_id: 'ref:Supplier', last_counted: 'd', source: SOURCE },
    required: ['on_hand'],
  },
  MarketingChannel: {
    phase: 1, tenant: true, desc: 'Marketing channel (website, social, email, paid, influencer, events...).',
    fields: { name: 's', kind: ['e', 'website', 'social', 'email', 'paid_ads', 'influencer', 'events', 'trade_show', 'promotion', 'organic', 'other'], monthly_budget: 'n', status: ['e', 'active', 'paused'] }, required: ['name'],
  },
  MarketingCampaign: {
    phase: 1, tenant: true, desc: 'Campaign with spend and outcome (attribution only where tracked).',
    fields: { name: 's', channel_id: 'ref:MarketingChannel', start_date: 'd', end_date: 'd', spend: 'n', impressions: 'n', clicks: 'n', leads: 'n', customers_acquired: 'n', attributed_revenue: 'n', attribution_method: ['e', 'none', 'promo_code', 'utm_tracking', 'platform_reported', 'survey', 'estimate'], status: ['e', 'planned', 'active', 'completed', 'cancelled'], notes: 't' },
    required: ['name'],
  },
  Expense: {
    phase: 1, tenant: true, desc: 'Expense record.',
    fields: { date: 'd', category: ['e', 'cogs_materials', 'packaging', 'manufacturing', 'payroll', 'rent', 'marketing', 'events', 'software', 'shipping', 'professional_fees', 'utilities', 'travel', 'loan_payment', 'other'], cost_type: ['e', 'variable', 'fixed'], amount: 'n', vendor: 's', supplier_id: 'ref:Supplier', location_id: 'ref:BusinessLocation', recurring: 'b', description: 's', data_basis: DATA_BASIS, source: SOURCE },
    required: ['date', 'amount'],
  },
  FinancialMetric: {
    phase: 1, tenant: true, desc: 'Period financial summary (from statements, accounting import or manual entry).',
    fields: { period_start: 'd', period_end: 'd', period_type: ['e', 'month', 'quarter', 'year'], revenue: 'n', cogs: 'n', gross_profit: 'n', operating_expenses: 'n', net_profit: 'n', cash_balance: 'n', accounts_receivable: 'n', accounts_payable: 'n', inventory_value: 'n', payroll: 'n', marketing_spend: 'n', debt_balance: 'n', data_basis: DATA_BASIS, source: SOURCE, notes: 't' },
    required: ['period_start'],
  },
  Forecast: {
    phase: 1, tenant: true, desc: 'Stored forecast with assumptions and scenarios (never guaranteed).',
    fields: { metric: 's', target_id: 's', method: 's', horizon_periods: 'i', period_type: 's', history_points: 'i', conservative: 'ao', expected: 'ao', aggressive: 'ao', assumptions: 'a', confidence: ['e', 'low', 'moderate', 'high'], generated_at: 'dt', actuals_comparison: 'ao' },
    required: ['metric'],
  },
  Scenario: {
    phase: 1, tenant: true, desc: 'What-if scenario (estimate only).',
    fields: { name: 's', kind: 's', inputs: 'o', assumptions: 'a', results: 'o', risks: 'a', created_by_user: 's', compared_with: 'a' },
    required: ['name'],
  },
  Recommendation: {
    phase: 1, tenant: true, desc: 'AI / rules recommendation. Structure: situation → analysis → impact → recommendation → priority → action → measurement.',
    fields: {
      title: 's', category: 's', rule_key: 's', finding_level: ['e', 'opportunity', 'critical', 'high', 'monitor', 'positive'],
      situation: 't', analysis: 't', impact: 't', recommendation: 't', next_step: 't', measurement: 't', why_it_matters: 't', expected_benefit: 't', risks: 't',
      effort: ['e', 'medium', 'low', 'high'], priority: ['e', 'medium', 'critical', 'high', 'low'], priority_score: 'n', horizon: ['e', 'this_week', 'this_month', 'this_quarter', 'later'],
      suggested_deadline: 'd', dependencies: 'a', responsible_department: 's', evidence: 'ao', confidence: ['e', 'low', 'moderate', 'high'], confidence_gaps: 'a',
      status: ['e', 'proposed', 'approved', 'rejected', 'deferred', 'assigned', 'in_progress', 'done', 'superseded'], decided_by: 's', decided_at: 'dt',
      task_id: 'ref:Task', expected_result: 't', actual_result: 't', outcome: ['e', 'unknown', 'worked', 'partially', 'did_not_work'], fingerprint: 's', generated_by: 's', agent_keys: 'a',
    },
    required: ['title'],
  },
  Task: {
    phase: 1, tenant: true, desc: 'Trackable action (from plans, recommendations or manual).',
    fields: { title: 's', description: 't', plan_horizon: ['e', 'none', '30', '60', '90', '180', '365'], objective: 's', priority: ['e', 'medium', 'critical', 'high', 'low'], owner_user_id: 's', owner_name: 's', due_date: 'd', status: ['e', 'not_started', 'in_progress', 'completed', 'delayed', 'cancelled'], expected_outcome: 't', actual_outcome: 't', kpi: 's', estimated_cost: 'n', recommendation_id: 'ref:Recommendation', goal_id: 'ref:BusinessGoal', completion_notes: 't', completed_at: 'dt', quarter: 's' },
    required: ['title'],
  },
  Risk: {
    phase: 1, tenant: true, desc: 'Business risk register.',
    fields: { title: 's', category: ['e', 'cash_flow', 'inventory', 'customer_concentration', 'supplier', 'marketing_dependency', 'operational', 'staffing', 'expansion', 'financial', 'competitive', 'technology', 'regulatory', 'other'], severity: ['e', 'moderate', 'low', 'high', 'critical'], probability: ['e', 'unknown', 'low', 'medium', 'high'], impact: 't', early_warning_indicators: 'a', recommended_action: 't', evidence: 'ao', status: ['e', 'open', 'mitigating', 'closed'], detected_by: ['e', 'manual', 'rules', 'ai'], fingerprint: 's' },
    required: ['title'],
  },
  Opportunity: {
    phase: 1, tenant: true, desc: 'Growth opportunity.',
    fields: { title: 's', category: 's', description: 't', estimated_value: 'n', value_basis: DATA_BASIS, feasibility: ['e', 'medium', 'low', 'high'], urgency: ['e', 'medium', 'low', 'high'], implementation_cost: 'n', evidence: 'ao', confidence: ['e', 'low', 'moderate', 'high'], rank_score: 'n', status: ['e', 'open', 'pursuing', 'won', 'dismissed'], fingerprint: 's' },
    required: ['title'],
  },
  Competitor: {
    phase: 1, tenant: true, desc: 'Competitor; every fact carries verified/interpretation flag.',
    fields: { name: 's', website: 's', positioning: 't', price_range: 's', locations: 't', products: 't', strengths: 't', weaknesses: 't', facts: 'ao', ai_summary: 't', ai_summary_generated_at: 'dt' },
    required: ['name'],
  },
  Event: {
    phase: 1, tenant: true, desc: 'Event / trade show / exhibition / pop-up.',
    fields: { name: 's', kind: ['e', 'trade_show', 'exhibition', 'popup', 'market', 'launch', 'other'], start_date: 'd', end_date: 'd', location_text: 's', country: 's', cost: 'n', cost_breakdown: 'o', status: ['e', 'planned', 'completed', 'cancelled'], goals: 't' },
    required: ['name'],
  },
  EventResult: {
    phase: 1, tenant: true, desc: 'Measured outcome of an event plus generated performance report.',
    fields: { event_id: 'ref:Event', visitors: 'n', leads: 'n', customers: 'n', sales_revenue: 'n', units_sold: 'n', products_sold: 'ao', customer_feedback: 't', follow_up_opportunities: 't', report: 'o', report_generated_at: 'dt' },
    required: ['event_id'],
  },
  Decision: {
    phase: 1, tenant: true, desc: 'Decision Center record: expected vs actual.',
    fields: { decision: 's', date: 'd', reason: 't', expected_result: 't', assumptions: 'a', responsible_person: 's', review_date: 'd', actual_result: 't', outcome: ['e', 'pending', 'better_than_expected', 'as_expected', 'worse_than_expected'], lessons: 't', recommendation_id: 'ref:Recommendation' },
    required: ['decision'],
  },
  Document: {
    phase: 1, tenant: true, desc: 'Business Knowledge Center document. Contents are untrusted data for AI.',
    fields: { title: 's', category: ['e', 'other', 'financial_statement', 'sales_report', 'inventory_report', 'marketing_report', 'business_plan', 'supplier_document', 'product_list', 'pricing', 'strategic_plan', 'meeting_notes', 'procedure', 'manufacturing_spec', 'training'], file_uri: 's', file_name: 's', mime_type: 's', size_bytes: 'n', visibility: ['e', 'managers', 'all_members', 'owner_admin', 'finance'], extracted_summary: 't', extracted_text: 't', uploaded_by: 's' },
    required: ['title'],
  },
  Report: {
    phase: 1, tenant: true, desc: 'Generated report (markdown + structured payload). Exportable to PDF/CSV.',
    fields: { kind: ['e', 'weekly_review', 'monthly_review', 'quarterly_growth', 'financial_overview', 'marketing', 'product', 'inventory', 'expansion', 'competitor', 'risk', 'annual_plan', 'event_performance', 'briefing', 'daily', 'sales', 'manufacturing', 'strategy', 'six_month_plan', 'operations_risk', 'forecast'], title: 's', period_start: 'd', period_end: 'd', content_md: 't', payload: 'o', data_limitations: 'a', status: ['e', 'complete', 'partial', 'failed'], error: 't', generated_by: 's', generated_at: 'dt' },
    required: ['kind'],
  },
  AIConversation: {
    phase: 1, tenant: true, desc: 'AI Business Advisor conversation (per user, per business).',
    fields: { user_id: 's', title: 's', messages: 'ao', last_message_at: 'dt' },
  },
  Notification: {
    phase: 1, tenant: true, desc: 'In-app notification.',
    fields: { user_id: 's', title: 's', body: 't', level: ['e', 'info', 'warning', 'critical', 'success'], link: 's', read: 'b', related_entity: 's', related_id: 's' },
    required: ['title'],
  },
  Integration: {
    phase: 1, tenant: true, desc: 'Integration registry. Credentials are never stored here (Base44 secrets/connectors only).',
    fields: { provider: 's', category: ['e', 'ecommerce', 'accounting', 'payments', 'crm', 'advertising', 'analytics', 'erp', 'inventory', 'manufacturing', 'marketing', 'webhook', 'other'], status: ['e', 'not_configured', 'pending', 'connected', 'disconnected', 'failed'], last_tested_at: 'dt', last_test_result: 't', last_sync_at: 'dt', config_public: 'o', enabled: 'b' },
    required: ['provider'],
  },
  ImportBatch: {
    phase: 1, tenant: true, desc: 'Data import with validation review before commit.',
    fields: { target_entity: 's', file_name: 's', source: SOURCE, row_count: 'i', valid_count: 'i', issue_count: 'i', issues: 'ao', rows: 'ao', column_mapping: 'o', status: ['e', 'pending_review', 'committed', 'rejected', 'failed'], committed_count: 'i', reviewed_by: 's' },
    required: ['target_entity'],
  },
  AuditLog: {
    phase: 1, tenant: true, desc: 'Immutable audit trail (writes, permission changes, approvals, AI actions).',
    fields: { actor_user_id: 's', actor_email: 's', actor_type: ['e', 'user', 'ai', 'system'], action: 's', entity: 's', record_id: 's', summary: 't', before: 'o', after: 'o', ip: 's' },
    required: ['action'],
  },
  PlanConfig: {
    phase: 1, tenant: false, desc: 'Configurable subscription plans (pricing is data, not code).',
    fields: { key: ['e', 'trial', 'starter', 'growth', 'professional', 'enterprise'], name: 's', monthly_price: 'n', annual_price: 'n', currency: 's', max_businesses: 'i', max_users: 'i', max_ai_requests_month: 'i', features: 'a', active: 'b' },
    required: ['key', 'name'],
  },

};

// Prompt 2 adds its entities from entity-spec-p2.mjs (merged by gen-entities.mjs when present).
