// Base44 backend function: monitor — scheduled analysis, alerts and weekly reviews.
import { createClientFromRequest } from 'npm:@base44/sdk';
import { handleMonitor } from './_shared/monitor-handler.ts';
import { respond } from './_shared/http.ts';
import './_shared/register.ts';

Deno.serve((req: Request) => respond(req, async (body) => {
  const base44 = createClientFromRequest(req);
  return handleMonitor(body, { client: base44, svc: base44.asServiceRole });
}));
