// Base44 backend function: api — permission-checked data gateway (tenant isolation, RBAC, audit, imports).
import { createClientFromRequest } from 'npm:@base44/sdk';
import { handleApi } from './_shared/api-handler.ts';
import { respond } from './_shared/http.ts';
import './_shared/register.ts';

Deno.serve((req: Request) => respond(req, async (body) => {
  const base44 = createClientFromRequest(req);
  return handleApi(body, { client: base44, svc: base44.asServiceRole });
}));
