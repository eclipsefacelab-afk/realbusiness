// `monitor` backend function — scheduled (and, in Prompt 2, event-driven) monitoring.
// P1: daily analysis for every active business + basic alerts as in-app notifications,
// and the automated Weekly Business Review on Mondays.
import { analyze, persistAnalysis, syncRecommendations, weeklyReview } from './services.ts';
import { extensions } from './extensions.ts';
import { HttpError } from './context.ts';

export const monitorExt: { run?: (svc: any, args: any, now: Date) => Promise<any> } = {};

export async function handleMonitor(body: any, deps: { client: any; svc: any; now?: Date }) {
  const { client, svc } = deps;
  const now = deps.now || new Date();
  // Interactive callers must be platform admins; scheduled runs have no user session.
  let user: any = null;
  try { user = await client.auth.me(); } catch { user = null; }
  if (user && user.role !== 'admin') throw new HttpError(403, 'Monitoring runs on a schedule; it cannot be triggered by app users.');
  const args = body?.args || body || {};
  if (monitorExt.run) return monitorExt.run(svc, args, now);
  return runBasicMonitoring(svc, args, now);
}

export async function runBasicMonitoring(svc: any, args: any, now: Date) {
  const businesses = (await svc.entities.Business.filter({ status: 'active' }, '-created_date', 1000)).filter((b: any) => !args.business_id || b.id === args.business_id);
  const results: any[] = [];
  for (const b of businesses) {
    try {
      // Duplicate-run guard: skip if analysed in the last 50 minutes.
      const last = (await svc.entities.HealthAssessment.filter({ business_id: b.id }, '-assessed_at', 1))[0];
      if (last && now.getTime() - new Date(last.assessed_at).getTime() < 50 * 60000 && !args.force) { results.push({ business_id: b.id, skipped: 'recent' }); continue; }
      const a = await analyze(svc, b.id, now);
      await persistAnalysis(svc, b.id, a, now);
      const { recommendations } = await syncRecommendations(svc, b.id, a, now);
      // Basic alerts: notify owners/admins once per new critical finding.
      const members = (await svc.entities.BusinessMember.filter({ business_id: b.id, status: 'active' })).filter((m: any) => ['owner', 'admin'].includes(m.role));
      let notified = 0;
      for (const f of a.diag.findings.filter((x) => x.level === 'critical')) {
        const existing = await svc.entities.Notification.filter({ business_id: b.id, related_entity: 'finding', related_id: f.fingerprint });
        if (existing.some((n: any) => !n.read)) continue;
        for (const m of members) { await svc.entities.Notification.create({ business_id: b.id, user_id: m.user_id, title: f.title, body: `${f.situation}\n\nRecommended: ${f.recommendation}`, level: 'critical', link: '/next', related_entity: 'finding', related_id: f.fingerprint }); notified++; }
      }
      let review = null;
      if (args.mode === 'weekly' || (args.mode !== 'daily' && now.getUTCDay() === 1 && !args.skip_weekly)) {
        const prior = await svc.entities.Report.filter({ business_id: b.id, kind: 'weekly_review' }, '-generated_at', 1);
        if (!prior[0] || now.getTime() - new Date(prior[0].generated_at).getTime() > 6 * 86400000) review = (await weeklyReview(svc, b.id, a, recommendations, now, extensions.llmHooks(svc, b.id))).id;
      }
      results.push({ business_id: b.id, health: a.health.overall_score, stage: a.stage.stage, notified, weekly_review: review });
    } catch (e: any) { results.push({ business_id: b.id, error: String(e?.message || e) }); }
  }
  return { ran_at: now.toISOString(), businesses: results.length, results: results.map((r) => ({ ...r, business_id: undefined })) };
}
