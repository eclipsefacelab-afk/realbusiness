// Deterministic business metrics. Every value carries its basis so the UI and AI can distinguish
// ACTUAL (from records), ESTIMATED (owner-entered approximations / derived from partial data),
// FORECAST and ASSUMPTION. Missing data yields null — never an invented number.
export type Basis = 'actual' | 'estimated' | 'forecast' | 'assumption';
export type M = { value: number | null; basis: Basis | null; source: string; as_of?: string | null; note?: string };
export type BusinessData = {
  business: any; sales: any[]; orders: any[]; products: any[]; variants: any[]; customers: any[]; inventory: any[];
  expenses: any[]; financials: any[]; campaigns: any[]; channels: any[]; events: any[]; eventResults: any[]; goals: any[];
  tasks: any[]; locations: any[]; recommendations?: any[]; competitors?: any[]; risks?: any[]; decisions?: any[];
  // Prompt 2
  productionRuns?: any[]; invoices?: any[]; suppliers?: any[]; purchaseOrders?: any[];
};

export const DAY = 86400000;
export const iso = (d: Date) => d.toISOString().slice(0, 10);
export const toDate = (s: any) => (s ? new Date(String(s).length === 10 ? s + 'T00:00:00Z' : s) : null);
export const daysBetween = (a: Date, b: Date) => Math.round((b.getTime() - a.getTime()) / DAY);
const num = (x: any) => (x === null || x === undefined || x === '' || isNaN(Number(x)) ? null : Number(x));
export const round = (x: number | null, d = 2) => (x === null || !isFinite(x) ? null : Math.round(x * 10 ** d) / 10 ** d);
const m = (value: number | null, basis: Basis | null, source: string, extra: Partial<M> = {}): M => ({ value: value === null ? null : round(value), basis: value === null ? null : basis, source, ...extra });
const sum = (a: number[]) => a.reduce((s, x) => s + x, 0);

export function saleRevenue(s: any): number {
  const r = num(s.revenue);
  if (r !== null) return r;
  const q = num(s.quantity), p = num(s.unit_price);
  return q !== null && p !== null ? q * p : 0;
}

function inWindow(dateStr: any, start: Date, end: Date) {
  const d = toDate(dateStr);
  return !!d && d >= start && d < end;
}

export function monthlySeries(sales: any[], months: number, now: Date) {
  const out: { period: string; revenue: number; units: number }[] = [];
  for (let i = months - 1; i >= 0; i--) {
    const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
    const end = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i + 1, 1));
    const rows = sales.filter((s) => inWindow(s.date, start, end));
    out.push({ period: iso(start).slice(0, 7), revenue: round(sum(rows.map(saleRevenue)))!, units: sum(rows.map((r) => num(r.quantity) || 0)) });
  }
  return out;
}

export function weeklySeries(sales: any[], weeks: number, now: Date) {
  const out: { period: string; revenue: number; units: number }[] = [];
  for (let i = weeks - 1; i >= 0; i--) {
    const end = new Date(now.getTime() - i * 7 * DAY);
    const start = new Date(end.getTime() - 7 * DAY);
    const rows = sales.filter((s) => inWindow(s.date, start, end));
    out.push({ period: iso(start), revenue: round(sum(rows.map(saleRevenue)))!, units: sum(rows.map((r) => num(r.quantity) || 0)) });
  }
  return out;
}

export function computeSnapshot(d: BusinessData, now = new Date()) {
  const b = d.business || {};
  const t30 = new Date(now.getTime() - 30 * DAY), t60 = new Date(now.getTime() - 60 * DAY), t90 = new Date(now.getTime() - 90 * DAY);
  const sales = (d.sales || []).filter((s) => !s.status || s.status !== 'refunded');
  const s30 = sales.filter((s) => inWindow(s.date, t30, now));
  const sPrev30 = sales.filter((s) => inWindow(s.date, t60, t30));
  const s90 = sales.filter((s) => inWindow(s.date, t90, now));
  const hasSales = sales.length > 0;
  const lastSaleDate = hasSales ? sales.map((s) => s.date).filter(Boolean).sort().slice(-1)[0] : null;
  const firstSaleDate = hasSales ? sales.map((s) => s.date).filter(Boolean).sort()[0] : null;
  const historyDays = firstSaleDate ? daysBetween(toDate(firstSaleDate)!, now) : 0;

  // Revenue
  const rev30 = sum(s30.map(saleRevenue)), revPrev = sum(sPrev30.map(saleRevenue)), rev90 = sum(s90.map(saleRevenue));
  const latestFin = [...(d.financials || [])].sort((a, b2) => String(b2.period_start).localeCompare(String(a.period_start)))[0];
  let revenue30: M;
  if (hasSales && historyDays >= 1) revenue30 = m(rev30, 'actual', 'Sale records, last 30 days', { as_of: lastSaleDate });
  else if (latestFin && num(latestFin.revenue) !== null) revenue30 = m(num(latestFin.revenue)! / (latestFin.period_type === 'quarter' ? 3 : latestFin.period_type === 'year' ? 12 : 1), latestFin.data_basis === 'actual' ? 'actual' : 'estimated', `Financial summary ${latestFin.period_start}`, { as_of: latestFin.period_end || latestFin.period_start });
  else if (num(b.avg_monthly_revenue) !== null) revenue30 = m(num(b.avg_monthly_revenue), 'estimated', 'Owner estimate at onboarding');
  else revenue30 = m(null, null, 'No revenue data yet');
  const revenueChangePct = hasSales && revPrev > 0 && historyDays >= 60 ? m(((rev30 - revPrev) / revPrev) * 100, 'actual', 'Last 30 days vs previous 30 days') : m(null, null, 'Needs at least 60 days of sales records');
  const monthlyAvg90 = hasSales && historyDays >= 90 ? m(rev90 / 3, 'actual', 'Average of last 90 days') : m(null, null, 'Needs 90 days of sales records');

  // Units / orders / ATV
  const units30 = sum(s30.map((s) => num(s.quantity) || 0));
  const orderIds = new Set(s30.map((s) => s.order_id).filter(Boolean));
  const orders30 = (d.orders || []).filter((o) => inWindow(o.date, t30, now) && o.status !== 'cancelled');
  const orderCount = orders30.length || orderIds.size;
  const atv = orderCount > 0 ? m((orders30.length ? sum(orders30.map((o) => num(o.total) || 0)) : rev30) / orderCount, 'actual', 'Revenue ÷ orders, last 30 days') : num(b.avg_transaction_value) !== null ? m(num(b.avg_transaction_value), 'estimated', 'Owner estimate') : m(null, null, 'Needs order records');

  // Costs & margin
  const productCost: Record<string, number> = {}, variantCost: Record<string, number> = {};
  for (const p of d.products || []) if (num(p.unit_cost) !== null) productCost[p.id] = num(p.unit_cost)!;
  for (const v of d.variants || []) if (num(v.unit_cost) !== null) variantCost[v.id] = num(v.unit_cost)!;
  let costedRev = 0, cogs = 0, costCoverage = 0;
  for (const s of s90) {
    const uc = num(s.unit_cost) ?? variantCost[s.variant_id] ?? productCost[s.product_id];
    if (uc !== undefined && uc !== null) { cogs += uc * (num(s.quantity) || 0); costedRev += saleRevenue(s); costCoverage++; }
  }
  const costCoveragePct = s90.length ? (costCoverage / s90.length) * 100 : 0;
  let grossMargin: M;
  if (costedRev > 0 && costCoveragePct >= 50) grossMargin = m(((costedRev - cogs) / costedRev) * 100, costCoveragePct >= 90 ? 'actual' : 'estimated', `Sales × unit costs (${Math.round(costCoveragePct)}% of lines costed), 90 days`);
  else if (latestFin && num(latestFin.revenue) && num(latestFin.cogs) !== null) grossMargin = m(((num(latestFin.revenue)! - num(latestFin.cogs)!) / num(latestFin.revenue)!) * 100, latestFin.data_basis === 'actual' ? 'actual' : 'estimated', `Financial summary ${latestFin.period_start}`);
  else if (num(b.gross_margin_pct) !== null) grossMargin = m(num(b.gross_margin_pct), 'estimated', 'Owner estimate at onboarding');
  else grossMargin = m(null, null, 'Add unit costs to products/shades to calculate');

  // Operating expenses (monthly)
  const exp90 = (d.expenses || []).filter((e) => inWindow(e.date, t90, now));
  const opexRows = exp90.filter((e) => !['cogs_materials', 'packaging', 'manufacturing'].includes(e.category));
  const expHistoryDays = (d.expenses || []).length ? daysBetween(toDate([...(d.expenses || [])].map((e) => e.date).sort()[0])!, now) : 0;
  let opex: M;
  if (opexRows.length && expHistoryDays >= 60) opex = m(sum(opexRows.map((e) => num(e.amount) || 0)) / 3, 'actual', 'Expense records ÷ 3 months');
  else if (latestFin && num(latestFin.operating_expenses) !== null) opex = m(num(latestFin.operating_expenses)! / (latestFin.period_type === 'quarter' ? 3 : latestFin.period_type === 'year' ? 12 : 1), latestFin.data_basis === 'actual' ? 'actual' : 'estimated', `Financial summary ${latestFin.period_start}`);
  else if (num(b.monthly_operating_expenses) !== null) opex = m(num(b.monthly_operating_expenses), 'estimated', 'Owner estimate at onboarding');
  else opex = m(null, null, 'Add expenses or a monthly estimate');

  const netMonthly = revenue30.value !== null && grossMargin.value !== null && opex.value !== null
    ? m(revenue30.value * (grossMargin.value / 100) - opex.value, [revenue30.basis, grossMargin.basis, opex.basis].every((x) => x === 'actual') ? 'actual' : 'estimated', 'Revenue × gross margin − operating expenses')
    : m(null, null, 'Needs revenue, margin and expenses');

  // Cash & runway
  const finWithCash = [...(d.financials || [])].filter((f) => num(f.cash_balance) !== null).sort((a, b2) => String(b2.period_end || b2.period_start).localeCompare(String(a.period_end || a.period_start)))[0];
  const cash = finWithCash ? m(num(finWithCash.cash_balance), finWithCash.data_basis === 'actual' ? 'actual' : 'estimated', `Financial summary ${finWithCash.period_end || finWithCash.period_start}`, { as_of: finWithCash.period_end || finWithCash.period_start }) : num(b.cash_available) !== null ? m(num(b.cash_available), 'estimated', 'Owner estimate at onboarding', { as_of: b.updated_date?.slice?.(0, 10) || null }) : m(null, null, 'Cash position not entered');
  const runwayMonths = cash.value !== null && netMonthly.value !== null
    ? netMonthly.value >= 0 ? m(null, cash.basis, 'Cash-flow positive (no runway limit from operations)', { note: 'positive' }) : m(cash.value / -netMonthly.value, 'estimated', 'Cash ÷ monthly loss')
    : m(null, null, 'Needs cash and profit data');

  // Customers
  const custSales: Record<string, { n: number; first: string; last: string; spent: number; orders: Set<string> }> = {};
  for (const s of sales) {
    if (!s.customer_id) continue;
    const c = (custSales[s.customer_id] ||= { n: 0, first: s.date, last: s.date, spent: 0, orders: new Set() });
    c.orders.add(s.order_id || s.date); c.spent += saleRevenue(s);
    if (s.date < c.first) c.first = s.date; if (s.date > c.last) c.last = s.date;
  }
  const custIds = Object.keys(custSales);
  const custRecords = d.customers || [];
  let repeatRate: M, totalCustomers: M, newCustomers30: M;
  if (custIds.length >= 10) {
    repeatRate = m((custIds.filter((id) => custSales[id].orders.size > 1).length / custIds.length) * 100, 'actual', `Customers with 2+ orders (${custIds.length} customers linked to sales)`);
    totalCustomers = m(Math.max(custIds.length, custRecords.length), 'actual', 'Customer records');
    newCustomers30 = m(custIds.filter((id) => inWindow(custSales[id].first, t30, now)).length, 'actual', 'First purchase in last 30 days');
  } else if (custRecords.length >= 10) {
    const withOrders = custRecords.filter((c) => num(c.total_orders) !== null);
    repeatRate = withOrders.length >= 10 ? m((withOrders.filter((c) => num(c.total_orders)! > 1).length / withOrders.length) * 100, 'estimated', 'Customer order counts (not linked to sale lines)') : m(null, null, 'Link sales to customers to measure repeat purchases');
    totalCustomers = m(custRecords.length, 'actual', 'Customer records');
    newCustomers30 = m(custRecords.filter((c) => inWindow(c.first_purchase_date || c.created_date, t30, now)).length, 'estimated', 'Customer first-purchase dates');
  } else {
    repeatRate = m(null, null, 'Fewer than 10 identified customers');
    totalCustomers = custRecords.length ? m(custRecords.length, 'actual', 'Customer records') : m(null, null, 'No customer records');
    newCustomers30 = m(null, null, 'Not enough customer data');
  }
  // Customer concentration (top customer share of 90d revenue)
  const custRev90: Record<string, number> = {};
  for (const s of s90) if (s.customer_id) custRev90[s.customer_id] = (custRev90[s.customer_id] || 0) + saleRevenue(s);
  const topCust = Object.entries(custRev90).sort((a, b2) => b2[1] - a[1])[0];
  const concentration = topCust && rev90 > 0 && Object.keys(custRev90).length >= 3 ? m((topCust[1] / rev90) * 100, 'actual', 'Largest customer share of 90-day revenue', { note: topCust[0] }) : m(null, null, 'Not enough customer-linked sales');

  // Marketing / CAC
  const camp90 = (d.campaigns || []).filter((c) => inWindow(c.start_date || c.created_date, t90, now));
  const spend90 = sum(camp90.map((c) => num(c.spend) || 0)) + sum(exp90.filter((e) => e.category === 'marketing').map((e) => num(e.amount) || 0));
  const newCust90 = custIds.filter((id) => inWindow(custSales[id].first, t90, now)).length;
  const cac = spend90 > 0 && newCust90 >= 5 ? m(spend90 / newCust90, 'estimated', 'Marketing spend ÷ new customers, 90 days (all-channel blended; not attribution)') : num(b.est_customer_acquisition_cost) !== null ? m(num(b.est_customer_acquisition_cost), 'estimated', 'Owner estimate') : m(null, null, 'Needs marketing spend and customer data');
  const campaigns = (d.campaigns || []).map((c) => {
    const reliable = c.attribution_method && !['none', 'estimate'].includes(c.attribution_method);
    const spend = num(c.spend) || 0;
    return {
      id: c.id, name: c.name, spend, customers: num(c.customers_acquired), revenue: num(c.attributed_revenue), attribution: c.attribution_method || 'none',
      cpa: reliable && spend > 0 && num(c.customers_acquired) ? round(spend / num(c.customers_acquired)!) : null,
      roas: reliable && spend > 0 && num(c.attributed_revenue) !== null ? round(num(c.attributed_revenue)! / spend) : null,
      reliable,
    };
  });

  // Product & variant performance
  const byKey = (rows: any[], key: string) => {
    const o: Record<string, { units: number; revenue: number; cost: number; costed: boolean }> = {};
    for (const s of rows) {
      const k = s[key]; if (!k) continue;
      const e = (o[k] ||= { units: 0, revenue: 0, cost: 0, costed: true });
      const q = num(s.quantity) || 0; e.units += q; e.revenue += saleRevenue(s);
      const uc = num(s.unit_cost) ?? variantCost[s.variant_id] ?? productCost[s.product_id];
      if (uc === undefined || uc === null) e.costed = false; else e.cost += uc * q;
    }
    return o;
  };
  const perf = (key: 'product_id' | 'variant_id', list: any[]) => {
    const cur = byKey(s30, key), prev = byKey(sPrev30, key), q90 = byKey(s90, key);
    const totalRev90 = sum(Object.values(q90).map((x) => x.revenue)) || 0;
    const rows = list.map((p) => {
      const c = cur[p.id] || { units: 0, revenue: 0, cost: 0, costed: false }, pr = prev[p.id] || { units: 0, revenue: 0, cost: 0, costed: false }, n = q90[p.id] || { units: 0, revenue: 0, cost: 0, costed: false };
      const growth = pr.units >= 5 && historyDays >= 60 ? ((c.units - pr.units) / pr.units) * 100 : null;
      const margin = n.revenue > 0 && n.costed ? ((n.revenue - n.cost) / n.revenue) * 100 : null;
      return {
        id: p.id, name: key === 'variant_id' ? `${(d.products || []).find((x) => x.id === p.product_id)?.name || ''} — ${p.shade_name || p.name}` : p.name,
        product_id: p.product_id || p.id, status: p.status, strategic_role: p.strategic_role,
        units_30d: c.units, units_prev_30d: pr.units, revenue_30d: round(c.revenue), revenue_90d: round(n.revenue), share_90d_pct: totalRev90 ? round((n.revenue / totalRev90) * 100, 1) : 0,
        velocity_per_day: round(n.units / Math.min(90, Math.max(historyDays, 1)), 3), growth_pct: round(growth, 1), margin_pct: round(margin, 1),
      };
    });
    rows.sort((a, b2) => (b2.revenue_90d || 0) - (a.revenue_90d || 0));
    const n = rows.filter((r) => (r.revenue_90d || 0) > 0).length;
    const topCut = Math.max(1, Math.ceil(n * 0.2));
    return rows.map((r, i) => ({
      ...r,
      tags: [
        i < topCut && (r.revenue_90d || 0) > 0 ? 'best_seller' : null,
        r.growth_pct !== null && r.growth_pct >= 30 ? 'fast_growing' : null,
        r.growth_pct !== null && r.growth_pct <= -25 ? 'declining' : null,
        historyDays >= 60 && (r.units_30d || 0) === 0 && r.status !== 'discontinued' && r.status !== 'in_development' ? 'no_recent_sales' : null,
        n >= 5 && i >= n - Math.ceil(n * 0.2) && (r.revenue_90d || 0) > 0 ? 'slow_seller' : null,
        r.margin_pct !== null && r.margin_pct < 30 ? 'low_margin' : null,
      ].filter(Boolean) as string[],
    }));
  };
  const products = perf('product_id', d.products || []);
  const variants = perf('variant_id', d.variants || []);
  const top3Share = variants.length >= 5 ? m(sum(variants.slice(0, 3).map((v) => v.share_90d_pct || 0)), 'actual', 'Top 3 shades share of 90-day revenue') : m(null, null, 'Needs shade-level sales');

  // Inventory
  const velocityFor = (it: any) => {
    const key = it.variant_id ? 'variant_id' : 'product_id';
    const idv = it.variant_id || it.product_id;
    const rows = s30.filter((s) => s[key] === idv && (!it.location_id || !s.location_id || s.location_id === it.location_id));
    return sum(rows.map((s) => num(s.quantity) || 0)) / Math.min(30, Math.max(historyDays, 1));
  };
  const nameFor = (it: any) => {
    const v = (d.variants || []).find((x) => x.id === it.variant_id), p = (d.products || []).find((x) => x.id === (it.product_id || v?.product_id));
    return [p?.name, v ? v.shade_name || v.name : null].filter(Boolean).join(' — ') || 'Unnamed item';
  };
  const bestSellerIds = new Set([...products, ...variants].filter((x) => x.tags.includes('best_seller')).map((x) => x.id));
  const inventory = (d.inventory || []).map((it) => {
    const onHand = (num(it.on_hand) || 0) - (num(it.reserved) || 0);
    const vel = hasSales ? velocityFor(it) : null;
    const days = vel && vel > 0 ? onHand / vel : null;
    const lead = num(it.lead_time_days);
    const reorder = num(it.reorder_point);
    const flags: string[] = [];
    if (onHand <= 0) flags.push('out_of_stock');
    else if (reorder !== null && onHand <= reorder) flags.push('low_stock');
    if (days !== null && lead !== null && days <= lead + 7) flags.push('stockout_risk');
    if (days !== null && days > 180) flags.push('overstock');
    if (hasSales && historyDays >= 60 && vel === 0 && onHand > 0) flags.push('slow_moving');
    if (vel !== null && vel > 0 && days !== null && days < 30) flags.push('fast_moving');
    return {
      id: it.id, name: nameFor(it), product_id: it.product_id, variant_id: it.variant_id, location_id: it.location_id, on_hand: onHand,
      velocity_per_day: round(vel, 3), days_of_cover: round(days, 0), lead_time_days: lead, reorder_point: reorder,
      capital: round(onHand * (num(it.unit_cost) ?? variantCost[it.variant_id] ?? productCost[it.product_id] ?? 0)),
      cost_known: (num(it.unit_cost) ?? variantCost[it.variant_id] ?? productCost[it.product_id]) !== undefined,
      is_best_seller: bestSellerIds.has(it.variant_id) || bestSellerIds.has(it.product_id), flags,
      forecast_note: days !== null ? `Forecast: at the current 30-day sales rate this item may run out in about ${Math.round(days)} days.` : null,
    };
  });
  const inventoryCapital = inventory.length ? m(sum(inventory.map((i) => i.capital || 0)), inventory.every((i) => i.cost_known) ? 'actual' : 'estimated', 'On-hand × unit cost') : m(null, null, 'No inventory records');

  // Channels & locations
  const groupRev = (rows: any[], key: string) => {
    const o: Record<string, number> = {};
    for (const s of rows) o[s[key] || 'unspecified'] = (o[s[key] || 'unspecified'] || 0) + saleRevenue(s);
    return Object.entries(o).map(([k, v]) => ({ key: k, revenue: round(v), share_pct: rev90 ? round((v / rev90) * 100, 1) : 0 })).sort((a, b2) => (b2.revenue || 0) - (a.revenue || 0));
  };
  const channels = groupRev(s90, 'channel');
  const locations = groupRev(s90, 'location_id').map((l) => ({ ...l, name: (d.locations || []).find((x) => x.id === l.key)?.name || (l.key === 'unspecified' ? 'Unspecified' : l.key) }));

  // Events
  const events = (d.events || []).map((e) => {
    const r = (d.eventResults || []).find((x) => x.event_id === e.id);
    const evSales = sales.filter((s) => s.event_id === e.id);
    const revenue = r && num(r.sales_revenue) !== null ? num(r.sales_revenue)! : evSales.length ? sum(evSales.map(saleRevenue)) : null;
    const cost = num(e.cost);
    return {
      id: e.id, name: e.name, date: e.start_date, status: e.status, cost, revenue: round(revenue), leads: r ? num(r.leads) : null, customers: r ? num(r.customers) : null, visitors: r ? num(r.visitors) : null,
      gross_return: revenue !== null && cost ? round(revenue - cost) : null, revenue_basis: r && num(r.sales_revenue) !== null ? 'actual' : evSales.length ? 'actual' : null,
      conversion_pct: r && num(r.leads) && num(r.customers) !== null ? round((num(r.customers)! / num(r.leads)!) * 100, 1) : null, has_result: !!r,
      followups_open: (d.tasks || []).filter((t) => (t.title || '').toLowerCase().includes((e.name || '').toLowerCase()) && !['completed', 'cancelled'].includes(t.status)).length,
    };
  });

  // Data coverage
  const coverage = {
    sales: hasSales, sales_recent: !!lastSaleDate && daysBetween(toDate(lastSaleDate)!, now) <= 14, sales_history_days: historyDays,
    costs: costCoveragePct >= 50, customers: custIds.length >= 10 || custRecords.length >= 10, inventory: (d.inventory || []).length > 0,
    expenses: (d.expenses || []).length > 0, financials: (d.financials || []).length > 0, cash: cash.value !== null,
    marketing: (d.campaigns || []).length > 0, events: (d.events || []).length > 0, products: (d.products || []).length > 0,
  };

  return {
    generated_at: now.toISOString(), last_sale_date: lastSaleDate, history_days: historyDays,
    revenue_30d: revenue30, revenue_change_pct: revenueChangePct, revenue_monthly_avg_90d: monthlyAvg90, units_30d: m(hasSales ? units30 : null, 'actual', 'Sale records'),
    orders_30d: m(orderCount || (hasSales ? 0 : null), 'actual', 'Orders'), avg_transaction_value: atv,
    gross_margin_pct: grossMargin, opex_monthly: opex, net_profit_monthly: netMonthly, cash, runway_months: runwayMonths,
    customers_total: totalCustomers, new_customers_30d: newCustomers30, repeat_rate_pct: repeatRate, top_customer_share_pct: concentration,
    cac, marketing_spend_90d: m(spend90 || (d.campaigns || []).length ? spend90 : null, 'actual', 'Campaign spend + marketing expenses, 90 days'), campaigns,
    products, variants, top3_shade_share_pct: top3Share, inventory, inventory_capital: inventoryCapital, channels, locations, events,
    monthly: hasSales ? monthlySeries(sales, 12, now) : [], weekly: hasSales ? weeklySeries(sales, 12, now) : [], coverage,
  };
}
export type Snapshot = ReturnType<typeof computeSnapshot>;
