// AI Business Diagnostic Engine — deterministic rule layer.
// Each finding follows the platform's core structure:
// Situation → Analysis → Impact → Recommendation → Priority → Action → Measurement.
// The LLM layer may rephrase/expand these but never supplies the numbers.
import type { Snapshot } from './metrics.ts';
import { industryFor } from './industries.ts';
import { evaluateGoal } from './goals.ts';
import { toDate, DAY } from './metrics.ts';

export type Level = 'critical' | 'high' | 'opportunity' | 'monitor' | 'positive';
export type Evidence = { label: string; value: string | number | null; basis: string; entity?: string; ids?: string[] };
export type Finding = {
  rule_key: string; fingerprint: string; level: Level; category: string; title: string;
  situation: string; analysis: string; impact: string; recommendation: string; next_step: string; measurement: string;
  why_it_matters: string; expected_benefit: string; risks: string; effort: 'low' | 'medium' | 'high';
  impact_score: number; urgency: number; risk_score: number; opportunity_score: number; strategic: number;
  responsible_department: string; dependencies: string[]; evidence: Evidence[]; confidence: 'low' | 'moderate' | 'high'; confidence_gaps: string[];
  goal_categories?: string[];
};
export type MissingInfo = { area: string; what: string; why: string };

const f1 = (n: number | null | undefined) => (n === null || n === undefined ? 'n/a' : (Math.round(n * 10) / 10).toLocaleString());
const money = (n: number | null | undefined, cur = '') => (n === null || n === undefined ? 'n/a' : `${cur}${Math.round(n).toLocaleString()}`);

function conf(evs: Evidence[], minSample = true): 'low' | 'moderate' | 'high' {
  const allActual = evs.every((e) => e.basis === 'actual');
  if (allActual && minSample) return 'high';
  if (evs.some((e) => e.basis === 'actual')) return 'moderate';
  return 'low';
}

export function diagnose(s: Snapshot, d: { business: any; goals: any[]; tasks: any[]; events: any[]; eventResults: any[]; risks?: any[] }, now = new Date()) {
  const b = d.business || {};
  const ind = industryFor(b.industry_module);
  const cur = b.currency ? `${b.currency} ` : '$';
  const F: Finding[] = [];
  const missing: MissingInfo[] = [];
  const base = { dependencies: [] as string[], confidence_gaps: [] as string[], strategic: 0.5 };
  const push = (x: Omit<Finding, 'confidence' | 'dependencies' | 'confidence_gaps' | 'strategic'> & Partial<Finding>) => F.push({ ...base, confidence: conf(x.evidence), ...x } as Finding);

  // ── Sales trend
  const g = s.revenue_change_pct.value;
  if (g !== null) {
    const ev: Evidence[] = [{ label: 'Revenue last 30 days', value: s.revenue_30d.value, basis: 'actual', entity: 'Sale' }, { label: 'Change vs prior 30 days', value: `${f1(g)}%`, basis: 'actual' }];
    if (g <= -15) push({
      rule_key: 'sales_decline', fingerprint: 'sales_decline', level: g <= -30 ? 'critical' : 'high', category: 'sales', title: `Sales are down ${f1(-g)}% versus the previous 30 days`,
      situation: `Revenue in the last 30 days was ${money(s.revenue_30d.value, cur)}, ${f1(-g)}% lower than the 30 days before.`,
      analysis: 'Look at which products, channels and locations account for the drop. The breakdown below shows where revenue changed most; seasonality cannot be ruled out without last year\'s data.',
      impact: 'If the decline continues, cash and production plans built on earlier sales levels will be too optimistic.',
      recommendation: 'Identify the 2–3 products or channels with the largest drop and act on those first (restock, promote, or follow up with lapsed customers).',
      next_step: 'Open Sales → compare this month vs last month by product and channel.', measurement: '30-day revenue back to within 5% of the prior period.',
      why_it_matters: 'Revenue is the source of cash for everything else.', expected_benefit: 'Stops a decline before it affects cash.', risks: 'Cause may be seasonal; avoid over-discounting.',
      effort: 'medium', impact_score: g <= -30 ? 0.95 : 0.8, urgency: 0.9, risk_score: 0.8, opportunity_score: 0.2, responsible_department: 'Sales', evidence: ev, goal_categories: ['revenue'],
      confidence_gaps: s.history_days < 365 ? ['Same period last year (to rule out seasonality)'] : [],
    });
    else if (g >= 15) push({
      rule_key: 'sales_growth', fingerprint: 'sales_growth', level: 'positive', category: 'sales', title: `Sales grew ${f1(g)}% versus the previous 30 days`,
      situation: `Revenue reached ${money(s.revenue_30d.value, cur)} in the last 30 days.`, analysis: 'Growth is visible in sales records. Check whether stock and production can keep up.',
      impact: 'Sustained growth may require more inventory and cash for production.', recommendation: 'Confirm stock cover on best sellers and keep doing what drove the increase.',
      next_step: 'Review Inventory for best sellers with less than 30 days of cover.', measurement: 'Growth maintained without stock-outs.',
      why_it_matters: 'Knowing what works lets you repeat it.', expected_benefit: 'Protects momentum.', risks: 'Stock-outs during growth lose customers.',
      effort: 'low', impact_score: 0.4, urgency: 0.3, risk_score: 0.2, opportunity_score: 0.6, responsible_department: 'Sales', evidence: ev, goal_categories: ['revenue'],
    });
  } else missing.push({ area: 'Sales', what: '60+ days of dated sales records', why: 'Needed to measure whether sales are rising or falling.' });

  // ── Cash runway
  if (s.runway_months.value !== null) {
    const rm = s.runway_months.value;
    if (rm < 6) push({
      rule_key: 'cash_runway', fingerprint: 'cash_runway', level: rm < 3 ? 'critical' : 'high', category: 'finance', title: `Cash may last only about ${f1(rm)} months at the current loss rate`,
      situation: `Cash is ${money(s.cash.value, cur)} (${s.cash.basis}) and the business is estimated to lose ${money(-(s.net_profit_monthly.value || 0), cur)} per month.`,
      analysis: `Runway = cash ÷ monthly loss. Inputs: revenue (${s.revenue_30d.basis}), margin (${s.gross_margin_pct.basis}), expenses (${s.opex_monthly.basis}).`,
      impact: 'Running out of cash stops production and growth regardless of demand.', recommendation: 'Reduce non-essential spending, collect receivables, and avoid new fixed commitments until runway exceeds 6 months. Consider speaking with an accountant or lender about options.',
      next_step: 'List all monthly expenses in Finance and mark which are essential.', measurement: 'Runway above 6 months.',
      why_it_matters: 'Cash, not profit, determines how long the business can operate.', expected_benefit: 'Avoids a cash crisis.', risks: 'Cutting marketing too deeply can reduce sales.',
      effort: 'medium', impact_score: 1, urgency: rm < 3 ? 1 : 0.8, risk_score: 1, opportunity_score: 0, responsible_department: 'Finance', strategic: 1,
      evidence: [{ label: 'Cash', value: s.cash.value, basis: s.cash.basis || 'estimated' }, { label: 'Monthly profit/loss', value: s.net_profit_monthly.value, basis: s.net_profit_monthly.basis || 'estimated' }, { label: 'Runway (months)', value: f1(rm), basis: 'estimated' }],
      confidence_gaps: s.cash.basis !== 'actual' ? ['Actual cash balance from bank or accounting'] : [],
    });
  } else if (s.cash.value === null) missing.push({ area: 'Finance', what: 'Current cash balance', why: 'Needed to know whether the business can afford growth plans.' });

  if (s.net_profit_monthly.value !== null && s.net_profit_monthly.value < 0 && !F.some((x) => x.rule_key === 'cash_runway')) push({
    rule_key: 'net_loss', fingerprint: 'net_loss', level: 'high', category: 'finance', title: 'The business is estimated to be losing money each month',
    situation: `Estimated monthly result: ${money(s.net_profit_monthly.value, cur)} (${s.net_profit_monthly.basis}).`, analysis: 'Revenue × gross margin does not cover operating expenses.',
    impact: 'Ongoing losses consume cash.', recommendation: 'Work on the biggest lever first: price/margin on top sellers, or the largest expense category.', next_step: 'Review Finance → expense breakdown.',
    measurement: 'Monthly result at or above break-even.', why_it_matters: 'Growth that loses money makes the problem bigger.', expected_benefit: 'Path to profitability.', risks: 'Estimates may be inaccurate if expenses are incomplete.',
    effort: 'medium', impact_score: 0.85, urgency: 0.7, risk_score: 0.8, opportunity_score: 0.2, responsible_department: 'Finance', evidence: [{ label: 'Monthly profit/loss', value: s.net_profit_monthly.value, basis: s.net_profit_monthly.basis || 'estimated' }], goal_categories: ['profit'],
  });

  // ── Margin
  if (s.gross_margin_pct.value !== null && s.gross_margin_pct.value < ind.assumptions.gross_margin_floor_pct) push({
    rule_key: 'low_margin', fingerprint: 'low_margin', level: 'high', category: 'finance', title: `Gross margin (${f1(s.gross_margin_pct.value)}%) is below the planning floor`,
    situation: `Gross margin is ${f1(s.gross_margin_pct.value)}% (${s.gross_margin_pct.basis}; ${s.gross_margin_pct.source}).`,
    analysis: `The platform uses ${ind.assumptions.gross_margin_floor_pct}% as a planning floor for ${ind.label}. This is a platform assumption, not market research.`,
    impact: 'Low margin limits how much you can spend on marketing and growth.', recommendation: 'Review pricing and unit costs of the highest-volume items; check packaging and material costs with suppliers.',
    next_step: 'Open Products and sort by margin.', measurement: 'Gross margin above the floor for two consecutive months.', why_it_matters: 'Margin funds every other activity.',
    expected_benefit: 'Each point of margin adds directly to profit.', risks: 'Price rises can reduce volume.', effort: 'medium', impact_score: 0.75, urgency: 0.5, risk_score: 0.6, opportunity_score: 0.5, responsible_department: 'Finance',
    evidence: [{ label: 'Gross margin', value: `${f1(s.gross_margin_pct.value)}%`, basis: s.gross_margin_pct.basis || 'estimated' }, { label: 'Planning floor', value: `${ind.assumptions.gross_margin_floor_pct}%`, basis: 'assumption' }], goal_categories: ['margin', 'profit'],
  });
  if (s.gross_margin_pct.value === null) missing.push({ area: 'Products', what: 'Unit cost for each product/shade', why: 'Needed for margin and product profitability.' });

  // ── Inventory
  for (const it of s.inventory) {
    const out = it.flags.includes('out_of_stock'), risk = it.flags.includes('stockout_risk');
    if (out || risk) push({
      rule_key: 'stockout_risk', fingerprint: `stockout:${it.id}`, level: it.is_best_seller ? 'critical' : 'high', category: 'inventory',
      title: out ? `${it.name} is out of stock` : `${it.name} may run out in about ${it.days_of_cover} days (forecast)`,
      situation: out ? `${it.name} has no available stock.` : `${it.on_hand} units on hand, selling about ${it.velocity_per_day}/day.`,
      analysis: `Forecast based on the last 30 days of sales. Lead time: ${it.lead_time_days ?? 'unknown'} days.${it.is_best_seller ? ' This is a best seller.' : ''}`,
      impact: 'Stock-outs lose sales and can send customers to competitors.', recommendation: 'Schedule production or reorder now.',
      next_step: `Plan a production run / reorder for ${it.name}.`, measurement: 'Days of cover above lead time + 14 days.', why_it_matters: 'Lost sales cannot be recovered later.',
      expected_benefit: `Protects about ${money((it.velocity_per_day || 0) * 30, '')} units of monthly demand (forecast).`, risks: 'Over-ordering ties up cash.',
      effort: 'low', impact_score: it.is_best_seller ? 0.9 : 0.6, urgency: out ? 1 : 0.85, risk_score: 0.7, opportunity_score: 0.3, responsible_department: 'Production',
      evidence: [{ label: 'On hand', value: it.on_hand, basis: 'actual', entity: 'InventoryItem', ids: [it.id] }, { label: 'Daily sales rate (30d)', value: it.velocity_per_day, basis: 'actual' }, { label: 'Days of cover', value: it.days_of_cover, basis: 'forecast' }],
      confidence_gaps: it.lead_time_days === null ? ['Supplier / production lead time'] : [],
    });
  }
  const over = s.inventory.filter((i) => i.flags.includes('overstock') || i.flags.includes('slow_moving'));
  const overCap = over.reduce((a, i) => a + (i.capital || 0), 0);
  if (over.length && overCap > 0) push({
    rule_key: 'excess_inventory', fingerprint: 'excess_inventory', level: overCap > (s.revenue_30d.value || 0) * 0.25 ? 'opportunity' : 'monitor', category: 'inventory',
    title: `${money(overCap, cur)} is tied up in slow-moving or excess stock`, situation: `${over.length} item(s) have more than 180 days of cover or no sales in 60 days.`,
    analysis: 'Cash in excess inventory cannot be used for growth.', impact: 'Frees cash if sold through.', recommendation: 'Bundle slow items with best sellers, run a targeted promotion, or pause production of these items. Do not discontinue without checking margin and strategic role.',
    next_step: 'Review the slow-moving list in Inventory.', measurement: 'Excess stock value reduced by 30% in 60 days.', why_it_matters: 'Cash flow.', expected_benefit: `Up to ${money(overCap, cur)} of stock value could be converted to cash (estimate, at cost).`,
    risks: 'Heavy discounting can affect brand perception.', effort: 'low', impact_score: 0.5, urgency: 0.3, risk_score: 0.3, opportunity_score: 0.6, responsible_department: 'Sales',
    evidence: [{ label: 'Items', value: over.length, basis: 'actual', entity: 'InventoryItem', ids: over.map((i) => i.id) }, { label: 'Capital at cost', value: overCap, basis: 'actual' }],
  });
  if (!s.inventory.length && s.coverage.products) missing.push({ area: 'Inventory', what: 'Stock counts for products/shades', why: 'Needed for stock-out and overstock alerts.' });

  // ── Products
  const items = s.variants.length ? s.variants : s.products;
  for (const p of items.filter((x) => x.tags.includes('fast_growing')).slice(0, 3)) push({
    rule_key: 'fast_growing_product', fingerprint: `fast:${p.id}`, level: 'opportunity', category: 'product', title: `${p.name} is growing fast (+${f1(p.growth_pct)}%)`,
    situation: `${p.units_30d} units in the last 30 days vs ${p.units_prev_30d} the month before.`, analysis: 'Demand is rising. Check stock cover and whether marketing or an event caused it.',
    impact: 'Opportunity to grow sales if supply keeps up.', recommendation: 'Increase production of this item and feature it in marketing.', next_step: 'Check inventory cover and plan production.',
    measurement: 'Units sold next 30 days ≥ this period without stock-outs.', why_it_matters: 'Growing items are the cheapest growth to capture.', expected_benefit: 'Additional unit sales (not guaranteed).', risks: 'Spike may be temporary.',
    effort: 'low', impact_score: 0.6, urgency: 0.5, risk_score: 0.2, opportunity_score: 0.85, responsible_department: 'Production', evidence: [{ label: 'Units 30d / prior 30d', value: `${p.units_30d} / ${p.units_prev_30d}`, basis: 'actual', entity: 'Sale' }], goal_categories: ['revenue', 'units'],
  });
  for (const p of items.filter((x) => x.tags.includes('declining')).slice(0, 3)) push({
    rule_key: 'declining_product', fingerprint: `declining:${p.id}`, level: 'monitor', category: 'product', title: `${p.name} sales are declining (${f1(p.growth_pct)}%)`,
    situation: `${p.units_30d} units in the last 30 days vs ${p.units_prev_30d} before.`, analysis: `Margin: ${p.margin_pct ?? 'unknown'}%. Strategic role: ${p.strategic_role || 'not set'}. A decline alone is not a reason to discontinue.`,
    impact: 'May indicate changing preferences, stock issues or seasonality.', recommendation: 'Check stock availability and seasonality first; then consider a promotion or bundle. Only consider discontinuing if margin is low AND it has no strategic role.',
    next_step: 'Review this item in Products.', measurement: 'Decline stops within 60 days.', why_it_matters: 'Early action avoids excess stock.', expected_benefit: 'Avoids future overstock.', risks: 'Removing it may lose loyal customers.',
    effort: 'low', impact_score: 0.35, urgency: 0.3, risk_score: 0.3, opportunity_score: 0.2, responsible_department: 'Product', evidence: [{ label: 'Units 30d / prior 30d', value: `${p.units_30d} / ${p.units_prev_30d}`, basis: 'actual' }],
  });
  if (s.top3_shade_share_pct.value !== null && s.top3_shade_share_pct.value >= 60) push({
    rule_key: 'shade_concentration', fingerprint: 'shade_concentration', level: 'monitor', category: 'product', title: `Top 3 shades make up ${f1(s.top3_shade_share_pct.value)}% of revenue`,
    situation: 'Sales are concentrated in a few shades.', analysis: 'Production can focus on these, but supply issues on any of them would hurt sales.', impact: 'Dependency risk and production-planning opportunity.',
    recommendation: 'Keep extra safety stock on the top 3 shades and test promoting the next best shades.', next_step: 'Set reorder points for the top 3 shades.', measurement: 'No stock-outs on top shades.',
    why_it_matters: 'Concentration magnifies supply risk.', expected_benefit: 'Steadier revenue.', risks: 'Extra stock uses cash.', effort: 'low', impact_score: 0.4, urgency: 0.3, risk_score: 0.5, opportunity_score: 0.4, responsible_department: 'Production',
    evidence: [{ label: 'Top 3 share', value: `${f1(s.top3_shade_share_pct.value)}%`, basis: 'actual' }],
  });

  // ── Customers
  if (s.repeat_rate_pct.value !== null && s.repeat_rate_pct.value < ind.assumptions.repeat_rate_target_pct) push({
    rule_key: 'low_repeat', fingerprint: 'low_repeat', level: 'opportunity', category: 'customers', title: `Only ${f1(s.repeat_rate_pct.value)}% of customers have bought more than once`,
    situation: `Repeat rate ${f1(s.repeat_rate_pct.value)}% (${s.repeat_rate_pct.basis}).`, analysis: `Planning target for ${ind.label}: ${ind.assumptions.repeat_rate_target_pct}% (platform assumption).`,
    impact: 'Repeat customers cost less to win than new ones.', recommendation: 'Start a simple follow-up: thank-you message, replenishment reminder, or loyalty offer for second purchase (only to customers who consented to marketing).',
    next_step: 'Create a 30-day "second purchase" campaign in Marketing.', measurement: 'Repeat rate +5 points in 90 days.', why_it_matters: 'Retention compounds growth.', expected_benefit: 'More revenue from existing customers.', risks: 'Over-messaging customers.',
    effort: 'low', impact_score: 0.6, urgency: 0.4, risk_score: 0.2, opportunity_score: 0.8, responsible_department: 'Marketing', strategic: 0.8, evidence: [{ label: 'Repeat rate', value: `${f1(s.repeat_rate_pct.value)}%`, basis: s.repeat_rate_pct.basis || 'estimated' }], goal_categories: ['repeat_customers', 'customers'],
  });
  if (s.repeat_rate_pct.value === null) missing.push({ area: 'Customers', what: 'Customer linked to each sale (at least 10 customers)', why: 'Needed to measure repeat purchases and customer value.' });
  if (s.top_customer_share_pct.value !== null && s.top_customer_share_pct.value > 30) push({
    rule_key: 'customer_concentration', fingerprint: 'customer_concentration', level: 'high', category: 'risk', title: `One customer accounts for ${f1(s.top_customer_share_pct.value)}% of revenue`,
    situation: 'Revenue depends heavily on a single customer (likely wholesale).', analysis: 'Losing or delaying this account would materially affect sales and cash.', impact: 'Concentration risk.',
    recommendation: 'Protect the relationship (terms, service) and add 2–3 more accounts of similar type.', next_step: 'List prospective wholesale/retail partners.', measurement: 'Top customer below 25% of revenue.',
    why_it_matters: 'Dependency on one buyer weakens negotiating position.', expected_benefit: 'More resilient revenue.', risks: 'New accounts take time.', effort: 'high', impact_score: 0.7, urgency: 0.4, risk_score: 0.9, opportunity_score: 0.4, responsible_department: 'Sales',
    evidence: [{ label: 'Top customer share (90d)', value: `${f1(s.top_customer_share_pct.value)}%`, basis: 'actual', entity: 'Customer', ids: [s.top_customer_share_pct.note || ''] }],
  });

  // ── Channel dependency
  const topCh = s.channels[0];
  if (topCh && s.channels.length >= 1 && (topCh.share_pct || 0) >= 75 && (s.revenue_30d.value || 0) > 0) push({
    rule_key: 'channel_dependency', fingerprint: 'channel_dependency', level: 'monitor', category: 'marketing', title: `${f1(topCh.share_pct)}% of revenue comes from ${topCh.key}`,
    situation: `Channel mix over 90 days is concentrated in ${topCh.key}.`, analysis: 'A single channel is efficient but fragile.', impact: 'Changes in that channel (platform fees, venue, partner) affect most revenue.',
    recommendation: 'Test one additional channel with a small budget and measure results.', next_step: 'Pick one channel to test next quarter.', measurement: 'Second channel ≥ 15% of revenue.',
    why_it_matters: 'Diversification reduces risk.', expected_benefit: 'Less dependency.', risks: 'Spreading too thin.', effort: 'medium', impact_score: 0.4, urgency: 0.2, risk_score: 0.5, opportunity_score: 0.5, responsible_department: 'Marketing',
    evidence: [{ label: `Share via ${topCh.key}`, value: `${f1(topCh.share_pct)}%`, basis: 'actual' }],
  });

  // ── Events: follow-ups
  for (const e of s.events) {
    const ed = toDate(e.date);
    if (e.status === 'completed' && e.has_result && (e.leads || 0) > 0 && ed && now.getTime() - ed.getTime() <= 45 * DAY && e.followups_open === 0) push({
      rule_key: 'event_followup', fingerprint: `event_followup:${e.id}`, level: 'high', category: 'marketing', title: `Follow up the ${e.leads} leads from ${e.name}`,
      situation: `${e.name} produced ${e.leads} leads and ${e.customers ?? 'an unknown number of'} customers. No open follow-up task was found.`, analysis: 'Event leads cool quickly; follow-up within 2–3 weeks typically converts best (general practice, not measured for your business yet).',
      impact: 'Unconverted leads are lost event spend.', recommendation: 'Contact event leads who consented, with a personal thank-you and an offer on the shades they tried.', next_step: 'Create a follow-up task and message draft (sending requires your approval).',
      measurement: 'Leads converted to customers within 30 days.', why_it_matters: `The event cost ${money(e.cost, cur)}.`, expected_benefit: 'Higher return on event spend.', risks: 'Only contact people who agreed to be contacted.',
      effort: 'low', impact_score: 0.65, urgency: 0.85, risk_score: 0.2, opportunity_score: 0.8, responsible_department: 'Marketing', evidence: [{ label: 'Leads', value: e.leads, basis: 'actual', entity: 'EventResult' }, { label: 'Event cost', value: e.cost, basis: 'actual', entity: 'Event', ids: [e.id] }], goal_categories: ['customers'],
    });
    if (e.status === 'completed' && !e.has_result) missing.push({ area: 'Events', what: `Results for ${e.name} (visitors, leads, customers, sales)`, why: 'Needed for the Event Performance Report.' });
  }

  // ── Marketing attribution
  const best = s.campaigns.filter((c) => c.reliable && c.cpa !== null).sort((a, b2) => (a.cpa || 0) - (b2.cpa || 0))[0];
  if (best && s.campaigns.filter((c) => c.reliable && c.cpa !== null).length >= 2) push({
    rule_key: 'best_campaign', fingerprint: `best_campaign:${best.id}`, level: 'opportunity', category: 'marketing', title: `"${best.name}" has the lowest cost per customer (${money(best.cpa, cur)})`,
    situation: `Tracked via ${best.attribution}.`, analysis: 'Among campaigns with reliable tracking, this one acquired customers most cheaply.', impact: 'Shifting budget toward it may lower acquisition cost.',
    recommendation: 'Review what made it work and repeat it with a modest budget increase; keep measuring.', next_step: 'Duplicate the campaign with +20% budget as a test.', measurement: 'CPA stays within 20% of this level.',
    why_it_matters: 'Spend where it demonstrably works.', expected_benefit: 'Lower blended acquisition cost (estimate).', risks: 'Results may not scale linearly.', effort: 'low', impact_score: 0.5, urgency: 0.4, risk_score: 0.2, opportunity_score: 0.7, responsible_department: 'Marketing',
    evidence: [{ label: 'CPA', value: best.cpa, basis: 'actual', entity: 'MarketingCampaign', ids: [best.id] }],
  });
  const unattributed = s.campaigns.filter((c) => !c.reliable && c.spend > 0);
  if (unattributed.length) missing.push({ area: 'Marketing', what: `Tracking (promo code / UTM) for ${unattributed.length} campaign(s)`, why: 'Without tracking the platform cannot tell which campaigns produce customers.' });

  // ── Goals
  for (const goal of d.goals || []) {
    const ev = evaluateGoal(goal, now);
    if (ev.status === 'behind' || ev.status === 'at_risk') push({
      rule_key: 'goal_behind', fingerprint: `goal:${goal.id}`, level: ev.status === 'behind' ? 'high' : 'monitor', category: 'goals', title: `Goal "${goal.title}" is ${ev.status === 'behind' ? 'behind' : 'at risk'}`,
      situation: ev.explanation, analysis: 'Current pace is below what is needed to reach the target by the deadline.', impact: 'The goal will be missed without a change in approach.',
      recommendation: 'Either increase effort on the actions linked to this goal or reset the deadline realistically.', next_step: 'Review tasks linked to this goal.', measurement: 'Goal status returns to On track.',
      why_it_matters: 'Goals guide priorities.', expected_benefit: 'Realistic plans.', risks: 'Chasing an unrealistic target can harm cash.', effort: 'medium', impact_score: 0.6, urgency: 0.6, risk_score: 0.4, opportunity_score: 0.4, responsible_department: 'Management', strategic: 0.9,
      evidence: [{ label: 'Progress', value: `${ev.progress_pct}%`, basis: 'actual', entity: 'BusinessGoal', ids: [goal.id] }, { label: 'Time elapsed', value: `${ev.elapsed_pct}%`, basis: 'actual' }], goal_categories: [goal.category],
    });
  }

  // ── Execution
  const overdue = (d.tasks || []).filter((t) => t.due_date && toDate(t.due_date)! < now && !['completed', 'cancelled'].includes(t.status));
  if (overdue.length >= 3) push({
    rule_key: 'overdue_tasks', fingerprint: 'overdue_tasks', level: 'monitor', category: 'operations', title: `${overdue.length} tasks are overdue`,
    situation: `${overdue.length} planned actions passed their due date.`, analysis: 'The plan may be too large for current capacity.', impact: 'Important actions slip; plans lose credibility.',
    recommendation: 'Re-prioritise: keep the top 3, reschedule or cancel the rest.', next_step: 'Open Growth Plan → overdue filter.', measurement: 'Fewer than 3 overdue tasks.',
    why_it_matters: 'Focus beats volume.', expected_benefit: 'Clearer weekly priorities.', risks: 'None significant.', effort: 'low', impact_score: 0.3, urgency: 0.5, risk_score: 0.3, opportunity_score: 0.1, responsible_department: 'Management',
    evidence: [{ label: 'Overdue tasks', value: overdue.length, basis: 'actual', entity: 'Task', ids: overdue.map((t) => t.id) }],
  });

  // ── Data freshness
  if (s.coverage.sales && !s.coverage.sales_recent) missing.push({ area: 'Sales', what: 'Recent sales (none in the last 14 days)', why: 'Analysis may be outdated.' });
  if (!s.coverage.sales) missing.push({ area: 'Sales', what: 'Sales records', why: 'Most analysis depends on sales data. Until then, analysis uses your onboarding estimates.' });
  if (!s.coverage.expenses && !s.coverage.financials) missing.push({ area: 'Finance', what: 'Expenses or monthly financial summary', why: 'Needed for profit and cash-flow analysis.' });

  const positives = F.filter((x) => x.level === 'positive');
  return {
    findings: F, missing,
    summary: {
      working: positives.map((x) => x.title), not_working: F.filter((x) => x.level === 'critical' || x.level === 'high').map((x) => x.title),
      immediate: F.filter((x) => x.level === 'critical').map((x) => x.title), opportunities: F.filter((x) => x.level === 'opportunity').map((x) => x.title),
      risks: F.filter((x) => ['risk', 'finance', 'inventory'].includes(x.category) && ['critical', 'high'].includes(x.level)).map((x) => x.title),
      investigate_next: missing.slice(0, 5).map((m) => `${m.area}: ${m.what}`),
    },
  };
}
