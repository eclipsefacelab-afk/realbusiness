// Priority Engine — ranks findings so the owner sees a short, ordered list.
import type { Finding } from './diagnostics.ts';

export type LearningStats = Record<string, { total: number; success_rate: number }>;
export const WEIGHTS = { financial: 0.3, urgency: 0.25, risk: 0.15, opportunity: 0.15, strategic: 0.1, effort: 0.05 };
const EFFORT = { low: 1, medium: 0.6, high: 0.3 };

export function priorityScore(f: Finding, goals: string[] = [], learning: LearningStats = {}) {
  const goalBoost = f.goal_categories?.some((c) => goals.includes(c)) ? 0.1 : 0;
  let s = WEIGHTS.financial * f.impact_score + WEIGHTS.urgency * f.urgency + WEIGHTS.risk * f.risk_score + WEIGHTS.opportunity * f.opportunity_score
    + WEIGHTS.strategic * Math.min(1, f.strategic + goalBoost) + WEIGHTS.effort * EFFORT[f.effort];
  if (f.dependencies?.length) s -= 0.05;
  // Learning loop: only adjusts once a rule has ≥3 documented outcomes; adjustment is bounded (±0.08).
  const L = learning[f.rule_key];
  let learningNote: string | null = null;
  if (L && L.total >= 3) {
    const adj = (L.success_rate - 0.5) * 0.16;
    s += adj;
    learningNote = `Adjusted ${adj >= 0 ? '+' : ''}${Math.round(adj * 100) / 100} from ${L.total} past outcomes (${Math.round(L.success_rate * 100)}% worked).`;
  }
  if (f.level === 'critical') s += 0.2;
  if (f.level === 'positive') s -= 0.3;
  return { score: Math.round(s * 1000) / 1000, learningNote };
}

export function priorityLabel(f: Finding, score: number): 'critical' | 'high' | 'medium' | 'low' {
  if (f.level === 'critical') return 'critical';
  if (score >= 0.62 || f.level === 'high') return 'high';
  if (score >= 0.4) return 'medium';
  return 'low';
}

export function horizonFor(f: Finding, label: string): 'this_week' | 'this_month' | 'this_quarter' {
  if (label === 'critical' || (f.urgency >= 0.8 && f.effort !== 'high')) return 'this_week';
  if (label === 'high' || f.urgency >= 0.5) return 'this_month';
  return 'this_quarter';
}

const addDays = (now: Date, n: number) => new Date(now.getTime() + n * 86400000).toISOString().slice(0, 10);

// Caps prevent overwhelm: at most 3 this week, 5 this month, 5 this quarter.
export function rankFindings(findings: Finding[], opts: { goals?: string[]; learning?: LearningStats; now?: Date; caps?: { this_week: number; this_month: number; this_quarter: number } } = {}) {
  const now = opts.now || new Date();
  const caps = opts.caps || { this_week: 3, this_month: 5, this_quarter: 5 };
  const ranked = findings.filter((f) => f.level !== 'positive').map((f) => {
    const { score, learningNote } = priorityScore(f, opts.goals, opts.learning);
    const label = priorityLabel(f, score);
    return { f, score, label, horizon: horizonFor(f, label), learningNote };
  }).sort((a, b) => b.score - a.score);
  const counts: Record<string, number> = { this_week: 0, this_month: 0, this_quarter: 0 };
  const shown: typeof ranked = [], deferred: typeof ranked = [];
  for (const r of ranked) {
    let h = r.horizon as keyof typeof caps;
    while (counts[h] >= caps[h] && h !== 'this_quarter') h = h === 'this_week' ? 'this_month' : 'this_quarter';
    if (counts[h] >= caps[h]) { deferred.push(r); continue; }
    counts[h]++; shown.push({ ...r, horizon: h });
  }
  return {
    actions: shown.map((r) => ({ ...r, deadline: addDays(now, r.horizon === 'this_week' ? 7 : r.horizon === 'this_month' ? 30 : 90) })),
    deferred: deferred.map((r) => ({ ...r, deadline: null })),
  };
}
