// Data Quality System: validates imported / entered rows before they are committed.
// Detects missing fields, duplicates (in file and vs existing), invalid dates, non-numeric values,
// unknown categories, inconsistent currencies/units, conflicting figures and suspicious outliers.
// Nothing is silently invented: invalid values are reported, never guessed.
import { ENTITY_REGISTRY } from './entity-registry.ts';

export type Issue = { row: number; field?: string; severity: 'error' | 'warning'; type: string; message: string };

const DUP_KEYS: Record<string, string[]> = {
  Sale: ['date', 'order_id', 'product_id', 'variant_id', 'quantity', 'revenue', 'customer_id'],
  Order: ['order_number'], Product: ['sku', 'name'], ProductVariant: ['sku', 'product_id', 'name'], Customer: ['email'],
  Expense: ['date', 'amount', 'vendor', 'description'], InventoryItem: ['product_id', 'variant_id', 'location_id'],
  FinancialMetric: ['period_start', 'period_type'], MarketingCampaign: ['name', 'start_date'], Supplier: ['name'], Invoice: ['invoice_number'],
};
const NON_NEGATIVE = new Set(['quantity', 'revenue', 'unit_price', 'unit_cost', 'price', 'amount', 'on_hand', 'spend', 'cost', 'total']);

export function normaliseDate(v: any): string | null {
  if (v === null || v === undefined || v === '') return null;
  const s = String(v).trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) { const d = new Date(s + 'T00:00:00Z'); return isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== s ? null : s; }
  if (/^\d{4}-\d{2}-\d{2}T/.test(s)) { const d = new Date(s); return isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10); }
  // Ambiguous formats like 03/04/2026 are rejected rather than guessed.
  return null;
}

export function parseNumber(v: any): number | null | 'invalid' {
  if (v === null || v === undefined || v === '') return null;
  if (typeof v === 'number') return isFinite(v) ? v : 'invalid';
  const s = String(v).trim().replace(/[$€£,\s]/g, '').replace(/^\((.*)\)$/, '-$1');
  if (s === '') return null;
  const n = Number(s);
  return isFinite(n) ? n : 'invalid';
}

const keyOf = (rec: any, keys: string[]) => keys.map((k) => String(rec[k] ?? '').trim().toLowerCase()).join('|');

export function validateRows(entity: string, rows: any[], existing: any[] = []) {
  const meta = ENTITY_REGISTRY[entity];
  if (!meta) throw new Error(`Unknown entity ${entity}`);
  const issues: Issue[] = [];
  const clean: any[] = [];
  const seen = new Map<string, number>();
  const existingKeys = new Set(existing.map((e) => keyOf(e, DUP_KEYS[entity] || [])));
  const currencies = new Set<string>();
  const numericVals: Record<string, number[]> = {};

  rows.forEach((raw, i) => {
    const row = i + 1;
    const rec: any = {};
    let rowHasError = false;
    if (raw && raw.__force_error) rowHasError = true;
    for (const [k, v] of Object.entries(raw || {})) {
      if (k === '__force_error') continue;
      if (!meta.fields.includes(k) || k === 'business_id') { if (v !== '' && v !== null && v !== undefined) issues.push({ row, field: k, severity: 'warning', type: 'unknown_field', message: `Column "${k}" is not part of ${entity} and will be ignored.` }); continue; }
      if (meta.numeric.includes(k)) {
        const n = parseNumber(v);
        if (n === 'invalid') { issues.push({ row, field: k, severity: 'error', type: 'invalid_number', message: `"${v}" is not a number.` }); rowHasError = true; continue; }
        if (n !== null && n < 0 && NON_NEGATIVE.has(k)) issues.push({ row, field: k, severity: 'warning', type: 'suspicious_value', message: `Negative ${k} (${n}). Refunds should be recorded with status "refunded".` });
        if (n !== null) { rec[k] = n; (numericVals[k] ||= []).push(n); }
      } else if (meta.dates.includes(k)) {
        const dt = normaliseDate(v);
        if (v && !dt) { issues.push({ row, field: k, severity: 'error', type: 'invalid_date', message: `"${v}" is not a valid date. Use YYYY-MM-DD.` }); rowHasError = true; continue; }
        if (dt) { rec[k] = dt; if (new Date(dt) > new Date(Date.now() + 366 * 86400000)) issues.push({ row, field: k, severity: 'warning', type: 'suspicious_value', message: `Date ${dt} is more than a year in the future.` }); }
      } else if (meta.enums[k]) {
        if (v === '' || v === null || v === undefined) continue;
        const val = String(v).trim().toLowerCase().replace(/[\s-]+/g, '_');
        if (!meta.enums[k].includes(val)) { issues.push({ row, field: k, severity: 'error', type: 'invalid_category', message: `"${v}" is not one of: ${meta.enums[k].join(', ')}.` }); rowHasError = true; continue; }
        rec[k] = val;
      } else if (v !== '' && v !== null && v !== undefined) rec[k] = typeof v === 'string' ? v.trim() : v;
    }
    for (const req of meta.required) if (rec[req] === undefined || rec[req] === null || rec[req] === '') { issues.push({ row, field: req, severity: 'error', type: 'missing_field', message: `Required field "${req}" is missing.` }); rowHasError = true; }
    if (rec.currency) currencies.add(String(rec.currency).toUpperCase());
    // Conflicting figures: revenue vs quantity × unit_price
    if (entity === 'Sale' && rec.revenue !== undefined && rec.quantity !== undefined && rec.unit_price !== undefined) {
      const calc = rec.quantity * rec.unit_price;
      if (Math.abs(calc - rec.revenue) > Math.max(1, 0.05 * Math.abs(calc))) issues.push({ row, field: 'revenue', severity: 'warning', type: 'conflicting_figures', message: `Revenue ${rec.revenue} differs from quantity × price (${Math.round(calc * 100) / 100}). Discounts? Please confirm.` });
    }
    if (entity === 'FinancialMetric' && rec.revenue !== undefined && rec.cogs !== undefined && rec.gross_profit !== undefined && Math.abs(rec.revenue - rec.cogs - rec.gross_profit) > 1) issues.push({ row, field: 'gross_profit', severity: 'warning', type: 'conflicting_figures', message: 'Gross profit does not equal revenue − cost of goods.' });
    const dk = DUP_KEYS[entity];
    if (dk) {
      const k = keyOf(rec, dk);
      if (k.replace(/\|/g, '') !== '') {
        if (seen.has(k)) issues.push({ row, severity: 'warning', type: 'duplicate', message: `Looks like a duplicate of row ${seen.get(k)} in this file.` });
        else seen.set(k, row);
        if (existingKeys.has(k)) issues.push({ row, severity: 'warning', type: 'duplicate_existing', message: 'A matching record already exists.' });
      }
    }
    clean.push({ ...rec, __row: row, __error: rowHasError });
  });
  if (currencies.size > 1) issues.push({ row: 0, field: 'currency', severity: 'warning', type: 'inconsistent_units', message: `Multiple currencies in one file (${[...currencies].join(', ')}). Totals will not be converted automatically.` });
  // Outliers: > 10× median
  for (const [k, vals] of Object.entries(numericVals)) {
    if (vals.length < 8) continue;
    const sorted = [...vals].map(Math.abs).sort((a, b) => a - b), med = sorted[Math.floor(sorted.length / 2)];
    if (med <= 0) continue;
    clean.forEach((r) => { if (typeof r[k] === 'number' && Math.abs(r[k]) > med * 10) issues.push({ row: r.__row, field: k, severity: 'warning', type: 'suspicious_value', message: `${k} = ${r[k]} is more than 10× the typical value (${med}).` }); });
  }
  const errorRows = new Set([...issues.filter((i) => i.severity === 'error').map((i) => i.row), ...clean.filter((r) => r.__error).map((r) => r.__row)]);
  return { rows: clean, issues, valid_count: clean.filter((r) => !errorRows.has(r.__row)).length, error_rows: [...errorRows], row_count: rows.length };
}

// Simple CSV parser (quoted fields, commas, CRLF). Excel files are parsed in the browser to rows.
export function parseCSV(text: string): Record<string, string>[] {
  const out: string[][] = []; let row: string[] = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"' && text[i + 1] === '"') { cell += '"'; i++; } else if (c === '"') q = false; else cell += c; }
    else if (c === '"') q = true; else if (c === ',') { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cell); out.push(row); row = []; cell = ''; }
    else cell += c;
  }
  if (cell !== '' || row.length) { row.push(cell); out.push(row); }
  const [header, ...body] = out.filter((r) => r.some((x) => x.trim() !== ''));
  if (!header) return [];
  const h = header.map((x) => x.trim().toLowerCase().replace(/\s+/g, '_'));
  return body.map((r) => Object.fromEntries(h.map((k, i) => [k, (r[i] ?? '').trim()])));
}
