// `api` backend function: the single, permission-checked gateway for all business data.
import { ENTITY_REGISTRY } from './entity-registry.ts';
import { can, canAssignRole, maskRecord, ENTITY_RESOURCE, PROTECTED_FIELDS, SYSTEM_ONLY_WRITE, FINANCE_REPORT_KINDS, ROLES, permissionsFor, type Role } from './permissions.ts';
import { HttpError, requireUser, membershipsFor, tenantContext, assertCan, audit, type Ctx } from './context.ts';
import { validateRows } from './validation.ts';
import { evaluateGoal } from './goals.ts';
import { seedDemoBusiness, createMany } from './demo.ts';
import { extensions } from './extensions.ts';

const GOAL_MAP: Record<string, { title: string; category: string }> = {
  increase_revenue: { title: 'Increase revenue', category: 'revenue' }, increase_profit: { title: 'Increase profit', category: 'profit' },
  increase_customers: { title: 'Increase customers', category: 'customers' }, increase_repeat_customers: { title: 'Increase repeat customers', category: 'repeat_customers' },
  launch_products: { title: 'Launch products', category: 'other' }, open_locations: { title: 'Open locations', category: 'locations' }, expand_geographically: { title: 'Expand geographically', category: 'market' },
  enter_new_markets: { title: 'Enter new markets', category: 'market' }, increase_ecommerce: { title: 'Increase ecommerce', category: 'ecommerce' }, increase_wholesale: { title: 'Increase wholesale', category: 'wholesale' },
  hire_employees: { title: 'Hire employees', category: 'hiring' }, improve_operations: { title: 'Improve operations', category: 'operations' }, raise_financing: { title: 'Raise financing', category: 'financing' },
  prepare_for_investment: { title: 'Prepare for investment', category: 'financing' }, build_management_team: { title: 'Build a management team', category: 'hiring' }, prepare_for_sale: { title: 'Prepare for sale', category: 'other' },
};

function tenantEntity(entity: string) {
  const meta = ENTITY_REGISTRY[entity];
  if (!meta || !meta.tenant || entity === 'BusinessMember') throw new HttpError(400, `Entity ${entity} is not available through this endpoint.`);
  return meta;
}

function sanitize(entity: string, data: any, partial: boolean) {
  const meta = ENTITY_REGISTRY[entity];
  const input: any = {};
  for (const [k, v] of Object.entries(data || {})) if (!PROTECTED_FIELDS.includes(k) && meta.fields.includes(k)) input[k] = v;
  // Re-use the import validator for type coercion, enum and required checks.
  const objFields = Object.keys(input).filter((k) => typeof input[k] === 'object' && input[k] !== null);
  const flat = Object.fromEntries(Object.entries(input).filter(([k]) => !objFields.includes(k)));
  const v = validateRows(entity, [flat]);
  const errors = v.issues.filter((i) => i.severity === 'error' && !(partial && i.type === 'missing_field'));
  if (errors.length) throw new HttpError(422, errors.map((e) => e.message).join(' '), errors);
  const { __row, __error, ...clean } = v.rows[0];
  for (const k of objFields) clean[k] = input[k];
  return clean;
}

// Additional per-record visibility rules beyond resource permissions.
function visible(ctx: Ctx, entity: string, rec: any) {
  if (entity === 'Report' && FINANCE_REPORT_KINDS.has(rec.kind) && !can(ctx.role, 'finance', 'read')) return false;
  if (entity === 'AIConversation' && rec.user_id !== ctx.user.id && ctx.role !== 'owner') return false;
  if (entity === 'Notification' && rec.user_id && rec.user_id !== ctx.user.id) return false;
  if (entity === 'Document') {
    if (rec.visibility === 'finance' && !can(ctx.role, 'finance', 'read')) return false;
    if (rec.visibility === 'owner_admin' && !['owner', 'admin'].includes(ctx.role)) return false;
    if (rec.visibility === 'managers' && ['employee', 'read_only'].includes(ctx.role)) return false;
  }
  return true;
}

async function getScoped(ctx: Ctx, entity: string, id: string) {
  const rec = await ctx.svc.entities[entity].get(id).catch(() => null);
  // Records of other businesses are indistinguishable from missing records.
  if (!rec || rec.business_id !== ctx.businessId || !visible(ctx, entity, rec)) throw new HttpError(404, 'Record not found.');
  return rec;
}

export async function handleApi(body: any, deps: { client: any; svc: any; now?: Date }) {
  const { client, svc } = deps;
  const now = deps.now || new Date();
  const user = await requireUser(client);
  const action = body?.action;

  // ── Account-level actions (no business context yet)
  if (action === 'bootstrap') {
    const memberships = await membershipsFor(svc, user);
    const businesses: any[] = [];
    for (const m of memberships) {
      const b = await svc.entities.Business.get(m.business_id).catch(() => null);
      if (b && b.status !== 'archived') businesses.push({ id: b.id, name: b.name, industry_module: b.industry_module, current_stage: b.current_stage, health_score: can(m.role, 'strategy', 'read') ? b.health_score : null, onboarding_complete: b.onboarding_complete, is_demo: b.is_demo, role: m.role, permissions: permissionsFor(m.role), plan_key: b.plan_key, currency: b.currency });
    }
    const plans = await svc.entities.PlanConfig.filter({ active: true }).catch(() => []);
    return { user: { id: user.id, email: user.email, full_name: user.full_name, platform_role: user.role }, businesses, plans, roles: ROLES };
  }
  if (action === 'createBusiness') {
    const d = body.data || {};
    if (!d.name || String(d.name).trim().length < 2) throw new HttpError(422, 'Business name is required.');
    const bData = sanitizeBusiness(d);
    const b = await svc.entities.Business.create({ ...bData, owner_user_id: user.id, status: 'active', plan_key: bData.plan_key || 'trial', onboarding_complete: true });
    await svc.entities.BusinessMember.create({ business_id: b.id, user_id: user.id, user_email: String(user.email || '').toLowerCase(), role: 'owner', status: 'active' });
    const ctx = { svc, user, businessId: b.id } as any;
    for (const c of bData.operating_countries || []) await svc.entities.BusinessLocation.create({ business_id: b.id, name: c, kind: 'market', country: c, status: 'active' });
    for (const g of bData.goals || []) {
      const m = GOAL_MAP[g]; if (!m) continue;
      await svc.entities.BusinessGoal.create({ business_id: b.id, title: m.title, category: m.category, target_value: 0, start_value: 0, status: 'not_started', notes: 'Created from onboarding — set a measurable target and deadline.', deadline: bData.goal_timeframe_months ? new Date(now.getTime() + bData.goal_timeframe_months * 30 * 86400000).toISOString().slice(0, 10) : undefined });
    }
    await audit(ctx, 'business.create', 'Business', b.id, `Created business ${b.name} via onboarding`);
    return { business: b };
  }
  if (action === 'portfolio') {
    const memberships = await membershipsFor(svc, user);
    const rows: any[] = [];
    for (const m of memberships) {
      const b = await svc.entities.Business.get(m.business_id).catch(() => null); if (!b || b.status === 'archived') continue;
      const kpis = can(m.role, 'sales', 'read') ? await svc.entities.BusinessMetric.filter({ business_id: b.id, metric_key: 'revenue_30d' }, '-created_date', 1) : [];
      const alerts = svc.entities.Alert ? await svc.entities.Alert.filter({ business_id: b.id, status: 'open' }, '-created_date', 200).catch(() => []) : [];
      rows.push({ id: b.id, name: b.name, role: m.role, stage: b.current_stage, health_score: can(m.role, 'strategy', 'read') ? b.health_score : null, health_basis: b.health_score_basis, revenue_30d: kpis[0]?.value ?? null, revenue_basis: kpis[0]?.data_basis ?? null, open_alerts: alerts.length, critical_alerts: alerts.filter((x: any) => x.severity === 'critical').length, is_demo: b.is_demo });
    }
    return { businesses: rows };
  }
  if (action === 'demo.load') {
    const b = await seedDemoBusiness(svc, user, now);
    return { business: b };
  }

  // ── Business-scoped actions
  const ctx = await tenantContext(svc, user, body.business_id);
  const ext = extensions.api[action];
  if (ext) return ext(ctx, body, now);

  switch (action) {
    case 'business.get': return { business: maskBusiness(ctx), role: ctx.role, permissions: permissionsFor(ctx.role) };
    case 'business.update': {
      assertCan(ctx, 'business', 'write');
      const data = sanitizeBusiness(body.data || {});
      const finKeys = ['avg_monthly_revenue', 'gross_margin_pct', 'monthly_operating_expenses', 'cash_available', 'debt', 'est_customer_acquisition_cost', 'major_recurring_expenses', 'other_financials', 'financials_basis'];
      if (finKeys.some((k) => k in data) && !can(ctx.role, 'finance', 'write')) throw new HttpError(403, 'Your role cannot change financial information.');
      if ('plan_key' in data && ctx.role !== 'owner') delete data.plan_key;
      const updated = await svc.entities.Business.update(ctx.businessId, data);
      await audit(ctx, 'business.update', 'Business', ctx.businessId, `Updated fields: ${Object.keys(data).join(', ')}`, pick(ctx.business, Object.keys(data)), data);
      return { business: updated };
    }
    case 'business.archive': {
      if (ctx.role !== 'owner') throw new HttpError(403, 'Only the owner can archive a business.');
      await svc.entities.Business.update(ctx.businessId, { status: 'archived' });
      await audit(ctx, 'business.archive', 'Business', ctx.businessId, 'Business archived');
      return { ok: true };
    }
    case 'list': {
      const entity = body.entity; tenantEntity(entity); assertCan(ctx, ENTITY_RESOURCE[entity], 'read');
      const filter: any = { ...(body.filter || {}) };
      for (const k of Object.keys(filter)) if (!ENTITY_REGISTRY[entity].fields.includes(k) && k !== 'id') delete filter[k];
      filter.business_id = ctx.businessId; // always enforced, overrides any caller value
      const limit = Math.min(Number(body.limit) || 500, 5000);
      const rows = await svc.entities[entity].filter(filter, body.sort || '-created_date', limit);
      return { items: rows.filter((r: any) => r.business_id === ctx.businessId && visible(ctx, entity, r)).map((r: any) => maskRecord(entity, r, ctx.role)) };
    }
    case 'get': {
      const entity = body.entity; tenantEntity(entity); assertCan(ctx, ENTITY_RESOURCE[entity], 'read');
      return { item: maskRecord(entity, await getScoped(ctx, entity, body.id), ctx.role) };
    }
    case 'create': {
      const entity = body.entity; tenantEntity(entity); assertCan(ctx, ENTITY_RESOURCE[entity], 'write');
      if (SYSTEM_ONLY_WRITE.has(entity)) throw new HttpError(403, `${entity} records are created by the system.`);
      const data = sanitize(entity, body.data, false);
      if (entity === 'AIConversation') data.user_id = user.id;
      guardIntegrationStatus(entity, data);
      await checkRefs(ctx, entity, data);
      const rec = await svc.entities[entity].create({ ...data, business_id: ctx.businessId });
      await audit(ctx, 'create', entity, rec.id, `Created ${entity}`, null, data);
      await extensions.afterWrite(ctx, entity, 'create', rec, now);
      return { item: maskRecord(entity, rec, ctx.role) };
    }
    case 'update': {
      const entity = body.entity; tenantEntity(entity); assertCan(ctx, ENTITY_RESOURCE[entity], 'write');
      if (SYSTEM_ONLY_WRITE.has(entity)) throw new HttpError(403, `${entity} records are read-only.`);
      const before = await getScoped(ctx, entity, body.id);
      const data = sanitize(entity, body.data, true);
      guardIntegrationStatus(entity, data);
      if (entity === 'Task' && data.status === 'completed' && before.status !== 'completed') data.completed_at = now.toISOString();
      await checkRefs(ctx, entity, data);
      const rec = await svc.entities[entity].update(body.id, data);
      await audit(ctx, 'update', entity, body.id, `Updated ${entity}: ${Object.keys(data).join(', ')}`, pick(before, Object.keys(data)), data);
      await extensions.afterWrite(ctx, entity, 'update', { ...before, ...data }, now, before);
      return { item: maskRecord(entity, { ...before, ...rec, ...data }, ctx.role) };
    }
    case 'delete': {
      const entity = body.entity; tenantEntity(entity); assertCan(ctx, ENTITY_RESOURCE[entity], 'delete');
      if (SYSTEM_ONLY_WRITE.has(entity) || entity === 'AuditLog') throw new HttpError(403, `${entity} records cannot be deleted.`);
      const before = await getScoped(ctx, entity, body.id);
      const gate = await extensions.beforeDelete(ctx, entity, before, body, now);
      if (gate) return gate; // e.g. approval required (Prompt 2)
      await svc.entities[entity].delete(body.id);
      await audit(ctx, 'delete', entity, body.id, `Deleted ${entity} ${before.name || before.title || before.id}`, before, null);
      return { ok: true };
    }
    case 'recommendation.decide': {
      assertCan(ctx, 'strategy', 'approve');
      const rec = await getScoped(ctx, 'Recommendation', body.id);
      const map: Record<string, string> = { approve: 'approved', reject: 'rejected', defer: 'deferred', assign: 'assigned' };
      const status = map[body.decision]; if (!status) throw new HttpError(422, 'decision must be approve, reject, defer or assign');
      let task: any = null;
      if (['approve', 'assign'].includes(body.decision) && !rec.task_id) {
        task = await svc.entities.Task.create({ business_id: ctx.businessId, title: rec.next_step || rec.title, description: rec.recommendation, priority: rec.priority, due_date: body.due_date || rec.suggested_deadline, status: 'not_started', owner_user_id: body.owner_user_id, owner_name: body.owner_name || rec.responsible_department, expected_outcome: rec.expected_benefit, kpi: rec.measurement, recommendation_id: rec.id, plan_horizon: rec.horizon === 'this_week' ? '30' : rec.horizon === 'this_month' ? '60' : '90' });
      }
      await svc.entities.Recommendation.update(rec.id, { status, decided_by: user.email, decided_at: now.toISOString(), task_id: task?.id || rec.task_id, ...(body.decision === 'defer' && body.until ? { suggested_deadline: body.until } : {}) });
      await audit(ctx, `recommendation.${body.decision}`, 'Recommendation', rec.id, `${status}: ${rec.title}${body.note ? ' — ' + body.note : ''}`);
      return { ok: true, task };
    }
    case 'recommendation.outcome': {
      assertCan(ctx, 'strategy', 'write');
      const rec = await getScoped(ctx, 'Recommendation', body.id);
      if (!['worked', 'partially', 'did_not_work', 'unknown'].includes(body.outcome)) throw new HttpError(422, 'Invalid outcome');
      await svc.entities.Recommendation.update(rec.id, { outcome: body.outcome, actual_result: String(body.actual_result || ''), status: 'done' });
      await audit(ctx, 'recommendation.outcome', 'Recommendation', rec.id, `Outcome ${body.outcome}: ${body.actual_result || ''}`);
      await extensions.afterOutcome(ctx, rec, body, now);
      return { ok: true };
    }
    case 'goals.refresh': {
      assertCan(ctx, 'strategy', 'read');
      const goals = await svc.entities.BusinessGoal.filter({ business_id: ctx.businessId });
      const out: any[] = [];
      for (const g of goals) { const ev = evaluateGoal(g, now); if (can(ctx.role, 'strategy', 'write') && (ev.status !== g.status || ev.progress_pct !== g.progress_pct)) await svc.entities.BusinessGoal.update(g.id, { status: ev.status, progress_pct: ev.progress_pct, required_pace: ev.required_pace }); out.push({ ...g, ...ev }); }
      return { goals: out };
    }
    case 'members.list': {
      assertCan(ctx, 'members', 'read');
      return { members: await svc.entities.BusinessMember.filter({ business_id: ctx.businessId }) };
    }
    case 'members.invite': {
      assertCan(ctx, 'members', 'write');
      const email = String(body.email || '').trim().toLowerCase(), role = body.role as Role;
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new HttpError(422, 'Valid email required.');
      if (!ROLES.includes(role) || !canAssignRole(ctx.role, role)) throw new HttpError(403, 'You cannot assign that role.');
      const existing = await svc.entities.BusinessMember.filter({ business_id: ctx.businessId, user_email: email });
      if (existing.some((m: any) => m.status !== 'removed')) throw new HttpError(409, 'This person is already a member or invited.');
      const m = await svc.entities.BusinessMember.create({ business_id: ctx.businessId, user_email: email, role, status: 'invited', invited_by: user.email });
      await audit(ctx, 'members.invite', 'BusinessMember', m.id, `Invited ${email} as ${role}`);
      return { member: m, note: 'The person gets access the first time they sign in to this app with this email. Ask them to sign up / log in (invite emails require the app to be shared with them in Base44).' };
    }
    case 'members.update': {
      assertCan(ctx, 'members', 'write');
      const m = await getMember(ctx, body.member_id);
      const role = body.role as Role;
      if (!ROLES.includes(role) || !canAssignRole(ctx.role, role) || !canAssignRole(ctx.role, m.role)) throw new HttpError(403, 'You cannot change this member to that role.');
      if (m.role === 'owner' && role !== 'owner') await ensureAnotherOwner(ctx, m.id);
      await extensions.beforePermissionChange(ctx, m, role, now);
      await svc.entities.BusinessMember.update(m.id, { role });
      await audit(ctx, 'members.role_change', 'BusinessMember', m.id, `${m.user_email}: ${m.role} → ${role}`, { role: m.role }, { role });
      return { ok: true };
    }
    case 'members.remove': {
      assertCan(ctx, 'members', 'write');
      const m = await getMember(ctx, body.member_id);
      if (!canAssignRole(ctx.role, m.role)) throw new HttpError(403, 'You cannot remove this member.');
      if (m.role === 'owner') await ensureAnotherOwner(ctx, m.id);
      await svc.entities.BusinessMember.update(m.id, { status: 'removed' });
      await audit(ctx, 'members.remove', 'BusinessMember', m.id, `Removed ${m.user_email}`);
      return { ok: true };
    }
    case 'import.validate': {
      const entity = body.entity; tenantEntity(entity); assertCan(ctx, 'imports', 'write'); assertCan(ctx, ENTITY_RESOURCE[entity], 'write');
      const rows = Array.isArray(body.rows) ? body.rows.slice(0, 5000) : [];
      if (!rows.length) throw new HttpError(422, 'No rows found in the file.');
      const existing = await svc.entities[entity].filter({ business_id: ctx.businessId }, '-created_date', 5000);
      const resolved = await resolveNames(ctx, entity, rows);
      const v = validateRows(entity, resolved.rows, existing);
      v.issues.push(...resolved.issues);
      const batch = await svc.entities.ImportBatch.create({ business_id: ctx.businessId, target_entity: entity, file_name: body.file_name, source: body.source || 'csv', row_count: v.row_count, valid_count: v.valid_count, issue_count: v.issues.length, issues: v.issues.slice(0, 1000), rows: v.rows, status: 'pending_review' });
      return { batch_id: batch.id, row_count: v.row_count, valid_count: v.valid_count, issues: v.issues.slice(0, 1000), preview: v.rows.slice(0, 20) };
    }
    case 'import.extract': {
      // Excel/PDF/other files: Base44's file extraction turns the uploaded file into rows, which then go through the same validation & review.
      const entity = body.entity; tenantEntity(entity); assertCan(ctx, 'imports', 'write');
      if (!body.file_uri && !body.file_url) throw new HttpError(422, 'Upload a file first.');
      const url = body.file_url || (await svc.integrations.Core.CreateFileSignedUrl({ file_uri: body.file_uri, expires_in: 600 })).signed_url;
      const props = Object.fromEntries(ENTITY_REGISTRY[entity].fields.filter((f) => f !== 'business_id').map((f) => [f, { type: ENTITY_REGISTRY[entity].numeric.includes(f) ? 'number' : 'string' }]));
      for (const k of ['product', 'shade', 'customer_email', 'location']) props[k] = { type: 'string' };
      const out = await svc.integrations.Core.ExtractDataFromUploadedFile({ file_url: url, json_schema: { type: 'object', properties: { rows: { type: 'array', items: { type: 'object', properties: props } } } } });
      if (out?.status && out.status !== 'success') throw new HttpError(422, `Could not read the file: ${out.details || out.status}`);
      const rows = out?.output?.rows || (Array.isArray(out?.output) ? out.output : []);
      return { rows, note: 'Rows were extracted automatically — review them carefully before committing.' };
    }
    case 'import.commit': {
      assertCan(ctx, 'imports', 'write');
      const batch = await getScoped(ctx, 'ImportBatch', body.batch_id);
      if (batch.status !== 'pending_review') throw new HttpError(409, `Import is already ${batch.status}.`);
      assertCan(ctx, ENTITY_RESOURCE[batch.target_entity], 'write');
      const skipDup = body.skip_duplicates !== false;
      const dupRows = new Set((batch.issues || []).filter((i: any) => i.type === 'duplicate' || i.type === 'duplicate_existing').map((i: any) => i.row));
      const extra = ENTITY_REGISTRY[batch.target_entity].fields.includes('import_batch_id') ? { import_batch_id: batch.id } : {};
      const src = ENTITY_REGISTRY[batch.target_entity].fields.includes('source') ? { source: batch.source || 'csv' } : {};
      const toCreate = (batch.rows || []).filter((r: any) => !r.__error && !(skipDup && dupRows.has(r.__row))).map(({ __row, __error, ...rec }: any) => ({ ...rec, ...extra, ...src, business_id: ctx.businessId }));
      const refCache = new Map<string, boolean>();
      for (const rec of toCreate) await checkRefs(ctx, batch.target_entity, rec, refCache);
      await createMany(svc, batch.target_entity, toCreate);
      const n = toCreate.length;
      await svc.entities.ImportBatch.update(batch.id, { status: 'committed', committed_count: n, reviewed_by: user.email, rows: [] });
      await audit(ctx, 'import.commit', batch.target_entity, batch.id, `Imported ${n} ${batch.target_entity} rows from ${batch.file_name || 'file'}`);
      await extensions.afterImport(ctx, batch.target_entity, n, now);
      return { committed: n };
    }
    case 'import.reject': {
      assertCan(ctx, 'imports', 'write');
      const batch = await getScoped(ctx, 'ImportBatch', body.batch_id);
      await svc.entities.ImportBatch.update(batch.id, { status: 'rejected', rows: [], reviewed_by: user.email });
      return { ok: true };
    }
    case 'document.url': {
      assertCan(ctx, 'documents', 'read');
      const doc = await getScoped(ctx, 'Document', body.id);
      if (!doc.file_uri) throw new HttpError(404, 'This document has no file attached.');
      const r = await svc.integrations.Core.CreateFileSignedUrl({ file_uri: doc.file_uri, expires_in: 300 });
      await audit(ctx, 'document.download', 'Document', doc.id, `Downloaded ${doc.title}`);
      return { url: r.signed_url };
    }
    case 'notifications.read': {
      const n = await getScoped(ctx, 'Notification', body.id);
      await svc.entities.Notification.update(n.id, { read: true });
      return { ok: true };
    }
    default: throw new HttpError(400, `Unknown action ${action}`);
  }
}

// Lets spreadsheets use names/SKUs/emails instead of internal ids (product, shade, customer, location).
async function resolveNames(ctx: Ctx, entity: string, rows: any[]) {
  const meta = ENTITY_REGISTRY[entity];
  const needs = (f: string) => meta.fields.includes(f);
  const issues: any[] = [];
  const load = async (e: string) => ctx.svc.entities[e].filter({ business_id: ctx.businessId }, '-created_date', 5000);
  const [products, variants, customers, locations] = await Promise.all([
    needs('product_id') ? load('Product') : [], needs('variant_id') ? load('ProductVariant') : [], needs('customer_id') ? load('Customer') : [], needs('location_id') ? load('BusinessLocation') : [],
  ]);
  const low = (x: any) => String(x ?? '').trim().toLowerCase();
  const pBy = new Map<string, string>(); for (const p of products) { pBy.set(low(p.name), p.id); if (p.sku) pBy.set(low(p.sku), p.id); }
  const vBy = new Map<string, any>(); for (const v of variants) { if (v.sku) vBy.set(low(v.sku), v); vBy.set(`${v.product_id}|${low(v.shade_name || v.name)}`, v); }
  const cBy = new Map<string, string>(); for (const c of customers) { if (c.email) cBy.set(low(c.email), c.id); if (c.display_name) cBy.set(low(c.display_name), c.id); }
  const lBy = new Map<string, string>(); for (const l of locations) lBy.set(low(l.name), l.id);
  const out = rows.map((raw, i) => {
    const r: any = { ...raw };
    const prodKey = r.product_sku ?? r.product_name ?? r.product;
    if (needs('product_id') && !r.product_id && prodKey) { const id = pBy.get(low(prodKey)); if (id) r.product_id = id; else issues.push({ row: i + 1, field: 'product', severity: 'error', type: 'unknown_reference', message: `Product "${prodKey}" not found. Add it in Products first.` }); }
    const vKey = r.variant_sku ?? r.shade ?? r.variant;
    if (needs('variant_id') && !r.variant_id && vKey) { const v = vBy.get(low(r.variant_sku ?? '')) || vBy.get(`${r.product_id}|${low(r.shade ?? r.variant)}`); if (v) { r.variant_id = v.id; r.product_id ||= v.product_id; } else issues.push({ row: i + 1, field: 'shade', severity: 'error', type: 'unknown_reference', message: `Shade/variant "${vKey}" not found for this product.` }); }
    const cKey = r.customer_email ?? r.customer;
    if (needs('customer_id') && !r.customer_id && cKey) { const id = cBy.get(low(cKey)); if (id) r.customer_id = id; else issues.push({ row: i + 1, field: 'customer', severity: 'warning', type: 'unknown_reference', message: `Customer "${cKey}" not found; the sale will be imported without a customer link.` }); }
    if (needs('location_id') && !r.location_id && r.location) { const id = lBy.get(low(r.location)); if (id) r.location_id = id; else issues.push({ row: i + 1, field: 'location', severity: 'warning', type: 'unknown_reference', message: `Location "${r.location}" not found.` }); }
    for (const k of ['product_sku', 'product_name', 'product', 'variant_sku', 'shade', 'variant', 'customer_email', 'customer', 'location']) if (!meta.fields.includes(k)) delete r[k];
    return r;
  });
  // Unknown-reference errors must block the row.
  return { rows: out.map((r, i) => (issues.some((x) => x.row === i + 1 && x.severity === 'error') ? { ...r, __force_error: true } : r)), issues };
}

function guardIntegrationStatus(entity: string, data: any) {
  // An integration can only be reported as connected by a successful, server-side connection test.
  if (entity === 'Integration' && ['connected', 'failed'].includes(data.status)) throw new HttpError(422, 'Integration status is set by connection tests, not manually.');
  if (entity === 'Integration' && ('last_tested_at' in data || 'last_test_result' in data)) { delete data.last_tested_at; delete data.last_test_result; }
}

async function getMember(ctx: Ctx, id: string) {
  const m = await ctx.svc.entities.BusinessMember.get(id).catch(() => null);
  if (!m || m.business_id !== ctx.businessId) throw new HttpError(404, 'Member not found.');
  return m;
}
async function ensureAnotherOwner(ctx: Ctx, exceptId: string) {
  const owners = (await ctx.svc.entities.BusinessMember.filter({ business_id: ctx.businessId, role: 'owner', status: 'active' })).filter((m: any) => m.id !== exceptId);
  if (!owners.length) throw new HttpError(409, 'A business must keep at least one owner.');
}
async function checkRefs(ctx: Ctx, entity: string, data: any, cache: Map<string, boolean> = new Map()) {
  // Referenced records must belong to the same business (prevents cross-tenant linking).
  for (const [field, target] of Object.entries(ENTITY_REGISTRY[entity].refs)) {
    const id = data[field]; if (!id) continue;
    const key = `${target}:${id}`;
    if (!cache.has(key)) { const rec = await ctx.svc.entities[target]?.get(id).catch(() => null); cache.set(key, !!rec && rec.business_id === ctx.businessId); }
    if (!cache.get(key)) throw new HttpError(422, `${field} refers to a ${target} that does not exist in this business.`);
  }
}
function sanitizeBusiness(d: any) {
  const meta = ENTITY_REGISTRY.Business;
  const allowed = meta.fields.filter((f) => !['owner_user_id', 'health_score', 'health_score_basis', 'current_stage', 'stage_reason', 'status', 'is_demo', 'parent_business_id'].includes(f));
  const out: any = {};
  for (const k of allowed) if (k in d) out[k] = d[k];
  for (const k of meta.numeric) if (k in out) { const n = out[k] === '' || out[k] === null ? null : Number(out[k]); if (n !== null && !isFinite(n)) throw new HttpError(422, `${k} must be a number`); out[k] = n; }
  for (const [k, vals] of Object.entries(meta.enums)) if (k in out && out[k] && !vals.includes(out[k])) throw new HttpError(422, `${k} must be one of ${vals.join(', ')}`);
  if (out.maturity_answers && typeof out.maturity_answers === 'object') out.maturity_answers = Object.fromEntries(Object.entries(out.maturity_answers).filter(([, v]) => Number(v) >= 1 && Number(v) <= 5).map(([k, v]) => [k, Number(v)]));
  return out;
}
function maskBusiness(ctx: Ctx) {
  const b = { ...ctx.business };
  if (!can(ctx.role, 'finance', 'read')) for (const k of ['avg_monthly_revenue', 'gross_margin_pct', 'monthly_operating_expenses', 'cash_available', 'debt', 'est_customer_acquisition_cost', 'major_recurring_expenses', 'other_financials']) delete b[k];
  return b;
}
const pick = (o: any, keys: string[]) => Object.fromEntries(keys.map((k) => [k, o?.[k]]));
