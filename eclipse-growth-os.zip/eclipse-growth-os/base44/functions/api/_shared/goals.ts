// Goal progress & pace: Ahead / On track / At risk / Behind.
import { toDate, DAY } from './metrics.ts';

export function evaluateGoal(g: any, now = new Date()) {
  const start = Number(g.start_value ?? 0), target = Number(g.target_value), current = Number(g.current_value ?? g.start_value ?? 0);
  if (!isFinite(target) || target === start) return { status: g.status || 'not_started', progress_pct: null, required_pace: null, elapsed_pct: null, explanation: 'Target must differ from the starting value.' };
  const progress = (current - start) / (target - start);
  const s = toDate(g.start_date || g.created_date) || now, e = toDate(g.deadline);
  const elapsed = e ? Math.min(1, Math.max(0, (now.getTime() - s.getTime()) / Math.max(DAY, e.getTime() - s.getTime()))) : null;
  const remainingMonths = e ? Math.max(0.03, (e.getTime() - now.getTime()) / (30 * DAY)) : null;
  const required = remainingMonths ? (target - current) / remainingMonths : null;
  let status: string;
  if (['cancelled'].includes(g.status)) status = g.status;
  else if (progress >= 1) status = 'achieved';
  else if (elapsed === null) status = progress > 0 ? 'on_track' : 'not_started';
  else if (e && now > e) status = 'behind';
  else if (progress >= elapsed + 0.1) status = 'ahead';
  else if (progress >= elapsed - 0.05) status = 'on_track';
  else if (progress >= elapsed - 0.2) status = 'at_risk';
  else status = 'behind';
  const pct = Math.round(progress * 1000) / 10;
  return {
    status, progress_pct: pct, elapsed_pct: elapsed === null ? null : Math.round(elapsed * 1000) / 10, required_pace: required === null ? null : Math.round(required * 100) / 100,
    explanation: elapsed === null ? `${pct}% of the way to target (no deadline set).` : `${pct}% done with ${Math.round(elapsed * 100)}% of the time used. To finish on time you need about ${required === null ? 'n/a' : Math.round(required * 100) / 100} ${g.unit || ''} per month.`,
  };
}
