// Business Maturity Assessment & Health Score.
// A category is scored only from evidence that exists. With no evidence the score is null and the
// assessment says what information is needed. Owner self-assessment answers (1–5) count as
// ESTIMATED evidence and are labelled that way.
import type { Snapshot, Basis } from './metrics.ts';
import { industryFor } from './industries.ts';

export const HEALTH_CATEGORIES = [
  ['product', 'Product'], ['customers', 'Customers'], ['sales', 'Sales'], ['marketing', 'Marketing'], ['finance', 'Finance'],
  ['operations', 'Operations'], ['technology', 'Technology'], ['inventory', 'Inventory'], ['management', 'Management'],
  ['employees', 'Employees'], ['customer_service', 'Customer service'], ['brand', 'Brand'], ['competitive_position', 'Competitive position'],
  ['cash_flow', 'Cash flow'], ['scalability', 'Scalability'], ['risk', 'Risk'], ['expansion_readiness', 'Expansion readiness'],
] as const;
export type CategoryKey = typeof HEALTH_CATEGORIES[number][0];

// Plain-language self-assessment questions shown in onboarding (answers 1–5).
export const MATURITY_QUESTIONS: Record<CategoryKey, string> = {
  product: 'How confident are you that customers love your products? (1 = unsure, 5 = proven repeat demand)',
  customers: 'How well do you know who your customers are and how to reach them?',
  sales: 'How predictable are your monthly sales?',
  marketing: 'Do you know which marketing activities actually bring customers?',
  finance: 'How well do you track money in and money out each month?',
  operations: 'How smoothly do production, fulfilment and day-to-day tasks run without you?',
  technology: 'How well do your tools (website, POS, inventory, accounting) work together?',
  inventory: 'How rarely do you run out of, or have too much of, stock?',
  management: 'Do you have people who can make decisions when you are not there?',
  employees: 'Do you have enough trained people for current demand?',
  customer_service: 'How quickly and consistently do you handle customer questions and complaints?',
  brand: 'How recognised is your brand in your target market?',
  competitive_position: 'How clearly different and better are you than competitors?',
  cash_flow: 'How comfortable is your cash position month to month?',
  scalability: 'Could you handle double the sales without major problems?',
  risk: 'How protected are you from losing a key supplier, customer or person?',
  expansion_readiness: 'How ready is the business to open a new location, market or channel?',
};

type Ev = { label: string; value: string; basis: Basis | 'self_assessment' };
type Signal = { score: number; weight: number; ev: Ev; strength?: string; weakness?: string };
export type CategoryResult = {
  key: CategoryKey; label: string; score: number | null; basis: 'actual' | 'estimated' | 'mixed' | 'insufficient_data';
  condition: string; evidence: Ev[]; strengths: string[]; weaknesses: string[]; risk: string; recommendation: string; missing: string[];
};

const clamp = (x: number) => Math.max(0, Math.min(100, Math.round(x)));
const scale = (x: number, lo: number, hi: number) => clamp(((x - lo) / (hi - lo)) * 100);
const fmt = (n: number | null, suffix = '') => (n === null ? 'n/a' : `${Math.round(n * 10) / 10}${suffix}`);

export function assessHealth(s: Snapshot, business: any, extra: { goalsBehind?: number; openCriticalRisks?: number; competitorsTracked?: number; activeLocations?: number } = {}) {
  const ind = industryFor(business?.industry_module);
  const answers = (business?.maturity_answers || {}) as Record<string, number>;
  const sig: Record<CategoryKey, Signal[]> = Object.fromEntries(HEALTH_CATEGORIES.map(([k]) => [k, []])) as any;
  const missing: Record<CategoryKey, string[]> = Object.fromEntries(HEALTH_CATEGORIES.map(([k]) => [k, []])) as any;
  const add = (k: CategoryKey, x: Signal) => sig[k].push(x);
  const need = (k: CategoryKey, what: string) => missing[k].push(what);

  // Self-assessment (estimated, low weight relative to data)
  for (const [k] of HEALTH_CATEGORIES) {
    const a = Number(answers[k]);
    if (a >= 1 && a <= 5) add(k, { score: (a - 1) * 25, weight: 0.6, ev: { label: 'Owner self-assessment', value: `${a}/5`, basis: 'self_assessment' } });
  }

  // Sales
  if (s.revenue_change_pct.value !== null) {
    const g = s.revenue_change_pct.value;
    add('sales', { score: scale(g, -30, 30), weight: 1.5, ev: { label: 'Revenue change (30d vs prior 30d)', value: fmt(g, '%'), basis: 'actual' }, strength: g > 5 ? `Sales grew ${fmt(g, '%')} vs the prior 30 days` : undefined, weakness: g < -5 ? `Sales fell ${fmt(-g, '%')} vs the prior 30 days` : undefined });
  } else need('sales', 'At least 60 days of sales records to measure the trend');
  if (s.coverage.sales) add('sales', { score: s.coverage.sales_recent ? 70 : 30, weight: 0.5, ev: { label: 'Sales data up to date', value: s.last_sale_date || 'n/a', basis: 'actual' }, weakness: s.coverage.sales_recent ? undefined : 'No sales recorded in the last 14 days (data may be outdated)' });
  else need('sales', 'Sales records (import CSV or enter manually)');

  // Product
  const prods = s.variants.length ? s.variants : s.products;
  if (prods.some((p) => (p.revenue_90d || 0) > 0)) {
    const growing = prods.filter((p) => p.tags.includes('fast_growing')).length, declining = prods.filter((p) => p.tags.includes('declining')).length;
    add('product', { score: clamp(60 + growing * 8 - declining * 8), weight: 1, ev: { label: 'Growing vs declining items', value: `${growing} growing / ${declining} declining`, basis: 'actual' }, strength: growing ? `${growing} product(s) growing fast` : undefined, weakness: declining ? `${declining} product(s) declining` : undefined });
  } else need('product', 'Product- or shade-level sales');
  const lowMargin = prods.filter((p) => p.tags.includes('low_margin')).length;
  if (prods.some((p) => p.margin_pct !== null)) add('product', { score: clamp(80 - lowMargin * 15), weight: 0.7, ev: { label: 'Low-margin items (<30%)', value: String(lowMargin), basis: 'actual' }, weakness: lowMargin ? `${lowMargin} item(s) earn under 30% margin` : undefined });
  else need('product', 'Unit costs for products/shades');

  // Customers
  if (s.repeat_rate_pct.value !== null) {
    const r = s.repeat_rate_pct.value, tgt = ind.assumptions.repeat_rate_target_pct;
    add('customers', { score: scale(r, 0, tgt * 1.6), weight: 1.5, ev: { label: 'Repeat customer rate', value: fmt(r, '%'), basis: s.repeat_rate_pct.basis! }, strength: r >= tgt ? `Repeat rate ${fmt(r, '%')} meets the platform planning target of ${tgt}% (assumption)` : undefined, weakness: r < tgt ? `Repeat rate ${fmt(r, '%')} is below the ${tgt}% planning target (assumption, not market research)` : undefined });
  } else need('customers', 'Link sales to customers (10+ customers) to measure repeat purchases');
  if (s.top_customer_share_pct.value !== null) {
    const c = s.top_customer_share_pct.value;
    add('risk', { score: scale(60 - c, 0, 50), weight: 1, ev: { label: 'Largest customer share of revenue', value: fmt(c, '%'), basis: 'actual' }, weakness: c > 30 ? `One customer is ${fmt(c, '%')} of revenue` : undefined });
  }

  // Marketing
  const reliable = s.campaigns.filter((c) => c.reliable);
  if (reliable.length) add('marketing', { score: clamp(50 + reliable.filter((c) => (c.roas || 0) >= 2).length * 15), weight: 1, ev: { label: 'Campaigns with trackable results', value: `${reliable.length} (ROAS ≥ 2: ${reliable.filter((c) => (c.roas || 0) >= 2).length})`, basis: 'actual' }, strength: 'Campaign results are tracked with promo codes/UTM' });
  else if (s.campaigns.length) add('marketing', { score: 35, weight: 0.8, ev: { label: 'Campaigns without reliable attribution', value: String(s.campaigns.length), basis: 'actual' }, weakness: 'Campaign results cannot be attributed reliably (add promo codes or UTM tracking)' });
  else need('marketing', 'Marketing campaigns with spend and results');

  // Finance & cash flow
  if (s.gross_margin_pct.value !== null) {
    const gm = s.gross_margin_pct.value, floor = ind.assumptions.gross_margin_floor_pct;
    add('finance', { score: scale(gm, floor - 25, floor + 25), weight: 1.2, ev: { label: 'Gross margin', value: fmt(gm, '%'), basis: s.gross_margin_pct.basis! }, strength: gm >= floor ? `Gross margin ${fmt(gm, '%')}` : undefined, weakness: gm < floor ? `Gross margin ${fmt(gm, '%')} is below the ${floor}% planning floor for ${ind.label} (platform assumption)` : undefined });
  } else need('finance', 'Unit costs or cost of goods to calculate margin');
  if (s.net_profit_monthly.value !== null) {
    const np = s.net_profit_monthly.value, rev = s.revenue_30d.value || 1;
    add('finance', { score: scale((np / rev) * 100, -20, 20), weight: 1, ev: { label: 'Estimated monthly profit', value: fmt(np), basis: s.net_profit_monthly.basis! }, strength: np > 0 ? 'Business is estimated to be profitable' : undefined, weakness: np < 0 ? 'Business is estimated to be losing money each month' : undefined });
  } else need('finance', 'Operating expenses (records or monthly estimate)');
  if (s.runway_months.value !== null || s.runway_months.note === 'positive') {
    const rm = s.runway_months.note === 'positive' ? 24 : s.runway_months.value!;
    add('cash_flow', { score: scale(rm, 1, 12), weight: 1.5, ev: { label: 'Cash runway', value: s.runway_months.note === 'positive' ? 'Cash-flow positive' : `${fmt(rm)} months`, basis: s.cash.basis! }, weakness: rm < 6 ? `Only about ${fmt(rm)} months of cash at the current loss rate` : undefined, strength: rm >= 12 ? 'Comfortable cash position' : undefined });
  } else need('cash_flow', 'Current cash balance and monthly profit/loss');

  // Inventory
  if (s.inventory.length) {
    const risky = s.inventory.filter((i) => i.flags.some((f) => ['out_of_stock', 'stockout_risk', 'low_stock'].includes(f))).length;
    const over = s.inventory.filter((i) => i.flags.includes('overstock') || i.flags.includes('slow_moving')).length;
    add('inventory', { score: clamp(100 - (risky / s.inventory.length) * 120 - (over / s.inventory.length) * 60), weight: 1.5, ev: { label: 'Items at stock-out risk / overstocked', value: `${risky} / ${over} of ${s.inventory.length}`, basis: 'actual' }, weakness: risky ? `${risky} item(s) low or at risk of running out` : undefined, strength: !risky && !over ? 'Stock levels are balanced' : undefined });
  } else need('inventory', 'Inventory counts per product/shade');

  // Operations / scalability
  if (extra.goalsBehind !== undefined && extra.goalsBehind > 0) add('management', { score: clamp(70 - extra.goalsBehind * 15), weight: 0.6, ev: { label: 'Goals behind schedule', value: String(extra.goalsBehind), basis: 'actual' }, weakness: `${extra.goalsBehind} goal(s) behind schedule` });
  if (extra.competitorsTracked) add('competitive_position', { score: 50, weight: 0.2, ev: { label: 'Competitors tracked', value: String(extra.competitorsTracked), basis: 'actual' } });
  else need('competitive_position', 'Add competitors and what you know about them');
  if (extra.openCriticalRisks) add('risk', { score: clamp(60 - extra.openCriticalRisks * 20), weight: 1, ev: { label: 'Open high/critical risks', value: String(extra.openCriticalRisks), basis: 'actual' }, weakness: `${extra.openCriticalRisks} high/critical risk(s) open` });

  const results: CategoryResult[] = HEALTH_CATEGORIES.map(([key, label]) => {
    const list = sig[key];
    if (!list.length) return { key, label, score: null, basis: 'insufficient_data', condition: 'Not enough information to score this area.', evidence: [], strengths: [], weaknesses: [], risk: 'Unknown — not measured.', recommendation: `Provide: ${(missing[key][0] || 'a self-assessment answer in onboarding')}.`, missing: missing[key].length ? missing[key] : ['Self-assessment answer or related records'] };
    const w = list.reduce((a, x) => a + x.weight, 0);
    const score = clamp(list.reduce((a, x) => a + x.score * x.weight, 0) / w);
    const kinds = new Set(list.map((x) => (x.ev.basis === 'actual' ? 'actual' : 'estimated')));
    const basis = kinds.size > 1 ? 'mixed' : kinds.has('actual') ? 'actual' : 'estimated';
    const strengths = list.map((x) => x.strength).filter(Boolean) as string[];
    const weaknesses = list.map((x) => x.weakness).filter(Boolean) as string[];
    const condition = score >= 75 ? 'Strong' : score >= 55 ? 'Stable' : score >= 35 ? 'Needs attention' : 'Weak';
    return {
      key, label, score, basis, condition: `${condition}${basis !== 'actual' ? ' (based partly on estimates)' : ''}`,
      evidence: list.map((x) => x.ev), strengths, weaknesses,
      risk: score < 35 ? 'High — this area could hold back growth.' : score < 55 ? 'Moderate.' : 'Low.',
      recommendation: weaknesses[0] ? `Address: ${weaknesses[0].charAt(0).toLowerCase() + weaknesses[0].slice(1)}.` : missing[key][0] ? `Improve accuracy by adding: ${missing[key][0]}.` : 'Maintain current approach and keep data up to date.',
      missing: missing[key],
    };
  });
  const scored = results.filter((r) => r.score !== null);
  const coverage = Math.round((scored.length / results.length) * 100);
  const overall = scored.length ? Math.round(scored.reduce((a, r) => a + r.score!, 0) / scored.length) : null;
  const overallBasis = !scored.length ? 'insufficient_data' : scored.every((r) => r.basis === 'actual') ? 'actual' : scored.some((r) => r.basis !== 'estimated') ? 'mixed' : 'estimated';
  return {
    overall_score: overall, overall_basis: overallBasis, data_coverage_pct: coverage, preliminary: coverage < 40,
    categories: results, missing_information: [...new Set(results.flatMap((r) => r.missing))],
  };
}
export type Health = ReturnType<typeof assessHealth>;
