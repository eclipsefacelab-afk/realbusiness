// Extension points. Master Prompt 1 runs with these no-op defaults; the Master Prompt 2
// enhancement layer registers itself here (see shared/p2/register.ts) without rewriting core code.
import type { Ctx } from './context.ts';

type ApiExt = (ctx: Ctx, body: any, now: Date) => Promise<any>;
export const extensions = {
  api: {} as Record<string, ApiExt>,
  intelligence: {} as Record<string, ApiExt>,
  afterWrite: async (_ctx: Ctx, _entity: string, _op: 'create' | 'update', _rec: any, _now: Date, _before?: any): Promise<void> => {},
  beforeDelete: async (_ctx: Ctx, _entity: string, _rec: any, _body: any, _now: Date): Promise<any> => null,
  afterOutcome: async (_ctx: Ctx, _rec: any, _body: any, _now: Date): Promise<void> => {},
  beforePermissionChange: async (_ctx: Ctx, _member: any, _role: string, _now: Date): Promise<void> => {},
  afterImport: async (_ctx: Ctx, _entity: string, _count: number, _now: Date): Promise<void> => {},
  llmHooks: (_svc: any, _businessId: string, _user?: any): any => ({}),
};
