// Industry modules. The core engine is common; modules change KPIs, vocabulary, benchmark
// ASSUMPTIONS (never presented as market research) and navigation.
export type IndustryModule = {
  key: string;
  label: string;
  variantLabel: string; // what a product variant is called
  kpis: { key: string; label: string; explain: string }[];
  // Benchmarks are rough planning assumptions supplied by the platform, labelled as such in every output.
  assumptions: { gross_margin_floor_pct: number; healthy_inventory_days_max: number; repeat_rate_target_pct: number };
  hideNav: string[];
  onboardingHints: string[];
  roadmapThemes: string[];
};

const base: IndustryModule = {
  key: 'general', label: 'General business', variantLabel: 'Variant',
  kpis: [
    { key: 'revenue_30d', label: 'Revenue (30 days)', explain: 'Money received from sales in the last 30 days.' },
    { key: 'gross_margin_pct', label: 'Gross margin', explain: 'Share of each sale left after paying for the product itself.' },
    { key: 'repeat_rate_pct', label: 'Repeat customers', explain: 'Share of customers who bought more than once.' },
  ],
  assumptions: { gross_margin_floor_pct: 35, healthy_inventory_days_max: 120, repeat_rate_target_pct: 25 },
  hideNav: [], onboardingHints: [], roadmapThemes: ['Increase repeat purchases', 'Improve margins', 'Strengthen cash position'],
};

export const INDUSTRIES: Record<string, IndustryModule> = {
  general: base,
  cosmetics: {
    ...base, key: 'cosmetics', label: 'Cosmetics (manufacturer + consumer brand)', variantLabel: 'Shade',
    kpis: [
      ...base.kpis,
      { key: 'shade_concentration', label: 'Top-shade concentration', explain: 'How much of your sales come from your top 3 shades. High = production focus is easy, but you depend on few shades.' },
      { key: 'event_conversion', label: 'Event conversion', explain: 'Of the people you met at events, how many became paying customers.' },
      { key: 'sell_through', label: 'Sell-through', explain: 'How quickly produced stock is sold.' },
    ],
    assumptions: { gross_margin_floor_pct: 55, healthy_inventory_days_max: 150, repeat_rate_target_pct: 30 },
    onboardingHints: ['Enter each shade as a product variant so the platform can do shade-level analysis.', 'Record trade shows and pop-ups as Events so customers met there can be followed up.'],
    roadmapThemes: ['Increase brand awareness', 'Convert event customers', 'Build repeat purchases', 'Improve ecommerce', 'Expand retail', 'Improve production planning', 'Expand product range', 'Develop wholesale', 'Strengthen Jamaica operations', 'Strengthen Canada operations', 'Evaluate new locations', 'Evaluate international opportunities'],
  },
  beauty: { ...base, key: 'beauty', label: 'Beauty', variantLabel: 'Shade / size', assumptions: { gross_margin_floor_pct: 50, healthy_inventory_days_max: 150, repeat_rate_target_pct: 30 } },
  retail: { ...base, key: 'retail', label: 'Retail', variantLabel: 'Variant', assumptions: { gross_margin_floor_pct: 30, healthy_inventory_days_max: 120, repeat_rate_target_pct: 25 } },
  manufacturing: { ...base, key: 'manufacturing', label: 'Manufacturing', variantLabel: 'SKU', assumptions: { gross_margin_floor_pct: 25, healthy_inventory_days_max: 90, repeat_rate_target_pct: 40 } },
  distribution: { ...base, key: 'distribution', label: 'Distribution', variantLabel: 'SKU', assumptions: { gross_margin_floor_pct: 15, healthy_inventory_days_max: 60, repeat_rate_target_pct: 50 } },
  restaurant: { ...base, key: 'restaurant', label: 'Restaurant', variantLabel: 'Menu item', hideNav: ['competitors'], assumptions: { gross_margin_floor_pct: 60, healthy_inventory_days_max: 10, repeat_rate_target_pct: 30 } },
  professional_services: { ...base, key: 'professional_services', label: 'Professional services', variantLabel: 'Service package', hideNav: ['inventory'], assumptions: { gross_margin_floor_pct: 40, healthy_inventory_days_max: 0, repeat_rate_target_pct: 50 } },
  construction: { ...base, key: 'construction', label: 'Construction', variantLabel: 'Service', hideNav: ['inventory'], assumptions: { gross_margin_floor_pct: 20, healthy_inventory_days_max: 60, repeat_rate_target_pct: 20 } },
  transportation: { ...base, key: 'transportation', label: 'Transportation', variantLabel: 'Route / service', hideNav: ['inventory'], assumptions: { gross_margin_floor_pct: 20, healthy_inventory_days_max: 30, repeat_rate_target_pct: 50 } },
  ecommerce: { ...base, key: 'ecommerce', label: 'Ecommerce', variantLabel: 'Variant', assumptions: { gross_margin_floor_pct: 40, healthy_inventory_days_max: 120, repeat_rate_target_pct: 25 } },
};

export function industryFor(key?: string | null): IndustryModule {
  return INDUSTRIES[key || 'general'] || base;
}
