// Clearly-labelled SAMPLE data so the interface can be explored before real data is entered.
// Lives in its own business ("… (DEMO DATA)") flagged is_demo — never mixed into a real business.
import { iso, DAY } from './metrics.ts';
import { audit } from './context.ts';

export async function createMany(svc: any, entity: string, rows: any[]) {
  const api = svc.entities[entity];
  const out: any[] = [];
  if (typeof api.bulkCreate === 'function') { for (let i = 0; i < rows.length; i += 400) out.push(...((await api.bulkCreate(rows.slice(i, i + 400))) || [])); return out; }
  for (const r of rows) out.push(await api.create(r));
  return out;
}

function rng(seed: number) { return () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296); }

export async function seedDemoBusiness(svc: any, user: any, now = new Date()) {
  const mine = await svc.entities.BusinessMember.filter({ user_id: user.id, status: 'active' });
  for (const m of mine) { const b = await svc.entities.Business.get(m.business_id).catch(() => null); if (b?.is_demo && b.status !== 'archived') return b; }
  const r = rng(42);
  const D = { is_demo: true };
  const b = await svc.entities.Business.create({ name: 'Sample Cosmetics Co. (DEMO DATA)', industry: 'Cosmetics', industry_module: 'cosmetics', business_type: 'Manufacturer & consumer brand', country: 'Canada', province_state: 'Ontario', city: 'Toronto', year_established: 2022, employees: 6, locations_count: 2, currency: 'CAD', operating_countries: ['Canada', 'Jamaica'], sales_channels: ['ecommerce', 'event', 'wholesale', 'retail'], goals: ['increase_revenue', 'increase_repeat_customers', 'increase_wholesale'], goal_timeframe_months: 12, avg_monthly_revenue: 38000, gross_margin_pct: 62, monthly_operating_expenses: 21000, cash_available: 55000, financials_basis: 'estimated', maturity_answers: { brand: 3, technology: 2, management: 2, employees: 3, customer_service: 4, operations: 3, scalability: 2, expansion_readiness: 2 }, owner_user_id: user.id, status: 'active', plan_key: 'trial', onboarding_complete: true, is_demo: true });
  const B = { business_id: b.id, ...D };
  await svc.entities.BusinessMember.create({ business_id: b.id, user_id: user.id, user_email: String(user.email || '').toLowerCase(), role: 'owner', status: 'active', is_demo: true });
  const ca = await svc.entities.BusinessLocation.create({ ...B, name: 'Canada (Toronto)', kind: 'production', country: 'Canada', status: 'active' });
  const jm = await svc.entities.BusinessLocation.create({ ...B, name: 'Jamaica (Kingston)', kind: 'market', country: 'Jamaica', status: 'active' });
  const online = await svc.entities.BusinessLocation.create({ ...B, name: 'Online store', kind: 'online', country: 'Canada', status: 'active' });
  const catalog = [
    { name: 'Sample Silk Foundation', price: 42, cost: 11, shades: ['Ivory 110', 'Sand 220', 'Honey 330', 'Caramel 440', 'Cocoa 550', 'Espresso 660', 'Ebony 770'], w: [0.5, 0.8, 1.2, 1.6, 1.9, 1.4, 0.9] },
    { name: 'Sample Velvet Lipstick', price: 24, cost: 5, shades: ['Rose', 'Berry', 'Brick', 'Nude'], w: [1, 1.3, 0.6, 1.1] },
    { name: 'Sample Brow Pencil', price: 18, cost: 4, shades: ['Soft Brown', 'Dark Brown', 'Black'], w: [0.8, 1, 0.7] },
  ];
  const variants: any[] = [];
  for (const p of catalog) {
    const prod = await svc.entities.Product.create({ ...B, name: p.name, price: p.price, unit_cost: p.cost, status: 'active', strategic_role: p.name.includes('Foundation') ? 'hero' : 'core', category: p.name.split(' ').slice(-1)[0] });
    for (let i = 0; i < p.shades.length; i++) {
      const v = await svc.entities.ProductVariant.create({ ...B, product_id: prod.id, name: p.shades[i], shade_name: p.shades[i], price: p.price, unit_cost: p.cost, status: 'active' });
      variants.push({ ...v, product_id: prod.id, price: p.price, cost: p.cost, w: p.w[i] });
    }
  }
  const custRows: any[] = [];
  for (let i = 1; i <= 320; i++) custRows.push(({ ...B, display_name: `Sample Customer ${String(i).padStart(3, '0')}`, type: i <= 3 ? 'wholesale' : 'consumer', country: i % 4 === 0 ? 'Jamaica' : 'Canada', marketing_consent: i % 3 !== 0 }));
  const customers = await createMany(svc, 'Customer', custRows);
  const event = await svc.entities.Event.create({ ...B, name: 'Sample Beauty Expo', kind: 'trade_show', start_date: iso(new Date(now.getTime() - 20 * DAY)), end_date: iso(new Date(now.getTime() - 19 * DAY)), location_text: 'Toronto', country: 'Canada', cost: 3500, status: 'completed' });
  await svc.entities.EventResult.create({ ...B, event_id: event.id, visitors: 420, leads: 85, customers: 31, sales_revenue: 4380, units_sold: 142, customer_feedback: 'Strong interest in deeper foundation shades; requests for a travel size.' });
  const ch = await svc.entities.MarketingChannel.create({ ...B, name: 'Instagram ads', kind: 'paid_ads', monthly_budget: 1200, status: 'active' });
  await svc.entities.MarketingCampaign.create({ ...B, name: 'Sample Spring shade launch', channel_id: ch.id, start_date: iso(new Date(now.getTime() - 70 * DAY)), end_date: iso(new Date(now.getTime() - 40 * DAY)), spend: 1800, customers_acquired: 24, attributed_revenue: 3900, attribution_method: 'promo_code', status: 'completed' });
  await svc.entities.MarketingCampaign.create({ ...B, name: 'Sample Influencer collab', channel_id: ch.id, start_date: iso(new Date(now.getTime() - 35 * DAY)), spend: 2500, customers_acquired: 14, attributed_revenue: 2100, attribution_method: 'promo_code', status: 'completed' });
  await svc.entities.MarketingCampaign.create({ ...B, name: 'Sample Boosted posts', channel_id: ch.id, start_date: iso(new Date(now.getTime() - 25 * DAY)), spend: 900, attribution_method: 'none', status: 'active' });
  // ~180 days of shade-level sales with growth in deeper foundation shades
  const channels = ['ecommerce', 'ecommerce', 'retail', 'event', 'wholesale'];
  let orderNo = 1000;
  const saleRows: any[] = [];
  for (let day = 180; day >= 1; day--) {
    const date = iso(new Date(now.getTime() - day * DAY));
    const orders = Math.round(4 + r() * 6 + (180 - day) / 40);
    for (let o = 0; o < orders; o++) {
      const cust = r() < 0.04 ? customers[Math.floor(r() * 3)] : customers[3 + Math.floor(Math.pow(r(), 1.8) * (customers.length - 3))];
      const channel = cust.type === 'wholesale' ? 'wholesale' : channels[Math.floor(r() * 4)];
      const lines = 1 + Math.floor(r() * 2);
      for (let l = 0; l < lines; l++) {
        const pickW = r() * variants.reduce((t, v) => t + v.w * (v.shade_name?.match(/Cocoa|Espresso|Caramel/) && day < 60 ? 1.8 : 1), 0);
        let acc = 0, v = variants[0];
        for (const x of variants) { acc += x.w * (x.shade_name?.match(/Cocoa|Espresso|Caramel/) && day < 60 ? 1.8 : 1); if (acc >= pickW) { v = x; break; } }
        const qty = channel === 'wholesale' ? 6 + Math.floor(r() * 12) : 1;
        const price = channel === 'wholesale' ? Math.round(v.price * 0.55) : v.price;
        saleRows.push({ ...B, date, order_id: `S-${orderNo}`, product_id: v.product_id, variant_id: v.id, customer_id: cust.id, quantity: qty, unit_price: price, revenue: qty * price, unit_cost: v.cost, channel, location_id: cust.country === 'Jamaica' ? jm.id : channel === 'ecommerce' ? online.id : ca.id, currency: 'CAD', source: 'demo', event_id: day >= 19 && day <= 20 && channel === 'event' ? event.id : undefined });
      }
      orderNo++;
    }
  }
  await createMany(svc, 'Sale', saleRows);
  for (const v of variants) await svc.entities.InventoryItem.create({ ...B, product_id: v.product_id, variant_id: v.id, location_id: ca.id, on_hand: Math.round(20 + r() * 220 * (v.shade_name?.match(/Ivory|Nude|Black/) ? 3 : v.shade_name?.match(/Cocoa|Espresso/) ? 0.2 : 1)), reorder_point: 40, lead_time_days: 21, unit_cost: v.cost, last_counted: iso(now) });
  const months = [5, 4, 3, 2, 1];
  for (const mo of months) {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - mo, 1));
    for (const [cat, amt, type] of [['rent', 3200, 'fixed'], ['payroll', 12500, 'fixed'], ['marketing', 1800, 'variable'], ['software', 450, 'fixed'], ['shipping', 1400, 'variable'], ['packaging', 2100, 'variable']] as const)
      await svc.entities.Expense.create({ ...B, date: iso(d), category: cat, amount: amt + Math.round(r() * amt * 0.1), cost_type: type, data_basis: 'actual', source: 'demo', recurring: type === 'fixed' });
  }
  await svc.entities.FinancialMetric.create({ ...B, period_start: iso(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 1))), period_end: iso(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 0))), period_type: 'month', cash_balance: 48500, accounts_receivable: 6200, accounts_payable: 4100, data_basis: 'actual', source: 'demo' });
  await svc.entities.BusinessGoal.create({ ...B, title: 'Reach $60,000 monthly revenue', category: 'revenue', metric_key: 'revenue_30d', unit: 'CAD', start_value: 30000, target_value: 60000, current_value: 30000, start_date: iso(new Date(now.getTime() - 90 * DAY)), deadline: iso(new Date(now.getTime() + 270 * DAY)) });
  await svc.entities.BusinessGoal.create({ ...B, title: 'Repeat customers to 35%', category: 'repeat_customers', metric_key: 'repeat_rate_pct', unit: '%', start_value: 20, target_value: 35, current_value: 20, start_date: iso(new Date(now.getTime() - 60 * DAY)), deadline: iso(new Date(now.getTime() + 120 * DAY)) });
  await svc.entities.Competitor.create({ ...B, name: 'Sample Competitor Beauty', positioning: 'Mass-market inclusive shades', price_range: '$$', facts: [{ fact: 'Sells 40 foundation shades', verified: false, source: 'Owner note (unverified)', date: iso(now) }] });
  await audit({ svc, businessId: b.id, user }, 'demo.load', 'Business', b.id, 'Loaded clearly-labelled sample data');
  return b;
}
