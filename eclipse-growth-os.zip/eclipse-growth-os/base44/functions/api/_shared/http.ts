// Uniform JSON responses and error handling for backend functions.
import { HttpError } from './context.ts';

export async function respond(req: Request, fn: (body: any) => Promise<any>): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204 });
  let body: any = {};
  try { body = await req.json(); } catch { body = {}; }
  try {
    const out = await fn(body);
    return Response.json(out ?? {});
  } catch (e: any) {
    if (e instanceof HttpError) return Response.json({ error: e.message, details: e.details ?? null }, { status: e.status });
    console.error('Unhandled error', e);
    return Response.json({ error: 'Something went wrong on the server. The error was logged; please try again.' }, { status: 500 });
  }
}
