// Dynamic growth-stage classification from evidence. Re-run whenever data changes.
import type { Snapshot } from './metrics.ts';

export const STAGES = ['idea', 'startup', 'validation', 'early_revenue', 'early_growth', 'scaling', 'expansion', 'multi_location', 'mature', 'international_expansion'] as const;
export const STAGE_LABELS: Record<string, string> = {
  idea: 'Idea', startup: 'Startup', validation: 'Validation', early_revenue: 'Early Revenue', early_growth: 'Early Growth', scaling: 'Scaling',
  expansion: 'Expansion', multi_location: 'Multi-location', mature: 'Mature', international_expansion: 'International Expansion',
};
export const STAGE_FOCUS: Record<string, string> = {
  idea: 'Prove that people want the product before spending heavily.',
  startup: 'Get the first paying customers and learn what they value.',
  validation: 'Show that customers buy again and that each sale makes money.',
  early_revenue: 'Make sales predictable and track the numbers that matter.',
  early_growth: 'Double down on what sells; build repeat purchases and systems.',
  scaling: 'Grow without breaking operations, cash or quality.',
  expansion: 'Add markets/channels one at a time with clear break-even targets.',
  multi_location: 'Standardise operations and compare locations.',
  mature: 'Protect margins, renew products and look for the next growth curve.',
  international_expansion: 'Manage country-level risk, compliance and logistics.',
};

export function classifyStage(s: Snapshot, business: any, extra: { activeRetailLocations?: number; countries?: number; growthMonths?: number[] } = {}) {
  const rev = s.revenue_monthly_avg_90d.value ?? s.revenue_30d.value;
  const basis = s.revenue_monthly_avg_90d.value !== null ? 'actual' : s.revenue_30d.basis;
  const g = s.revenue_change_pct.value;
  const countries = extra.countries ?? (business?.operating_countries?.length || 1);
  const retail = extra.activeRetailLocations ?? 0;
  const hasProducts = (s.products?.length || 0) > 0 || !!business?.products_services;
  const signals: Record<string, any> = { monthly_revenue: rev, revenue_basis: basis, growth_30d_pct: g, sales_history_days: s.history_days, countries, active_retail_locations: retail, repeat_rate_pct: s.repeat_rate_pct.value };
  const notes: string[] = [];
  let stage: string;

  if (!rev && !hasProducts) stage = 'idea';
  else if (!rev) stage = 'startup';
  else if (rev < 3000 || (s.coverage.sales && s.history_days < 90 && rev < 15000)) stage = 'validation';
  else if (rev >= 400000 && g !== null && g > -3 && g < 3) stage = 'mature';
  else if (rev >= 100000 && countries >= 2) stage = 'international_expansion';
  else if (rev >= 100000 && retail >= 3) stage = 'multi_location';
  else if (rev >= 80000 && (retail >= 2 || countries >= 2)) stage = 'expansion';
  else if (rev >= 50000 && (g === null || g >= 5)) stage = 'scaling';
  else if (rev >= 15000 && (g === null || g >= 3)) stage = 'early_growth';
  else stage = 'early_revenue';

  if (countries >= 2 && !['international_expansion', 'expansion'].includes(stage)) notes.push(`Operates in ${countries} countries; revenue level does not yet indicate an international-expansion stage.`);
  if (g === null) notes.push('Growth trend not measured yet (needs 60+ days of sales records).');
  const reason = `Monthly revenue ≈ ${rev ? Math.round(rev).toLocaleString() : '0'} (${basis || 'no data'})${g !== null ? `, 30-day trend ${Math.round(g)}%` : ''}. ${notes.join(' ')}`.trim();
  return { stage, label: STAGE_LABELS[stage], focus: STAGE_FOCUS[stage], reason, signals, confidence: basis === 'actual' && g !== null ? 'high' : basis ? 'moderate' : 'low' };
}
