// Request context: authentication, tenant membership, role checks, audit logging and scoped data loading.
// SECURITY MODEL: entities deny direct client access (RLS false). Backend functions use the service
// role, so EVERY query here is filtered by business_id after the caller's membership is verified.
import { can, type Role, type Resource, type Action, maskRecord, ENTITY_RESOURCE } from './permissions.ts';
import type { BusinessData } from './metrics.ts';

export class HttpError extends Error { constructor(public status: number, message: string, public details?: any) { super(message); } }

export type Ctx = { svc: any; user: any; businessId: string; role: Role; member: any; business: any };

export async function requireUser(client: any) {
  let user: any = null;
  try { user = await client.auth.me(); } catch { user = null; }
  if (!user) throw new HttpError(401, 'Please sign in.');
  return user;
}

export async function membershipsFor(svc: any, user: any) {
  const byId = await svc.entities.BusinessMember.filter({ user_id: user.id, status: 'active' });
  // Invitations are matched by email until the invitee signs in for the first time.
  const byEmail = user.email ? await svc.entities.BusinessMember.filter({ user_email: String(user.email).toLowerCase(), status: 'invited' }) : [];
  for (const inv of byEmail) {
    await svc.entities.BusinessMember.update(inv.id, { user_id: user.id, status: 'active' });
    inv.user_id = user.id; inv.status = 'active';
  }
  return [...byId, ...byEmail.filter((x: any) => !byId.some((y: any) => y.id === x.id))];
}

export async function tenantContext(svc: any, user: any, businessId: string | undefined): Promise<Ctx> {
  if (!businessId || typeof businessId !== 'string') throw new HttpError(400, 'business_id is required.');
  const members = await svc.entities.BusinessMember.filter({ business_id: businessId, user_id: user.id, status: 'active' });
  const member = members[0];
  if (!member) throw new HttpError(403, 'You do not have access to this business.');
  const business = await svc.entities.Business.get(businessId).catch(() => null);
  if (!business || business.status === 'archived') throw new HttpError(404, 'Business not found.');
  return { svc, user, businessId, role: member.role as Role, member, business };
}

export function assertCan(ctx: Ctx, resource: Resource, action: Action) {
  if (!can(ctx.role, resource, action)) throw new HttpError(403, `Your role (${ctx.role}) does not allow ${action} on ${resource}.`);
}

export async function audit(ctx: Pick<Ctx, 'svc' | 'businessId' | 'user'>, action: string, entity: string, record_id: string | null, summary: string, before?: any, after?: any, actor_type: 'user' | 'ai' | 'system' = 'user') {
  try {
    await ctx.svc.entities.AuditLog.create({ business_id: ctx.businessId, actor_user_id: ctx.user?.id || null, actor_email: ctx.user?.email || null, actor_type, action, entity, record_id, summary: String(summary).slice(0, 2000), before: before ? slim(before) : undefined, after: after ? slim(after) : undefined });
  } catch (e) { console.error('audit failed', e); }
}
function slim(o: any) { const s = JSON.stringify(o); return s.length > 8000 ? { truncated: true, preview: s.slice(0, 8000) } : o; }

const LIMIT = 5000;
async function scoped(svc: any, entity: string, businessId: string, sort = '-created_date') {
  try { return await svc.entities[entity].filter({ business_id: businessId }, sort, LIMIT); } catch { return []; }
}

// Loads business data, restricted to the resources the caller's role can read.
export async function loadBusinessData(svc: any, businessId: string, role: Role | 'system'): Promise<BusinessData & { allowed: Record<string, boolean> }> {
  const ok = (e: string) => role === 'system' || can(role as Role, ENTITY_RESOURCE[e], 'read');
  const get = (e: string, sort?: string) => (ok(e) ? scoped(svc, e, businessId, sort) : Promise.resolve([]));
  const [business, sales, orders, products, variants, customers, inventory, expenses, financials, campaigns, channels, events, eventResults, goals, tasks, locations, recommendations, competitors, risks, decisions] = await Promise.all([
    svc.entities.Business.get(businessId), get('Sale', '-date'), get('Order', '-date'), get('Product'), get('ProductVariant'), get('Customer'), get('InventoryItem'),
    get('Expense', '-date'), get('FinancialMetric', '-period_start'), get('MarketingCampaign'), get('MarketingChannel'), get('Event', '-start_date'), get('EventResult'),
    get('BusinessGoal'), get('Task'), get('BusinessLocation'), get('Recommendation'), get('Competitor'), get('Risk'), get('Decision'),
  ]);
  const data: any = { business: { ...(business || {}) }, sales, orders, products, variants, customers: role === 'system' ? customers : customers.map((c: any) => maskRecord('Customer', c, role as Role)), inventory, expenses, financials, campaigns, channels, events, eventResults, goals, tasks, locations, recommendations, competitors, risks, decisions };
  if (svc.entities.ProductionRun) {
    const [productionRuns, invoices, suppliers, purchaseOrders] = await Promise.all([get('ProductionRun'), get('Invoice'), get('Supplier'), get('PurchaseOrder')]);
    Object.assign(data, { productionRuns, invoices, suppliers, purchaseOrders });
  }
  // Owner-entered financial estimates on the Business record are finance data too.
  if (role !== 'system' && !can(role as Role, 'finance', 'read')) {
    for (const k of ['avg_monthly_revenue', 'gross_margin_pct', 'monthly_operating_expenses', 'cash_available', 'debt', 'est_customer_acquisition_cost', 'major_recurring_expenses', 'other_financials']) delete data.business[k];
  }
  data.allowed = Object.fromEntries(Object.keys(ENTITY_RESOURCE).map((e) => [e, ok(e)]));
  return data;
}
