// Master Prompt 2 enhancement layer: registers into the Prompt 1 extension points.
import { extensions } from '../extensions.ts';
import { monitorExt, runBasicMonitoring } from '../monitor-handler.ts';
import { HttpError, assertCan, audit, loadBusinessData, type Ctx } from '../context.ts';
import { can } from '../permissions.ts';
import { ENTITY_REGISTRY } from '../entity-registry.ts';
import { analyze, persistAnalysis, syncRecommendations, redactAnalysis, advisorContext, weeklyReview, periodSummary } from '../services.ts';
import { callLLM, collectNumbers, ungroundedNumbers, fenceUntrusted } from '../llm.ts';
import { iso, DAY, computeSnapshot, monthlySeries } from '../metrics.ts';
import { getSettings, DEFAULT_SETTINGS, AGENT_KEYS, sevRank } from './settings.ts';
import { usageHooks, summariseUsage } from './usage.ts';
import { detectExceptions, upsertAlerts, detectOpportunities, upsertOpportunities, runMonitoringFor, DETECTORS_FOR_ENTITY } from './exceptions.ts';
import { buildForecasts, compareForecastActuals, simulate, SCENARIO_KINDS, expansionReadiness } from './predict.ts';
import { orchestrate, AGENTS, routeQuestion } from './agents.ts';
import { runWorkflow, decideApproval, createApproval, WORKFLOWS } from './workflows.ts';

extensions.llmHooks = (svc, businessId, user) => usageHooks(svc, businessId, user);

// ── Business intelligence memory (Section 4)
async function remember(svc: any, businessId: string, kind: string, content: string, source: string, source_id: string, as_of = iso(new Date())) {
  const ex = await svc.entities.ContextMemory.filter({ business_id: businessId, source_id });
  if (ex[0]) return svc.entities.ContextMemory.update(ex[0].id, { content, as_of_date: as_of, status: 'current' });
  return svc.entities.ContextMemory.create({ business_id: businessId, kind, content, source, source_id, as_of_date: as_of, status: 'current' });
}
async function memoryFor(svc: any, businessId: string, now: Date) {
  const rows = await svc.entities.ContextMemory.filter({ business_id: businessId }, '-as_of_date', 200).catch(() => []);
  return rows.filter((m: any) => !['retracted', 'corrected'].includes(m.status) && (!m.valid_until || m.valid_until >= iso(now))).slice(0, 40).map((m: any) => {
    const age = m.as_of_date ? (now.getTime() - new Date(m.as_of_date).getTime()) / DAY : null;
    return { kind: m.kind, fact: m.content, as_of: m.as_of_date, status: m.status === 'historical' || (age !== null && age > 180) ? 'historical — verify before treating as current' : 'current' };
  });
}

// ── Shared, permission-filtered context for agents
async function agentContext(ctx: Ctx, now: Date) {
  const a = await analyze(ctx.svc, ctx.businessId, now);
  const red = redactAnalysis(a, ctx.role);
  const recs = can(ctx.role, 'strategy', 'read') ? await ctx.svc.entities.Recommendation.filter({ business_id: ctx.businessId }, '-priority_score', 50) : [];
  const docs = can(ctx.role, 'documents', 'read') ? (await ctx.svc.entities.Document.filter({ business_id: ctx.businessId }, '-created_date', 20)).filter((d: any) => d.extracted_summary && (d.visibility !== 'finance' || can(ctx.role, 'finance', 'read'))) : [];
  const base: any = advisorContext(red, recs, docs);
  const fin = can(ctx.role, 'finance', 'read');
  const f = buildForecasts(a.data, now);
  base.forecast = { revenue: f.revenue, cash: fin ? f.cash : { ok: false, reason: 'Restricted for your role' }, expenses: fin ? f.expenses : null, demand: can(ctx.role, 'inventory', 'read') ? f.demand : [], customer_behaviour: can(ctx.role, 'customers', 'read') ? f.customer_behaviour : null };
  base.alerts = (await ctx.svc.entities.Alert.filter({ business_id: ctx.businessId, status: 'open' }, '-created_date', 50)).filter((x: any) => fin || x.business_area !== 'Finance').map((x: any) => ({ severity: x.severity, title: x.title, area: x.business_area, what: x.what_happened }));
  base.opportunities = (await ctx.svc.entities.Opportunity.filter({ business_id: ctx.businessId, status: 'open' }, '-rank_score', 10)).map((o: any) => ({ title: o.title, value: o.estimated_value, basis: o.value_basis, confidence: o.confidence }));
  base.production = can(ctx.role, 'operations', 'read') ? (a.data.productionRuns || []).slice(0, 20).map((p: any) => ({ batch: p.batch_number, status: p.status, planned: p.planned_date, completed: p.completed_date, qty: p.produced_qty, cost_per_unit: p.produced_qty ? Math.round(((p.material_cost || 0) + (p.labor_cost || 0) + (p.overhead_cost || 0)) / p.produced_qty * 100) / 100 : null })) : [];
  base.suppliers = can(ctx.role, 'operations', 'read') ? (a.data.suppliers || []).map((s: any) => ({ name: s.name, lead_time_days: s.lead_time_days, reliability: s.reliability_score })) : [];
  base.expansion = fin ? expansionReadiness(a.data, now, a.health.overall_score) : null;
  base.goals = (a.data.goals || []).map((g: any) => ({ title: g.title, status: g.status, progress_pct: g.progress_pct }));
  base.top_customer_share = red.snapshot.top_customer_share_pct;
  base.memory = await memoryFor(ctx.svc, ctx.businessId, now);
  return { a, red, context: base };
}

// ── Reports & briefings (Sections 23–25)
const REPORT_TITLES: Record<string, string> = { daily: 'Daily Performance', quarterly_growth: 'Quarterly Growth Report', financial_overview: 'Financial Overview', marketing: 'Marketing Report', product: 'Product Report', inventory: 'Inventory Report', expansion: 'Expansion Analysis', competitor: 'Competitor Report', risk: 'Risk Report', sales: 'Sales Performance Report', manufacturing: 'Manufacturing Report', briefing: 'Management Briefing', operations_risk: 'Operational Risk Report', forecast: 'Forecast Report', six_month_plan: '6-Month Plan' };
const REPORT_PERM: Record<string, [string, string]> = { financial_overview: ['finance', 'read'], quarterly_growth: ['finance', 'read'], marketing: ['marketing', 'read'], product: ['products', 'read'], inventory: ['inventory', 'read'], expansion: ['finance', 'read'], competitor: ['competitors', 'read'], risk: ['strategy', 'read'], sales: ['sales', 'read'], manufacturing: ['operations', 'read'], briefing: ['strategy', 'read'], daily: ['sales', 'read'], operations_risk: ['operations', 'read'], forecast: ['strategy', 'read'], six_month_plan: ['strategy', 'write'] };

async function generateReport(ctx: Ctx, kind: string, now: Date) {
  const perm = REPORT_PERM[kind]; if (!perm) throw new HttpError(400, 'Unknown report type');
  assertCan(ctx, perm[0] as any, perm[1] as any); assertCan(ctx, 'reports', 'write');
  const { a, red, context } = await agentContext(ctx, now);
  const s: any = red.snapshot, cur = a.data.business.currency || '';
  const days = kind === 'daily' ? 1 : kind === 'quarterly_growth' ? 90 : kind === 'briefing' ? 7 : 30;
  const start = new Date(now.getTime() - days * DAY);
  const per = periodSummary(a, start, now);
  const m = (x: any) => (x?.value === null || x?.value === undefined ? 'n/a' : `${Math.round(x.value * 100) / 100} (${x.basis})`);
  const lines = (arr: any[], fn: (x: any) => string) => arr.map(fn);
  const S: [string, string | string[]][] = [['Key figures', [`Revenue last ${days} day(s): ${cur} ${per.revenue ?? 0} (actual) vs ${per.prev_revenue ?? 0} previous${per.change_pct !== null ? ` (${per.change_pct}%)` : ''}`, `Revenue 30d: ${m(s.revenue_30d)}`, ...(can(ctx.role, 'finance', 'read') ? [`Gross margin: ${m(s.gross_margin_pct)}`, `Est. monthly profit: ${m(s.net_profit_monthly)}`, `Cash: ${m(s.cash)}`] : [])]]];
  if (['sales', 'daily', 'quarterly_growth', 'product', 'briefing'].includes(kind)) S.push(['Products & shades', lines((s.variants.length ? s.variants : s.products).slice(0, 10), (p) => `${p.name}: ${p.units_30d} units (30d), growth ${p.growth_pct ?? 'n/a'}%, ${p.tags.join(', ') || '—'}`)], ['Channels (90d)', lines(s.channels, (c) => `${c.key}: ${c.revenue} (${c.share_pct}%)`)]);
  if (['inventory', 'operations_risk', 'briefing', 'manufacturing'].includes(kind)) S.push(['Inventory alerts', lines(s.inventory.filter((i: any) => i.flags.length), (i) => `${i.name}: ${i.on_hand} on hand, ${i.days_of_cover ?? 'n/a'} days left (forecast) — ${i.flags.join(', ')}`)]);
  if (['manufacturing', 'operations_risk'].includes(kind)) S.push(['Production', lines(context.production, (p: any) => `${p.batch || 'batch'}: ${p.status}, ${p.qty ?? '—'} units, cost/unit ${p.cost_per_unit ?? 'n/a'}`)]);
  if (['marketing', 'quarterly_growth'].includes(kind)) S.push(['Campaigns', lines(s.campaigns, (c) => `${c.name}: spend ${c.spend}, ${c.reliable ? `CPA ${c.cpa}, ROAS ${c.roas}` : 'not attributable (no tracking)'}`)], ['Events', lines(s.events, (e) => `${e.name}: cost ${e.cost ?? 'n/a'}, sales ${e.revenue ?? 'n/a'}, leads ${e.leads ?? 'n/a'}`)]);
  if (['financial_overview', 'quarterly_growth', 'forecast'].includes(kind)) { const f = context.forecast; S.push(['Forecast (not guaranteed)', f.revenue.ok ? lines(f.revenue.expected, (x: any) => `${x.period}: expected revenue ${x.value}`) : [f.revenue.reason], ], ['Cash outlook (forecast)', f.cash?.ok ? [...lines(f.cash.expected.slice(0, 6), (x: any) => `${x.period}: ${x.value}`), f.cash.warning || 'No negative cash in the conservative case.'] : [f.cash?.reason || 'n/a']]); }
  if (['risk', 'operations_risk', 'briefing'].includes(kind)) S.push(['Open alerts', lines(context.alerts, (x: any) => `[${x.severity}] ${x.title}`)]);
  if (['expansion'].includes(kind)) S.push(['Expansion readiness', [context.expansion?.message, ...(context.expansion?.checks || []).map((c: any) => `${c.pass === null ? '?' : c.pass ? '✓' : '✗'} ${c.label} — ${c.detail}`)]]);
  if (kind === 'competitor') S.push(['Competitors', lines(a.data.competitors || [], (c: any) => `${c.name}: ${(c.facts || []).filter((f: any) => f.verified).length} verified fact(s), ${(c.facts || []).filter((f: any) => !f.verified).length} unverified; ${c.positioning || ''}`)]);
  S.push(['Opportunities', lines(context.opportunities, (o: any) => `${o.title}${o.value ? ` (≈${o.value}, ${o.basis})` : ''}`)], ['Recommendations', lines(context.open_recommendations || [], (r: any) => `[${r.priority}] ${r.title}`)], ['Unresolved issues / data limitations', lines(red.missing, (x: any) => `${x.area}: ${x.what}`)]);
  let narrative: string | null = null, status: 'complete' | 'partial' = 'complete', error: string | null = null;
  const ai = await callLLM<{ what_happened: string; what_changed: string; why: string; at_risk: string; opportunities: string; needs_attention: string; next: string }>(ctx.svc, { purpose: `report_${kind}`, agent_key: 'cbio', tier: 'routine', schema: { type: 'object', required: ['what_happened', 'what_changed', 'why', 'at_risk', 'opportunities', 'needs_attention', 'next'], properties: Object.fromEntries(['what_happened', 'what_changed', 'why', 'at_risk', 'opportunities', 'needs_attention', 'next'].map((k) => [k, { type: 'string' }])) }, prompt: `Write the executive briefing for a ${REPORT_TITLES[kind]} using ONLY these sections. One or two sentences per field. Say "not enough data" where applicable.\nDATA:\n${JSON.stringify(S)}` }, extensions.llmHooks(ctx.svc, ctx.businessId, ctx.user));
  if (ai.ok) { const bad = ungroundedNumbers(Object.values(ai.data).join(' '), collectNumbers(S)); if (bad.length) { status = 'partial'; error = 'AI briefing discarded because it contained figures not traceable to the data.'; } else narrative = [['What happened?', ai.data.what_happened], ['What changed?', ai.data.what_changed], ['Why did it change?', ai.data.why], ['What is at risk?', ai.data.at_risk], ['What opportunities exist?', ai.data.opportunities], ['What needs management attention?', ai.data.needs_attention], ['What should happen next?', ai.data.next]].map(([h, b]) => `**${h}** ${b}`).join('\n\n'); }
  else { status = 'partial'; error = `AI briefing unavailable (${ai.error}); data sections are complete.`; }
  const title = `${REPORT_TITLES[kind]} — ${a.data.business.name} (${iso(start)} to ${iso(now)})`;
  const md = `# ${title}\n\n${narrative ? `## Executive briefing (AI-written from the data below)\n\n${narrative}\n\n` : ''}` + S.map(([h, b]) => `## ${h}\n\n${Array.isArray(b) ? (b.filter(Boolean).length ? b.filter(Boolean).map((x) => `- ${x}`).join('\n') : '_Nothing to report._') : b}`).join('\n\n') + `\n\n> Estimates and forecasts are labelled; this is not an audited financial statement.${error ? `\n\n> Note: ${error}` : ''}`;
  return ctx.svc.entities.Report.create({ business_id: ctx.businessId, kind, title, period_start: iso(start), period_end: iso(now), content_md: md, payload: { sections: S }, data_limitations: red.missing.map((x: any) => `${x.area}: ${x.what}`), status, error, generated_by: ctx.user?.email || 'system', generated_at: now.toISOString() });
}

// ── API extensions (admin, alerts, approvals, memory)
const ADMIN_SETTING_KEYS = Object.keys(DEFAULT_SETTINGS);
extensions.api['settings.get'] = async (ctx) => { assertCan(ctx, 'settings', 'read'); return { settings: await getSettings(ctx.svc, ctx.businessId), agents: AGENTS.map((a) => ({ key: a.key, name: a.name, focus: a.focus })), workflows: WORKFLOWS }; };
extensions.api['settings.update'] = async (ctx, body) => {
  assertCan(ctx, 'settings', 'admin');
  const cur = await getSettings(ctx.svc, ctx.businessId);
  const data = Object.fromEntries(Object.entries(body.data || {}).filter(([k]) => ADMIN_SETTING_KEYS.includes(k)));
  if ('ai_monthly_request_cap' in data && (Number(data.ai_monthly_request_cap) < 0 || !isFinite(Number(data.ai_monthly_request_cap)))) throw new HttpError(422, 'Invalid AI cap');
  if (data.workflow_modes) for (const [k, v] of Object.entries(data.workflow_modes as any)) if (WORKFLOWS[k]?.consequential && v === 'automatic') throw new HttpError(422, `${WORKFLOWS[k].label} involves external or financial actions and always requires approval.`);
  if (data.agents_enabled) for (const k of Object.keys(data.agents_enabled as any)) if (!(AGENT_KEYS as readonly string[]).includes(k)) throw new HttpError(422, `Unknown agent ${k}`);
  await ctx.svc.entities.BusinessSettings.update(cur.id, data);
  await audit(ctx, 'settings.update', 'BusinessSettings', cur.id, `Changed: ${Object.keys(data).join(', ')}`, Object.fromEntries(Object.keys(data).map((k) => [k, (cur as any)[k]])), data);
  return { settings: await getSettings(ctx.svc, ctx.businessId) };
};
extensions.api['alert.update'] = async (ctx, body, now) => {
  assertCan(ctx, 'alerts', 'write');
  const al = await ctx.svc.entities.Alert.get(body.id).catch(() => null);
  if (!al || al.business_id !== ctx.businessId) throw new HttpError(404, 'Alert not found');
  const u: any = {};
  if (body.op === 'acknowledge') u.status = 'acknowledged';
  else if (body.op === 'assign') { u.status = 'assigned'; u.assigned_to = String(body.assigned_to || ''); }
  else if (body.op === 'annotate') u.notes = [...(al.notes || []), { by: ctx.user.email, at: now.toISOString(), text: String(body.text || '').slice(0, 2000) }];
  else if (body.op === 'close') { u.status = 'closed'; u.closed_at = now.toISOString(); u.resolution = String(body.resolution || 'Closed by user'); }
  else throw new HttpError(422, 'op must be acknowledge, assign, annotate or close');
  await ctx.svc.entities.Alert.update(al.id, u);
  await audit(ctx, `alert.${body.op}`, 'Alert', al.id, `${al.title}: ${body.op}`);
  return { ok: true };
};
extensions.api['approval.decide'] = async (ctx, body, now) => decideApproval(ctx, body.id, body.decision, body.note || '', now);
extensions.api['memory.correct'] = async (ctx, body, now) => {
  if (!['owner', 'admin'].includes(ctx.role)) throw new HttpError(403, 'Only owners and administrators can correct AI memory.');
  const m = await ctx.svc.entities.ContextMemory.get(body.id).catch(() => null);
  if (!m || m.business_id !== ctx.businessId) throw new HttpError(404, 'Not found');
  if (body.op === 'retract') await ctx.svc.entities.ContextMemory.update(m.id, { status: 'retracted', corrected_by: ctx.user.email });
  else if (body.op === 'historical') await ctx.svc.entities.ContextMemory.update(m.id, { status: 'historical', corrected_by: ctx.user.email });
  else { await ctx.svc.entities.ContextMemory.update(m.id, { status: 'corrected', corrected_by: ctx.user.email }); await ctx.svc.entities.ContextMemory.create({ business_id: ctx.businessId, kind: m.kind, content: String(body.content || ''), as_of_date: iso(now), source: `Corrected by ${ctx.user.email}`, source_id: `${m.source_id || m.id}:corrected:${now.getTime()}`, status: 'current' }); }
  await audit(ctx, 'memory.correct', 'ContextMemory', m.id, `${body.op || 'correct'}: ${m.content.slice(0, 120)}`);
  return { ok: true };
};
extensions.api['usage.summary'] = async (ctx) => { assertCan(ctx, 'settings', 'read'); return summariseUsage(await ctx.svc.entities.AIUsageLog.filter({ business_id: ctx.businessId }, '-created_date', 5000)); };
extensions.api['integration.test'] = async (ctx, body, now) => {
  assertCan(ctx, 'integrations', 'admin');
  const i = await ctx.svc.entities.Integration.get(body.id).catch(() => null);
  if (!i || i.business_id !== ctx.businessId) throw new HttpError(404, 'Not found');
  // No provider connector code ships yet: report honestly rather than pretending.
  const result = `Not testable yet: no ${i.provider} connector/credentials are configured in this deployment. See docs/INTEGRATIONS.md.`;
  await ctx.svc.entities.Integration.update(i.id, { status: 'not_configured', last_tested_at: now.toISOString(), last_test_result: result });
  await audit(ctx, 'integration.test', 'Integration', i.id, result);
  return { ok: false, status: 'not_configured', result };
};
extensions.api['price.request'] = async (ctx, body) => {
  assertCan(ctx, 'products', 'write');
  const p = await ctx.svc.entities.Product.get(body.product_id).catch(() => null);
  if (!p || p.business_id !== ctx.businessId) throw new HttpError(404, 'Product not found');
  const ap = await createApproval(ctx.svc, ctx.businessId, { action_type: 'change_price', title: `Change ${p.name} price ${p.price ?? '—'} → ${body.new_price}`, description: body.reason || '', payload: { entity: 'Product', record_id: p.id, new_price: Number(body.new_price) }, requested_by: ctx.user.email, requested_by_type: 'user', required_role: 'approvals:approve', related_entity: 'Product', related_id: p.id });
  return { approval: ap };
};

// Deletes by non-owners (and any delete when configured) become approval requests.
extensions.beforeDelete = async (ctx, entity, rec, body, now) => {
  const s = await getSettings(ctx.svc, ctx.businessId);
  const rule = s.approval_rules.delete_record;
  if (rule === 'none' || (rule === 'owner_direct' && ctx.role === 'owner') || body.__approved) return null;
  const ap = await createApproval(ctx.svc, ctx.businessId, { action_type: 'delete_record', title: `Delete ${entity}: ${rec.name || rec.title || rec.decision || rec.id}`, description: body.reason || 'Deletion requested', payload: { entity, record_id: rec.id }, requested_by: ctx.user.email, requested_by_type: 'user', required_role: 'approvals:approve', related_entity: entity, related_id: rec.id });
  await audit(ctx, 'delete.requested', entity, rec.id, 'Deletion sent for approval');
  return { approval_required: true, approval_id: ap.id };
};

// Event-driven monitoring: scoped detectors after relevant writes (no full scans per transaction).
extensions.afterWrite = async (ctx, entity, op, rec, now) => {
  try {
    if (entity === 'Decision' && rec.actual_result) await remember(ctx.svc, ctx.businessId, 'decision', `Decision "${rec.decision}" (${rec.date || ''}): expected ${rec.expected_result || 'n/a'}; actual ${rec.actual_result}; outcome ${rec.outcome}. Lessons: ${rec.lessons || '—'}`, 'Decision Center', rec.id, rec.review_date || iso(now));
    if (entity === 'BusinessGoal') await remember(ctx.svc, ctx.businessId, 'objective', `Goal: ${rec.title} — target ${rec.target_value} ${rec.unit || ''} by ${rec.deadline || 'no deadline'}`, 'Goals', rec.id);
    const only = DETECTORS_FOR_ENTITY[entity];
    if (!only) return;
    const s = await getSettings(ctx.svc, ctx.businessId);
    if (!s.event_monitoring) return;
    const data = await loadBusinessData(ctx.svc, ctx.businessId, 'system');
    await upsertAlerts(ctx.svc, ctx.businessId, detectExceptions(data, s.thresholds, now, only), s, now, only);
  } catch (e) { console.error('event monitoring failed', e); }
};
extensions.afterImport = async (ctx, entity, n, now) => { if (n) await extensions.afterWrite(ctx, entity, 'create', {}, now); };

// Learning loop: aggregate outcomes per rule; memory of what worked.
extensions.afterOutcome = async (ctx, rec, body, now) => {
  if (!rec.rule_key) return;
  const all = (await ctx.svc.entities.Recommendation.filter({ business_id: ctx.businessId, rule_key: rec.rule_key })).map((r: any) => (r.id === rec.id ? { ...r, outcome: body.outcome } : r)).filter((r: any) => r.outcome && r.outcome !== 'unknown');
  const st = { total: all.length, worked: all.filter((r: any) => r.outcome === 'worked').length, partially: all.filter((r: any) => r.outcome === 'partially').length, did_not_work: all.filter((r: any) => r.outcome === 'did_not_work').length };
  const success_rate = st.total ? (st.worked + 0.5 * st.partially) / st.total : 0;
  const ex = (await ctx.svc.entities.LearningStat.filter({ business_id: ctx.businessId, rule_key: rec.rule_key }))[0];
  if (ex) await ctx.svc.entities.LearningStat.update(ex.id, { ...st, success_rate, last_updated: now.toISOString() }); else await ctx.svc.entities.LearningStat.create({ business_id: ctx.businessId, rule_key: rec.rule_key, ...st, success_rate, last_updated: now.toISOString() });
  await remember(ctx.svc, ctx.businessId, 'recommendation_outcome', `Recommendation "${rec.title}" → ${body.outcome}: ${body.actual_result || ''}`, 'Recommendation outcome', rec.id, iso(now));
};

// ── Intelligence extensions
const ix = extensions.intelligence;
ix['advisor.ask'] = async (ctx, body, now) => {
  assertCan(ctx, 'ai', 'write');
  const q = String(body.question || '').trim(); if (!q) throw new HttpError(422, 'Please type a question.');
  let conv = body.conversation_id ? await ctx.svc.entities.AIConversation.get(body.conversation_id).catch(() => null) : null;
  if (conv && (conv.business_id !== ctx.businessId || conv.user_id !== ctx.user.id)) conv = null;
  const settings = await getSettings(ctx.svc, ctx.businessId);
  const { context } = await agentContext(ctx, now);
  const out = await orchestrate(ctx.svc, { question: q, context, role: ctx.role, enabled: settings.agents_enabled, history: conv?.messages || [], hooks: extensions.llmHooks(ctx.svc, ctx.businessId, ctx.user), trigger: 'user_question' });
  const run = await ctx.svc.entities.AgentRun.create({ business_id: ctx.businessId, question: q, trigger: out.route?.collaboration ? 'collaboration' : 'user_question', agents: out.route?.agents.map((a: any) => a.key) || [], agent_findings: out.findings || [], synthesis: out.answer || { error: out.error }, unresolved_uncertainty: out.answer?.unresolved_uncertainty || [], status: out.status || 'failed', duration_ms: out.duration_ms, user_id: ctx.user.id });
  const messages = [...(conv?.messages || []), { role: 'user', content: q, at: now.toISOString() }, out.ok ? { role: 'assistant', content: out.answer.answer, structured: out.answer, agent_run_id: run.id, at: now.toISOString() } : { role: 'assistant', content: `I couldn't complete this answer: ${out.error}`, error: true, at: now.toISOString() }];
  if (conv) await ctx.svc.entities.AIConversation.update(conv.id, { messages, last_message_at: now.toISOString() });
  else conv = await ctx.svc.entities.AIConversation.create({ business_id: ctx.businessId, user_id: ctx.user.id, title: q.slice(0, 80), messages, last_message_at: now.toISOString() });
  return { conversation_id: conv.id, ok: out.ok, answer: out.answer, error: out.error, agent_run_id: run.id, status: out.status };
};
ix['agents.route'] = async (ctx, body) => { const s = await getSettings(ctx.svc, ctx.businessId); const r = routeQuestion(String(body.question || ''), ctx.role, s.agents_enabled); return { agents: r.agents.map((a) => a.name), blocked: r.blocked, collaboration: r.collaboration }; };
ix['command'] = async (ctx, _b, now) => {
  assertCan(ctx, 'strategy', 'read');
  const a = await analyze(ctx.svc, ctx.businessId, now);
  const red = redactAnalysis(a, ctx.role);
  const fin = can(ctx.role, 'finance', 'read');
  const [alerts, recs, opps, approvals, tasks, runs] = await Promise.all([
    ctx.svc.entities.Alert.filter({ business_id: ctx.businessId }, '-created_date', 200), ctx.svc.entities.Recommendation.filter({ business_id: ctx.businessId }, '-priority_score', 100),
    ctx.svc.entities.Opportunity.filter({ business_id: ctx.businessId, status: 'open' }, '-rank_score', 10), ctx.svc.entities.ApprovalRequest.filter({ business_id: ctx.businessId, status: 'pending' }, '-created_date', 50),
    ctx.svc.entities.Task.filter({ business_id: ctx.businessId }, 'due_date', 1000), ctx.svc.entities.AgentRun.filter({ business_id: ctx.businessId }, '-created_date', 5),
  ]);
  const f = buildForecasts(a.data, now, 3);
  return {
    health: red.health, stage: red.stage, snapshot: red.snapshot,
    alerts: alerts.filter((x: any) => x.status !== 'closed' && (fin || x.business_area !== 'Finance')).sort((x: any, y: any) => sevRank(y.severity) - sevRank(x.severity)).slice(0, 10),
    recommendations: recs.filter((r: any) => r.status === 'proposed' && (fin || r.category !== 'finance')).slice(0, 6), opportunities: opps,
    financial_warnings: fin ? [f.cash?.warning, red.snapshot.runway_months?.value !== null && red.snapshot.runway_months.value < 6 ? `Cash runway ≈${Math.round(red.snapshot.runway_months.value * 10) / 10} months (estimate)` : null].filter(Boolean) : [],
    forecast: { revenue: f.revenue, cash: fin ? f.cash : null }, approvals_pending: can(ctx.role, 'approvals', 'read') ? approvals.length : null,
    outstanding_actions: tasks.filter((t: any) => !['completed', 'cancelled'].includes(t.status)).slice(0, 8), recent_agent_runs: runs.map((r: any) => ({ question: r.question, status: r.status, agents: r.agents, at: r.created_date })),
    sales_intel: { best: (red.snapshot.variants.length ? red.snapshot.variants : red.snapshot.products).filter((p: any) => p.tags.includes('best_seller')).slice(0, 3).map((p: any) => p.name), declining: (red.snapshot.variants.length ? red.snapshot.variants : red.snapshot.products).filter((p: any) => p.tags.includes('declining')).slice(0, 3).map((p: any) => p.name) },
  };
};
ix['monitor.run'] = async (ctx, _b, now) => {
  assertCan(ctx, 'alerts', 'read');
  const data = await loadBusinessData(ctx.svc, ctx.businessId, 'system');
  const res = await runMonitoringFor(ctx.svc, ctx.businessId, data, now);
  const a = await analyze(ctx.svc, ctx.businessId, now);
  const opp = await upsertOpportunities(ctx.svc, ctx.businessId, detectOpportunities(data, a.diag.findings, now));
  await audit(ctx, 'monitor.run', 'Alert', null, `On-demand check: ${res.created} new, ${res.escalated} escalated, ${res.resolved} resolved alerts; ${opp} opportunities`, null, null, 'system');
  return { ...res, opportunities: opp };
};
ix['forecast'] = async (ctx, body, now) => {
  assertCan(ctx, 'strategy', 'read');
  const data = await loadBusinessData(ctx.svc, ctx.businessId, ctx.role);
  const f = buildForecasts(data, now, Math.min(12, Number(body.horizon) || 6));
  const fin = can(ctx.role, 'finance', 'read');
  if (!fin) { f.cash = { ok: false, reason: 'Restricted for your role' }; f.expenses = { ok: false, reason: 'Restricted for your role' } as any; }
  if (!can(ctx.role, 'customers', 'read')) (f as any).customer_behaviour = null;
  if (body.save && f.revenue.ok) await ctx.svc.entities.Forecast.create({ business_id: ctx.businessId, metric: 'revenue', method: (f.revenue as any).method, horizon_periods: (f.revenue as any).expected.length, period_type: 'month', history_points: (f.revenue as any).history_points, conservative: (f.revenue as any).conservative, expected: (f.revenue as any).expected, aggressive: (f.revenue as any).aggressive, assumptions: (f.revenue as any).assumptions, confidence: (f.revenue as any).confidence, generated_at: now.toISOString() });
  const saved = await ctx.svc.entities.Forecast.filter({ business_id: ctx.businessId, metric: 'revenue' }, '-generated_at', 6);
  const months = monthlySeries(data.sales, 24, now);
  return { ...f, accuracy: saved.map((s: any) => ({ generated_at: s.generated_at, comparison: compareForecastActuals(s, months) })).filter((x: any) => x.comparison.length) };
};
ix['scenario.kinds'] = async () => ({ kinds: SCENARIO_KINDS });
ix['scenario.run'] = async (ctx, body, now) => {
  assertCan(ctx, 'finance', 'read'); assertCan(ctx, 'strategy', 'read');
  const data = await loadBusinessData(ctx.svc, ctx.businessId, ctx.role);
  const r = simulate(data, { kind: body.kind, params: body.params || {} }, now);
  if (r.ok && body.save && can(ctx.role, 'strategy', 'write')) { const sc = await ctx.svc.entities.Scenario.create({ business_id: ctx.businessId, name: body.name || SCENARIO_KINDS[body.kind]?.label, kind: body.kind, inputs: (r as any).params, assumptions: (r as any).assumptions, results: r, risks: (r as any).risks, created_by_user: ctx.user.email }); return { ...r, scenario_id: sc.id }; }
  return r;
};
ix['expansion.assess'] = async (ctx, _b, now) => {
  assertCan(ctx, 'finance', 'read');
  const a = await analyze(ctx.svc, ctx.businessId, now);
  return { ...expansionReadiness(a.data, now, a.health.overall_score), locations: computeSnapshot(a.data, now).locations };
};
ix['report.generate'] = async (ctx, body, now) => ({ report: await generateReport(ctx, body.kind, now) });
ix['briefing'] = async (ctx, _b, now) => ({ report: await generateReport(ctx, 'briefing', now) });
ix['workflow.run'] = async (ctx, body, now) => {
  const k = body.key; const wf = WORKFLOWS[k]; if (!wf) throw new HttpError(400, 'Unknown workflow');
  assertCan(ctx, 'operations', k === 'low_stock_purchase' || k === 'production_recommendation' ? 'write' : 'read'); assertCan(ctx, 'strategy', 'read');
  const data = await loadBusinessData(ctx.svc, ctx.businessId, 'system');
  return runWorkflow(ctx, k, data, now, extensions.llmHooks(ctx.svc, ctx.businessId, ctx.user), (kind) => generateReport(ctx, kind, now));
};
ix['strategy.generate'] = async (ctx, body, now) => {
  assertCan(ctx, 'strategy', 'write');
  const topic = String(body.topic || 'revenue growth');
  const { context } = await agentContext(ctx, now);
  const res = await callLLM<any>(ctx.svc, { purpose: 'strategy', agent_key: 'growth', tier: 'complex', schema: { type: 'object', required: ['summary', 'objectives', 'initiatives', 'resources_needed', 'risks', 'kpis', 'assumptions'], properties: { summary: { type: 'string' }, objectives: { type: 'array', items: { type: 'string' } }, initiatives: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, why: { type: 'string' }, steps: { type: 'array', items: { type: 'string' } }, owner: { type: 'string' }, timeframe: { type: 'string' }, est_cost: { type: 'string' } } } }, resources_needed: { type: 'array', items: { type: 'string' } }, risks: { type: 'array', items: { type: 'string' } }, kpis: { type: 'array', items: { type: 'string' } }, assumptions: { type: 'array', items: { type: 'string' } }, not_recommended_now: { type: 'array', items: { type: 'string' } } } }, prompt: `Create a practical ${fenceUntrusted('topic', topic)} strategy for this business that fits its actual resources, cash, stage, goals and constraints. If the data shows the business is not ready for something (e.g. expansion), say so in not_recommended_now. Costs must be labelled as estimates.\nDATA:\n${JSON.stringify(context)}` }, extensions.llmHooks(ctx.svc, ctx.businessId, ctx.user));
  if (!res.ok) throw new HttpError(502, `Strategy could not be generated: ${res.error}`);
  const d = res.data;
  const md = `# ${topic.replace(/^\w/, (c) => c.toUpperCase())} strategy — ${context.business.stage}\n\n${d.summary}\n\n## Objectives\n${d.objectives.map((x: string) => `- ${x}`).join('\n')}\n\n## Initiatives\n${d.initiatives.map((i: any) => `### ${i.name}\n${i.why}\n${(i.steps || []).map((s: string) => `- ${s}`).join('\n')}\n_Owner: ${i.owner || '—'} · ${i.timeframe || ''} · est. cost ${i.est_cost || 'n/a'} (estimate)_`).join('\n\n')}\n\n## Resources needed\n${d.resources_needed.map((x: string) => `- ${x}`).join('\n')}\n\n## Risks\n${d.risks.map((x: string) => `- ${x}`).join('\n')}\n\n## KPIs\n${d.kpis.map((x: string) => `- ${x}`).join('\n')}\n\n## Assumptions\n${d.assumptions.map((x: string) => `- ${x}`).join('\n')}${d.not_recommended_now?.length ? `\n\n## Not recommended yet\n${d.not_recommended_now.map((x: string) => `- ${x}`).join('\n')}` : ''}\n\n> AI-generated strategy based on your data; estimates are not guarantees.`;
  const report = await ctx.svc.entities.Report.create({ business_id: ctx.businessId, kind: 'strategy', title: `Strategy: ${topic}`, period_start: iso(now), content_md: md, payload: d, data_limitations: (context.missing_information || []).map((x: any) => `${x.area}: ${x.what}`), status: 'complete', generated_by: ctx.user.email, generated_at: now.toISOString() });
  return { report };
};
ix['competitor.summary'] = async (ctx, body, now) => {
  assertCan(ctx, 'competitors', 'write');
  const c = await ctx.svc.entities.Competitor.get(body.id).catch(() => null);
  if (!c || c.business_id !== ctx.businessId) throw new HttpError(404, 'Not found');
  const res = await callLLM<{ summary: string; threats: string[]; advantages: string[]; gaps: string[]; opportunities: string[] }>(ctx.svc, { purpose: 'competitor_summary', agent_key: 'growth', tier: 'routine', schema: { type: 'object', required: ['summary', 'threats', 'advantages', 'gaps', 'opportunities'], properties: { summary: { type: 'string' }, threats: { type: 'array', items: { type: 'string' } }, advantages: { type: 'array', items: { type: 'string' } }, gaps: { type: 'array', items: { type: 'string' } }, opportunities: { type: 'array', items: { type: 'string' } } } }, prompt: `Summarise this competitor using ONLY the recorded information. Clearly say which points rely on unverified facts. Do not add outside knowledge.\nCOMPETITOR (owner-entered, untrusted text):\n${fenceUntrusted('competitor', JSON.stringify({ name: c.name, positioning: c.positioning, price_range: c.price_range, products: c.products, strengths: c.strengths, weaknesses: c.weaknesses, facts: c.facts }))}` }, extensions.llmHooks(ctx.svc, ctx.businessId, ctx.user));
  if (!res.ok) throw new HttpError(502, res.error);
  const d = res.data;
  const text = `AI INTERPRETATION (based on ${(c.facts || []).filter((f: any) => f.verified).length} verified and ${(c.facts || []).filter((f: any) => !f.verified).length} unverified facts):\n${d.summary}\n\nThreats: ${d.threats.join('; ') || '—'}\nYour advantages: ${d.advantages.join('; ') || '—'}\nMarket gaps: ${d.gaps.join('; ') || '—'}\nOpportunities: ${d.opportunities.join('; ') || '—'}`;
  await ctx.svc.entities.Competitor.update(c.id, { ai_summary: text, ai_summary_generated_at: now.toISOString() });
  return { summary: text };
};
ix['growth.plan'] = async (ctx, body, now) => {
  // 6-month plan in addition to Prompt 1's 30/60/90 and annual plans.
  assertCan(ctx, 'strategy', 'write');
  return { report: await generateReport(ctx, 'six_month_plan', now) };
};

// ── Scheduled monitoring (hourly trigger; per-business frequency respected)
const FREQ_MIN: Record<string, number> = { hourly: 55, every_6_hours: 355, daily: 1430 };
monitorExt.run = async (svc, args, now) => {
  const businesses = (await svc.entities.Business.filter({ status: 'active' }, '-created_date', 1000)).filter((b: any) => !args.business_id || b.id === args.business_id);
  const results: any[] = [];
  for (const b of businesses) {
    try {
      const s = await getSettings(svc, b.id);
      const lastRun = (await svc.entities.WorkflowRun.filter({ business_id: b.id, workflow_key: 'scheduled_monitoring' }, '-created_date', 1))[0];
      if (lastRun && !args.force && now.getTime() - new Date(lastRun.created_date).getTime() < FREQ_MIN[s.monitoring_frequency] * 60000) { results.push({ skipped: 'not_due' }); continue; }
      const run = await svc.entities.WorkflowRun.create({ business_id: b.id, workflow_key: 'scheduled_monitoring', mode: 'automatic', status: 'running', idempotency_key: `mon:${b.id}:${now.toISOString().slice(0, 13)}`, started_by: 'schedule' });
      const a = await analyze(svc, b.id, now);
      await persistAnalysis(svc, b.id, a, now);
      const { recommendations } = await syncRecommendations(svc, b.id, a, now);
      const mon = await upsertAlerts(svc, b.id, detectExceptions(a.data, s.thresholds, now), s, now);
      await upsertOpportunities(svc, b.id, detectOpportunities(a.data, a.diag.findings, now));
      const sys = { svc, businessId: b.id, user: { id: 'system', email: 'system' } } as any;
      const hooks = extensions.llmHooks(svc, b.id);
      const owner = { ...sys, role: 'owner', business: b } as Ctx;
      const prior = async (kind: string, hours: number) => { const r = (await svc.entities.Report.filter({ business_id: b.id, kind }, '-generated_at', 1))[0]; return r && now.getTime() - new Date(r.generated_at).getTime() < hours * 3600000; };
      if (s.report_schedule.weekly_review && now.getUTCDay() === 1 && !(await prior('weekly_review', 144))) await weeklyReview(svc, b.id, a, recommendations, now, hooks);
      if (s.report_schedule.monthly_review && now.getUTCDate() === 1 && !(await prior('monthly_review', 600))) await weeklyReview(svc, b.id, a, recommendations, now, hooks, 'monthly_review');
      if (s.report_schedule.daily_briefing && !(await prior('briefing', 20))) await generateReport(owner, 'briefing', now);
      await svc.entities.WorkflowRun.update(run.id, { status: 'completed', output: mon });
      results.push({ health: a.health.overall_score, ...mon });
    } catch (e: any) { results.push({ error: String(e?.message || e) }); }
  }
  return { ran_at: now.toISOString(), businesses: businesses.length, results };
};
void runBasicMonitoring; void ENTITY_REGISTRY;
