// AI-prepared workflows with human approval and idempotency (Sections 20–22).
import { computeSnapshot, iso, type BusinessData } from '../metrics.ts';
import { audit, HttpError, type Ctx } from '../context.ts';
import { can, canAssignRole, ROLES, type Role } from '../permissions.ts';
import { callLLM, type LLMHooks } from '../llm.ts';
import { CONSEQUENTIAL_ACTIONS, getSettings } from './settings.ts';
import { buildForecasts } from './predict.ts';

export const WORKFLOWS: Record<string, { label: string; produces: string; consequential: boolean }> = {
  low_stock_purchase: { label: 'Low-stock purchase recommendations → draft purchase orders', produces: 'Draft POs + approval request to place them', consequential: true },
  customer_followup: { label: 'Customer follow-up reminders', produces: 'Follow-up tasks + message draft (sending needs approval)', consequential: true },
  production_recommendation: { label: 'Production recommendations', produces: 'Planned production runs (drafts, editable)', consequential: false },
  sales_report: { label: 'Sales performance report', produces: 'Report', consequential: false },
  management_report: { label: 'Management briefing', produces: 'Report', consequential: false },
  marketing_campaign_draft: { label: 'Marketing campaign draft', produces: 'Campaign draft text (publishing needs approval)', consequential: true },
};

export async function createApproval(svc: any, businessId: string, req: { action_type: string; title: string; description: string; payload: any; requested_by: string; requested_by_type: 'ai' | 'user' | 'workflow'; required_role?: string; related_entity?: string; related_id?: string }) {
  return svc.entities.ApprovalRequest.create({ business_id: businessId, status: 'pending', ...req });
}

export async function runWorkflow(ctx: Ctx, key: string, data: BusinessData, now: Date, hooks: LLMHooks, reportFn: (kind: string) => Promise<any>) {
  const wf = WORKFLOWS[key]; if (!wf) throw new HttpError(400, 'Unknown workflow');
  const settings = await getSettings(ctx.svc, ctx.businessId);
  const mode = wf.consequential ? 'approval_required' : settings.workflow_modes[key] || 'approval_required';
  const idem = `${key}:${ctx.businessId}:${iso(now)}`;
  const dup = (await ctx.svc.entities.WorkflowRun.filter({ business_id: ctx.businessId, idempotency_key: idem })).find((r: any) => ['completed', 'awaiting_approval', 'running'].includes(r.status));
  if (dup) return { run: dup, duplicate: true, message: 'This workflow already ran today; the existing result is shown (duplicate prevention).' };
  const run = await ctx.svc.entities.WorkflowRun.create({ business_id: ctx.businessId, workflow_key: key, mode, status: 'running', idempotency_key: idem, attempts: 1, started_by: ctx.user?.email || 'system' });
  try {
    let output: any = {}, approval: any = null;
    const s = computeSnapshot(data, now);
    if (key === 'low_stock_purchase') {
      const f = buildForecasts(data, now);
      const lines = f.demand.filter((x) => x.recommended_order_qty > 0).map((x) => { const it = (data.inventory || []).find((i) => i.id === x.id); return { inventory_item_id: x.id, name: x.name, qty: x.recommended_order_qty, unit_cost: it?.unit_cost ?? null, supplier_id: it?.supplier_id || null, rationale: x.assumptions }; });
      if (!lines.length) output = { message: 'No items need reordering based on current sales rates and lead times.' };
      else {
        const groups: Record<string, any[]> = {}; for (const l of lines) (groups[l.supplier_id || 'unassigned'] ||= []).push(l);
        const pos: any[] = [];
        for (const [sup, ls] of Object.entries(groups)) {
          const total = ls.reduce((t, l) => t + (l.unit_cost || 0) * l.qty, 0);
          const po = await ctx.svc.entities.PurchaseOrder.create({ business_id: ctx.businessId, supplier_id: sup === 'unassigned' ? undefined : sup, po_number: `DRAFT-${iso(now).replace(/-/g, '')}-${pos.length + 1}`, lines: ls, total: Math.round(total * 100) / 100, status: 'pending_approval', rationale: 'AI-prepared from sales velocity, lead time and 30-day target cover (forecast).', created_by_type: 'ai' });
          pos.push(po);
        }
        approval = await createApproval(ctx.svc, ctx.businessId, { action_type: 'purchase_order', title: `Approve ${pos.length} draft purchase order(s)`, description: `${lines.length} item(s) below target cover. Quantities are forecasts — edit before approving. Approving does NOT send anything to suppliers.`, payload: { purchase_order_ids: pos.map((p) => p.id) }, requested_by: 'workflow:low_stock_purchase', requested_by_type: 'workflow', required_role: 'approvals:approve', related_entity: 'PurchaseOrder' });
        for (const po of pos) await ctx.svc.entities.PurchaseOrder.update(po.id, { approval_request_id: approval.id });
        output = { purchase_orders: pos.map((p) => ({ id: p.id, po_number: p.po_number, total: p.total, lines: p.lines.length })) };
      }
    } else if (key === 'customer_followup') {
      const events = s.events.filter((e) => e.has_result && (e.leads || 0) > 0 && e.followups_open === 0).slice(0, 3);
      const consenting = (data.customers || []).filter((c) => c.marketing_consent && c.acquisition_event_id && events.some((e) => e.id === c.acquisition_event_id));
      const tasks: any[] = [];
      for (const e of events) tasks.push(await ctx.svc.entities.Task.create({ business_id: ctx.businessId, title: `Follow up ${e.name} leads`, description: `${e.leads} leads; only contact people who consented.`, priority: 'high', status: 'not_started', due_date: iso(new Date(now.getTime() + 7 * 86400000)), plan_horizon: '30', owner_name: 'Marketing' }));
      const draft = await callLLM<{ subject: string; body: string }>(ctx.svc, { purpose: 'followup_draft', agent_key: 'marketing', tier: 'routine', schema: { type: 'object', properties: { subject: { type: 'string' }, body: { type: 'string' } }, required: ['subject', 'body'] }, prompt: `Draft a short, warm follow-up email from ${data.business?.name} to people met at ${events.map((e) => e.name).join(', ') || 'a recent event'}. No discounts or claims unless provided. Use {first_name} as a placeholder. DATA: ${JSON.stringify({ events: events.map((e) => ({ name: e.name, date: e.date })) })}` }, hooks);
      if (draft.ok && (consenting.length || events.length)) approval = await createApproval(ctx.svc, ctx.businessId, { action_type: 'send_external_message', title: `Send follow-up message to ${consenting.length} consenting contact(s)`, description: 'AI-drafted message. Review and edit. Approving records your authorisation; sending requires an email integration (not configured) — copy the draft into your email tool.', payload: { draft: draft.data, recipient_customer_ids: consenting.map((c) => c.id) }, requested_by: 'workflow:customer_followup', requested_by_type: 'workflow', required_role: 'approvals:approve' });
      output = { tasks: tasks.length, draft: draft.ok ? draft.data : null, draft_error: draft.ok ? null : draft.error, consenting_recipients: consenting.length };
    } else if (key === 'production_recommendation') {
      const f = buildForecasts(data, now);
      const runs: any[] = [];
      for (const x of f.demand.filter((d) => d.recommended_order_qty > 0).slice(0, 10)) { const it = (data.inventory || []).find((i) => i.id === x.id); runs.push(await ctx.svc.entities.ProductionRun.create({ business_id: ctx.businessId, product_id: it?.product_id, variant_id: it?.variant_id, planned_qty: x.recommended_order_qty, planned_date: x.reorder_by || iso(now), status: 'planned', batch_number: `AI-PLAN-${iso(now)}` })); }
      output = { planned_runs: runs.length, note: runs.length ? 'Planned runs are proposals; edit or cancel them in Operations → Production.' : 'No production needed based on current forecasts.' };
    } else if (key === 'sales_report' || key === 'management_report') {
      output = { report: await reportFn(key === 'sales_report' ? 'sales' : 'briefing') };
    } else if (key === 'marketing_campaign_draft') {
      const best = s.campaigns.filter((c) => c.reliable).sort((a, b) => (b.roas || 0) - (a.roas || 0))[0];
      const grow = (s.variants.length ? s.variants : s.products).filter((p) => p.tags.includes('fast_growing')).slice(0, 3).map((p) => p.name);
      const d = await callLLM<{ name: string; audience: string; message: string; channels: string[]; budget_note: string; measurement: string }>(ctx.svc, { purpose: 'campaign_draft', agent_key: 'marketing', tier: 'routine', schema: { type: 'object', required: ['name', 'audience', 'message', 'channels', 'measurement'], properties: { name: { type: 'string' }, audience: { type: 'string' }, message: { type: 'string' }, channels: { type: 'array', items: { type: 'string' } }, budget_note: { type: 'string' }, measurement: { type: 'string' } } }, prompt: `Draft a marketing campaign for ${data.business?.name}. Base it on the DATA only. Include a tracking method (promo code/UTM) so results can be attributed. DATA: ${JSON.stringify({ best_tracked_campaign: best, fast_growing: grow, repeat_rate: s.repeat_rate_pct })}` }, hooks);
      if (d.ok) approval = await createApproval(ctx.svc, ctx.businessId, { action_type: 'publish_marketing', title: `Publish campaign: ${d.data.name}`, description: 'AI draft. Publishing requires your approval and a connected marketing platform (not configured); approved drafts can be published manually.', payload: d.data, requested_by: 'workflow:marketing_campaign_draft', requested_by_type: 'workflow', required_role: 'approvals:approve' });
      output = { draft: d.ok ? d.data : null, error: d.ok ? null : d.error };
    }
    const status = approval ? 'awaiting_approval' : 'completed';
    await ctx.svc.entities.WorkflowRun.update(run.id, { status, output, approval_request_id: approval?.id });
    await audit(ctx, `workflow.${key}`, 'WorkflowRun', run.id, `${wf.label}: ${status}`, null, null, 'ai');
    return { run: { ...run, status, output, approval_request_id: approval?.id }, approval };
  } catch (e: any) {
    await ctx.svc.entities.WorkflowRun.update(run.id, { status: 'failed', error: String(e?.message || e) });
    await audit(ctx, `workflow.${key}.failed`, 'WorkflowRun', run.id, String(e?.message || e), null, null, 'system');
    throw new HttpError(500, `Workflow failed: ${e?.message || e}. Nothing was sent or purchased.`);
  }
}

// Approve / reject an ApprovalRequest. Only users with approvals:approve (or the specific required role) may decide.
export async function decideApproval(ctx: Ctx, id: string, decision: 'approve' | 'reject', note: string, now: Date) {
  const req = await ctx.svc.entities.ApprovalRequest.get(id).catch(() => null);
  if (!req || req.business_id !== ctx.businessId) throw new HttpError(404, 'Approval request not found.');
  if (req.status !== 'pending') throw new HttpError(409, `Already ${req.status}.`);
  const financial = ['payment', 'purchase', 'transfer_funds', 'purchase_order', 'change_price'].includes(req.action_type);
  if (!can(ctx.role, 'approvals', 'approve') || (financial && !can(ctx.role, 'finance', 'read'))) throw new HttpError(403, 'Your role cannot approve this action.');
  if (req.requested_by === ctx.user.email && req.action_type === 'change_permissions') throw new HttpError(403, 'You cannot approve your own permission change.');
  if (decision === 'reject') {
    await ctx.svc.entities.ApprovalRequest.update(id, { status: 'rejected', decided_by: ctx.user.email, decided_at: now.toISOString(), execution_result: note || 'Rejected' });
    if (req.action_type === 'purchase_order') for (const pid of req.payload?.purchase_order_ids || []) await ctx.svc.entities.PurchaseOrder.update(pid, { status: 'cancelled' });
    await audit(ctx, 'approval.reject', 'ApprovalRequest', id, `${req.title}${note ? ' — ' + note : ''}`);
    return { status: 'rejected' };
  }
  await ctx.svc.entities.ApprovalRequest.update(id, { status: 'approved', decided_by: ctx.user.email, decided_at: now.toISOString() });
  let result = '', status = 'executed', failure: string | null = null;
  try {
    switch (req.action_type) {
      case 'purchase_order': for (const pid of req.payload?.purchase_order_ids || []) await ctx.svc.entities.PurchaseOrder.update(pid, { status: 'approved' }); result = 'Purchase orders approved. Nothing was sent: send them to suppliers yourself (no supplier integration configured).'; break;
      case 'delete_record': { const { entity, record_id } = req.payload || {}; const rec = await ctx.svc.entities[entity].get(record_id).catch(() => null); if (!rec || rec.business_id !== ctx.businessId) throw new Error('Record no longer exists'); await ctx.svc.entities[entity].delete(record_id); result = `${entity} deleted.`; break; }
      case 'change_price': { const { entity = 'Product', record_id, new_price } = req.payload || {}; const rec = await ctx.svc.entities[entity].get(record_id).catch(() => null); if (!rec || rec.business_id !== ctx.businessId) throw new Error('Product not found'); await ctx.svc.entities[entity].update(record_id, { price: Number(new_price) }); result = `Price changed from ${rec.price} to ${new_price} in this platform only (your store/POS is not connected).`; break; }
      case 'change_permissions': { const { member_id, role } = req.payload || {}; const m = await ctx.svc.entities.BusinessMember.get(member_id).catch(() => null); if (!m || m.business_id !== ctx.businessId || !ROLES.includes(role) || !canAssignRole(ctx.role, role as Role)) throw new Error('Not permitted'); await ctx.svc.entities.BusinessMember.update(member_id, { role }); result = `Role changed to ${role}.`; break; }
      case 'send_external_message': case 'publish_marketing': status = 'approved'; result = 'Authorised. No email/marketing integration is connected, so nothing was sent automatically — copy the approved draft into your tool.'; break;
      default: status = 'approved'; result = 'Authorised and recorded. This action type has no automated execution — complete it manually.';
    }
  } catch (e: any) { status = 'failed'; failure = String(e?.message || e); }
  await ctx.svc.entities.ApprovalRequest.update(id, { status, execution_result: result, failure_reason: failure });
  await audit(ctx, `approval.${status}`, 'ApprovalRequest', id, `${req.title}: ${failure || result}`);
  return { status, result, failure };
}

export const isConsequential = (t: string) => CONSEQUENTIAL_ACTIONS.includes(t);
