// Automatic exception detection, alerts with de-duplication, and opportunity detection (Sections 5–8).
import { computeSnapshot, saleRevenue, toDate, DAY, round, type BusinessData } from '../metrics.ts';
import { getSettings, sevRank } from './settings.ts';

export type Exception = { exception_type: string; fingerprint: string; severity: string; title: string; business_area: string; what_happened: string; when_happened: string; why_it_matters: string; potential_impact: string; recommended_action: string; supporting_records: any[]; metrics: any };

const pctChange = (a: number, b: number) => (b > 0 ? ((a - b) / b) * 100 : null);
const sev = (x: number, steps: [number, string][]) => { for (const [t, s] of steps) if (x >= t) return s; return 'low'; };
const f = (n: number | null, d = 1) => (n === null ? 'n/a' : (Math.round(n * 10 ** d) / 10 ** d).toLocaleString());

// Each detector only reads the data it needs, so event-driven runs can call a subset.
export const DETECTORS: Record<string, (d: BusinessData, t: any, now: Date) => Exception[]> = {
  declining_sales: (d, t, now) => {
    const w = (a: number, b: number) => d.sales.filter((s) => { const x = toDate(s.date); return x && x >= new Date(now.getTime() - a * DAY) && x < new Date(now.getTime() - b * DAY); });
    const cur = w(30, 0), prev = w(60, 30);
    if (prev.length < 10) return [];
    const r1 = cur.reduce((a, s) => a + saleRevenue(s), 0), r0 = prev.reduce((a, s) => a + saleRevenue(s), 0), ch = pctChange(r1, r0);
    if (ch === null || ch > -t.sales_decline_pct) return [];
    return [{ exception_type: 'declining_sales', fingerprint: 'exc:declining_sales', severity: sev(-ch, [[40, 'critical'], [25, 'high'], [0, 'moderate']]), title: `Sales down ${f(-ch)}% vs previous 30 days`, business_area: 'Sales', what_happened: `Revenue fell from ${f(r0, 0)} to ${f(r1, 0)} (actual sale records).`, when_happened: now.toISOString(), why_it_matters: 'Lower sales reduce cash available for production and marketing.', potential_impact: `About ${f(r0 - r1, 0)} less revenue per month if the trend holds (estimate).`, recommended_action: 'Open Sales to see which products/channels dropped; ask the Sales agent "Why are sales down?".', supporting_records: [{ entity: 'Sale', count: cur.length }], metrics: { current: round(r1), previous: round(r0), change_pct: round(ch, 1), threshold_pct: t.sales_decline_pct } }];
  },
  increasing_expenses: (d, t, now) => {
    const w = (a: number, b: number) => d.expenses.filter((e) => { const x = toDate(e.date); return x && x >= new Date(now.getTime() - a * DAY) && x < new Date(now.getTime() - b * DAY); });
    const cur = w(30, 0), prev = w(60, 30);
    if (prev.length < 3) return [];
    const e1 = cur.reduce((a, e) => a + (Number(e.amount) || 0), 0), e0 = prev.reduce((a, e) => a + (Number(e.amount) || 0), 0), ch = pctChange(e1, e0);
    if (ch === null || ch < t.expense_increase_pct) return [];
    const byCat: Record<string, number> = {}; for (const e of cur) byCat[e.category] = (byCat[e.category] || 0) + (Number(e.amount) || 0); for (const e of prev) byCat[e.category] = (byCat[e.category] || 0) - (Number(e.amount) || 0);
    const top = Object.entries(byCat).sort((a, b) => b[1] - a[1])[0];
    return [{ exception_type: 'increasing_expenses', fingerprint: 'exc:increasing_expenses', severity: sev(ch, [[60, 'high'], [0, 'moderate']]), title: `Expenses up ${f(ch)}% vs previous 30 days`, business_area: 'Finance', what_happened: `Spending rose from ${f(e0, 0)} to ${f(e1, 0)}. Largest increase: ${top?.[0] || 'n/a'} (+${f(top?.[1] || 0, 0)}).`, when_happened: now.toISOString(), why_it_matters: 'Rising costs reduce profit unless sales rise too.', potential_impact: `${f(e1 - e0, 0)} more spending per month (actual).`, recommended_action: `Review ${top?.[0] || 'the largest'} expenses; check whether the increase is one-off.`, supporting_records: cur.slice(0, 20).map((e) => ({ entity: 'Expense', id: e.id })), metrics: { current: round(e1), previous: round(e0), change_pct: round(ch, 1) } }];
  },
  falling_margin: (d, t, now) => {
    const m = (a: number, b: number) => { let rev = 0, cost = 0, n = 0; for (const s of d.sales) { const x = toDate(s.date); if (!x || x < new Date(now.getTime() - a * DAY) || x >= new Date(now.getTime() - b * DAY)) continue; const uc = Number(s.unit_cost); if (!isFinite(uc) || s.unit_cost === null || s.unit_cost === undefined) continue; rev += saleRevenue(s); cost += uc * (Number(s.quantity) || 0); n++; } return n >= 10 && rev > 0 ? ((rev - cost) / rev) * 100 : null; };
    const m1 = m(30, 0), m0 = m(60, 30);
    if (m1 === null || m0 === null || m0 - m1 < t.margin_drop_points) return [];
    return [{ exception_type: 'falling_margin', fingerprint: 'exc:falling_margin', severity: m0 - m1 >= 10 ? 'high' : 'moderate', title: `Gross margin fell ${f(m0 - m1)} points`, business_area: 'Finance', what_happened: `Margin on costed sales went from ${f(m0)}% to ${f(m1)}%.`, when_happened: now.toISOString(), why_it_matters: 'Each margin point lost comes straight out of profit.', potential_impact: 'Discounting, channel mix (e.g. more wholesale) or higher unit costs are the usual causes.', recommended_action: 'Compare channel mix and unit costs between the two periods.', supporting_records: [], metrics: { current_pct: round(m1, 1), previous_pct: round(m0, 1) } }];
  },
  inventory: (d, t, now) => {
    const s = computeSnapshot(d, now);
    const out: Exception[] = [];
    for (const i of s.inventory) {
      if (i.flags.includes('out_of_stock') || (i.days_of_cover !== null && i.lead_time_days !== null && i.days_of_cover <= i.lead_time_days + t.stockout_days_buffer)) out.push({ exception_type: 'stock_shortage', fingerprint: `exc:stock:${i.id}`, severity: i.flags.includes('out_of_stock') ? 'critical' : i.is_best_seller ? 'high' : 'moderate', title: i.flags.includes('out_of_stock') ? `${i.name} is out of stock` : `${i.name}: ~${i.days_of_cover} days of stock left (forecast)`, business_area: 'Inventory', what_happened: `${i.on_hand} on hand, selling ${i.velocity_per_day}/day; lead time ${i.lead_time_days ?? 'unknown'} days.`, when_happened: now.toISOString(), why_it_matters: 'Stock-outs lose sales.', potential_impact: `≈${Math.round((i.velocity_per_day || 0) * 30)} units of monthly demand at risk (forecast).`, recommended_action: 'Run the low-stock purchase workflow or plan production.', supporting_records: [{ entity: 'InventoryItem', id: i.id }], metrics: { on_hand: i.on_hand, days_of_cover: i.days_of_cover, lead_time_days: i.lead_time_days } });
      if (i.days_of_cover !== null && i.days_of_cover > t.excess_inventory_days && (i.capital || 0) > 0) out.push({ exception_type: 'excess_inventory', fingerprint: `exc:excess:${i.id}`, severity: 'low', title: `${i.name}: ${i.days_of_cover} days of stock (excess)`, business_area: 'Inventory', what_happened: `${i.on_hand} units on hand vs ${i.velocity_per_day}/day sales.`, when_happened: now.toISOString(), why_it_matters: 'Cash tied up in slow stock.', potential_impact: `${f(i.capital, 0)} at cost tied up.`, recommended_action: 'Pause production, bundle or promote.', supporting_records: [{ entity: 'InventoryItem', id: i.id }], metrics: { capital: i.capital } });
    }
    return out;
  },
  production: (d, t, now) => (d.productionRuns || []).filter((p) => p.status === 'delayed' || (['planned', 'in_progress'].includes(p.status) && p.planned_date && toDate(p.planned_date)!.getTime() + t.production_delay_days * DAY < now.getTime())).map((p) => ({ exception_type: 'production_delay', fingerprint: `exc:prod:${p.id}`, severity: 'high', title: `Production batch ${p.batch_number || p.id} is delayed`, business_area: 'Manufacturing', what_happened: `Planned for ${p.planned_date}, status ${p.status}${p.delay_reason ? ` (${p.delay_reason})` : ''}.`, when_happened: now.toISOString(), why_it_matters: 'Delays can cause stock-outs of the items being produced.', potential_impact: `${p.planned_qty ?? '?'} units not yet available.`, recommended_action: 'Confirm a new completion date and check stock cover for this item.', supporting_records: [{ entity: 'ProductionRun', id: p.id }], metrics: { planned_qty: p.planned_qty } })),
  mfg_cost: (d, t) => {
    const runs = (d.productionRuns || []).filter((p) => p.status === 'completed' && Number(p.produced_qty) > 0).sort((a, b) => String(a.completed_date).localeCompare(String(b.completed_date)));
    const cpu = (p: any) => ((Number(p.material_cost) || 0) + (Number(p.labor_cost) || 0) + (Number(p.overhead_cost) || 0)) / Number(p.produced_qty);
    const out: Exception[] = [];
    const byItem: Record<string, any[]> = {}; for (const r of runs) (byItem[r.variant_id || r.product_id] ||= []).push(r);
    for (const [id, list] of Object.entries(byItem)) {
      if (list.length < 3) continue;
      const last = list[list.length - 1], prior = list.slice(0, -1), avg = prior.reduce((a, r) => a + cpu(r), 0) / prior.length, ch = pctChange(cpu(last), avg);
      if (ch !== null && ch >= t.mfg_cost_increase_pct) out.push({ exception_type: 'mfg_cost_increase', fingerprint: `exc:mfgcost:${id}`, severity: ch >= 25 ? 'high' : 'moderate', title: `Manufacturing cost per unit up ${f(ch)}%`, business_area: 'Manufacturing', what_happened: `Latest batch ${last.batch_number || ''} cost ${f(cpu(last), 2)}/unit vs average ${f(avg, 2)}.`, when_happened: new Date().toISOString(), why_it_matters: 'Higher unit costs lower margin on every sale.', potential_impact: 'Use multi-agent analysis (manufacturing + purchasing + finance + sales) to see effects on pricing.', recommended_action: 'Ask the advisor: "Why did manufacturing costs increase?"', supporting_records: list.slice(-3).map((r) => ({ entity: 'ProductionRun', id: r.id })), metrics: { latest_cpu: round(cpu(last)), average_cpu: round(avg), change_pct: round(ch, 1) } });
    }
    return out;
  },
  overdue: (d, t, now) => (d.invoices || []).filter((i) => i.due_date && !['paid', 'written_off'].includes(i.status) && toDate(i.due_date)!.getTime() + t.overdue_days * DAY < now.getTime()).map((i) => { const days = Math.round((now.getTime() - toDate(i.due_date)!.getTime()) / DAY); const owed = (Number(i.amount) || 0) - (Number(i.amount_paid) || 0); return { exception_type: 'overdue_payment', fingerprint: `exc:overdue:${i.id}`, severity: days > 60 ? 'high' : days > 30 ? 'moderate' : 'low', title: `Invoice ${i.invoice_number || ''} is ${days} days overdue`, business_area: 'Finance', what_happened: `${f(owed, 0)} outstanding, due ${i.due_date}.`, when_happened: now.toISOString(), why_it_matters: 'Unpaid invoices reduce cash.', potential_impact: `${f(owed, 0)} of cash not collected.`, recommended_action: 'Contact the customer (a reminder draft can be prepared; sending needs approval).', supporting_records: [{ entity: 'Invoice', id: i.id }], metrics: { days_overdue: days, owed } }; }),
  unprofitable: (d, t, now) => computeSnapshot(d, now).products.filter((p) => p.margin_pct !== null && p.margin_pct <= t.unprofitable_margin_pct && (p.revenue_90d || 0) > 0).map((p) => ({ exception_type: 'unprofitable_product', fingerprint: `exc:unprof:${p.id}`, severity: 'high', title: `${p.name} is selling at or below cost`, business_area: 'Product', what_happened: `Margin ${f(p.margin_pct)}% on ${f(p.revenue_90d, 0)} of 90-day sales.`, when_happened: now.toISOString(), why_it_matters: 'Each sale loses money.', potential_impact: 'Check pricing, discounts and unit cost data before acting.', recommended_action: 'Verify unit cost; consider price change (requires approval).', supporting_records: [{ entity: 'Product', id: p.id }], metrics: { margin_pct: p.margin_pct } })),
};
export const DETECTORS_FOR_ENTITY: Record<string, string[]> = { Sale: ['declining_sales', 'inventory', 'falling_margin'], Expense: ['increasing_expenses'], InventoryItem: ['inventory'], ProductionRun: ['production', 'mfg_cost'], Invoice: ['overdue'], Product: ['unprofitable'], ProductVariant: ['unprofitable'] };

export function detectExceptions(d: BusinessData, thresholds: any, now = new Date(), only?: string[]) {
  return Object.entries(DETECTORS).filter(([k]) => !only || only.includes(k)).flatMap(([, fn]) => { try { return fn(d, thresholds, now); } catch { return []; } });
}

// Upsert alerts: never re-alert an unchanged open issue; escalate when severity rises; re-open as new after closure.
export async function upsertAlerts(svc: any, businessId: string, list: Exception[], settings: any, now = new Date(), scope?: string[]) {
  const open: any[] = await svc.entities.Alert.filter({ business_id: businessId }, '-created_date', 2000);
  const byFp = new Map(open.filter((a) => a.status !== 'closed').map((a) => [a.fingerprint, a]));
  let created = 0, escalated = 0, unchanged = 0;
  const notify: any[] = [];
  for (const e of list) {
    const ex = byFp.get(e.fingerprint);
    if (ex) {
      const up = sevRank(e.severity) > sevRank(ex.severity);
      await svc.entities.Alert.update(ex.id, { last_seen_at: now.toISOString(), occurrences: (ex.occurrences || 1) + 1, metrics: e.metrics, ...(up ? { severity: e.severity, title: e.title, what_happened: e.what_happened } : {}) });
      if (up) { escalated++; notify.push(e); } else unchanged++;
      byFp.delete(e.fingerprint);
    } else {
      await svc.entities.Alert.create({ business_id: businessId, ...e, status: 'open', occurrences: 1, last_seen_at: now.toISOString(), detected_by: 'rules', notes: [] });
      created++; notify.push(e);
    }
  }
  // Auto-resolve open alerts whose condition cleared (only for detectors that ran).
  let resolved = 0;
  for (const a of byFp.values()) {
    if (a.status === 'closed' || a.detected_by !== 'rules') continue;
    if (scope && !scope.includes(mapType(a.exception_type))) continue;
    await svc.entities.Alert.update(a.id, { status: 'closed', closed_at: now.toISOString(), resolution: 'Condition no longer detected (auto-resolved).' }); resolved++;
  }
  const min = sevRank(settings.escalation?.notify_min_severity || 'high');
  const roles = settings.escalation?.notify_roles || ['owner', 'admin'];
  const members = (await svc.entities.BusinessMember.filter({ business_id: businessId, status: 'active' })).filter((m: any) => roles.includes(m.role));
  for (const e of notify.filter((x) => sevRank(x.severity) >= min)) for (const m of members) await svc.entities.Notification.create({ business_id: businessId, user_id: m.user_id, title: e.title, body: `${e.what_happened}\nRecommended: ${e.recommended_action}`, level: e.severity === 'critical' ? 'critical' : 'warning', link: '/alerts', related_entity: 'Alert', related_id: e.fingerprint });
  return { created, escalated, unchanged, resolved };
}
const mapType = (t: string) => ({ declining_sales: 'declining_sales', increasing_expenses: 'increasing_expenses', falling_margin: 'falling_margin', stock_shortage: 'inventory', excess_inventory: 'inventory', production_delay: 'production', mfg_cost_increase: 'mfg_cost', overdue_payment: 'overdue', unprofitable_product: 'unprofitable' } as any)[t];

// Opportunity detection & ranking (value, feasibility, urgency, evidence, implementation cost).
export function detectOpportunities(d: BusinessData, findings: any[], now = new Date()) {
  const s = computeSnapshot(d, now);
  const opps: any[] = findings.filter((x) => x.level === 'opportunity').map((x) => ({ title: x.title, category: x.category, description: `${x.situation} ${x.recommendation}`, estimated_value: null, value_basis: 'estimated', feasibility: x.effort === 'low' ? 'high' : x.effort === 'medium' ? 'medium' : 'low', urgency: x.urgency >= 0.6 ? 'high' : x.urgency >= 0.4 ? 'medium' : 'low', implementation_cost: null, evidence: x.evidence, confidence: x.confidence, fingerprint: `opp:${x.fingerprint}` }));
  // Supplier negotiation: concentrated spend
  const spend: Record<string, number> = {}; for (const e of d.expenses || []) if (e.vendor && ['cogs_materials', 'packaging', 'manufacturing'].includes(e.category)) spend[e.vendor] = (spend[e.vendor] || 0) + (Number(e.amount) || 0);
  const top = Object.entries(spend).sort((a, b) => b[1] - a[1])[0];
  if (top && top[1] > 5000) opps.push({ title: `Negotiate terms with ${top[0]}`, category: 'cost_reduction', description: `${Math.round(top[1]).toLocaleString()} spent with this supplier (recorded expenses). A 5% saving would be about ${Math.round(top[1] * 0.05).toLocaleString()} (illustrative estimate).`, estimated_value: Math.round(top[1] * 0.05), value_basis: 'estimated', feasibility: 'medium', urgency: 'low', implementation_cost: 0, evidence: [{ label: 'Spend with supplier', value: Math.round(top[1]), basis: 'actual', entity: 'Expense' }], confidence: 'moderate', fingerprint: `opp:supplier:${top[0]}` });
  // Excess inventory to cash
  const cap = s.inventory.filter((i) => i.flags.includes('overstock')).reduce((a, i) => a + (i.capital || 0), 0);
  if (cap > 1000) opps.push({ title: 'Turn excess stock into cash', category: 'cash', description: `About ${Math.round(cap).toLocaleString()} (at cost) is in overstocked items.`, estimated_value: Math.round(cap * 0.5), value_basis: 'estimated', feasibility: 'high', urgency: 'medium', implementation_cost: 0, evidence: [{ label: 'Overstock capital', value: Math.round(cap), basis: 'actual' }], confidence: 'moderate', fingerprint: 'opp:excess_to_cash' });
  // Pricing: high-margin best sellers growing — test small price increase
  for (const p of s.products.filter((x) => x.tags.includes('best_seller') && x.margin_pct !== null && (x.growth_pct || 0) > 10).slice(0, 1)) opps.push({ title: `Test a small price increase on ${p.name}`, category: 'pricing', description: `Demand is growing (+${p.growth_pct}%) at ${p.margin_pct}% margin. A 3–5% test on one channel would show price sensitivity. Price changes require approval.`, estimated_value: Math.round((p.revenue_90d || 0) / 3 * 0.03), value_basis: 'estimated', feasibility: 'medium', urgency: 'low', implementation_cost: 0, evidence: [{ label: 'Growth', value: p.growth_pct, basis: 'actual' }, { label: 'Monthly revenue', value: Math.round((p.revenue_90d || 0) / 3), basis: 'actual' }], confidence: 'low', fingerprint: `opp:price:${p.id}` });
  const L = { high: 3, medium: 2, low: 1 } as any, C = { high: 3, moderate: 2, low: 1 } as any;
  return opps.map((o) => ({ ...o, rank_score: Math.round(((o.estimated_value ? Math.min(3, Math.log10(o.estimated_value + 1)) : 1.5) + L[o.feasibility] + L[o.urgency] + C[o.confidence] - (o.implementation_cost ? 0.5 : 0)) * 100) / 100 })).sort((a, b) => b.rank_score - a.rank_score);
}

export async function upsertOpportunities(svc: any, businessId: string, opps: any[]) {
  const ex: any[] = await svc.entities.Opportunity.filter({ business_id: businessId }, '-created_date', 2000);
  const by = new Map(ex.map((o) => [o.fingerprint, o]));
  for (const o of opps) { const e = by.get(o.fingerprint); if (e) { if (e.status === 'open') await svc.entities.Opportunity.update(e.id, o); } else await svc.entities.Opportunity.create({ business_id: businessId, status: 'open', ...o }); }
  return opps.length;
}

export async function runMonitoringFor(svc: any, businessId: string, data: BusinessData, now = new Date(), only?: string[]) {
  const settings = await getSettings(svc, businessId);
  const list = detectExceptions(data, settings.thresholds, now, only);
  const res = await upsertAlerts(svc, businessId, list, settings, now, only);
  return { exceptions: list.length, ...res };
}
