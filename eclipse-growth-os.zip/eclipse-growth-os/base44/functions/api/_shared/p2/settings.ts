// Per-business admin configuration with safe defaults (Prompt 2 · Sections 6, 21, 31, 32, 35).
export const AGENT_KEYS = ['cbio', 'finance', 'sales', 'marketing', 'manufacturing', 'inventory', 'customer', 'growth', 'risk'] as const;

// Actions the AI may never perform on its own; always routed through ApprovalRequest.
export const CONSEQUENTIAL_ACTIONS = ['payment', 'purchase', 'transfer_funds', 'change_price', 'send_external_message', 'publish_marketing', 'delete_record', 'change_permissions', 'supplier_agreement', 'customer_agreement', 'purchase_order'];

export const DEFAULT_SETTINGS = {
  agents_enabled: Object.fromEntries(AGENT_KEYS.map((k) => [k, true])),
  thresholds: {
    sales_decline_pct: 15, expense_increase_pct: 20, margin_drop_points: 5, excess_inventory_days: 180, stockout_days_buffer: 7,
    overdue_days: 1, production_delay_days: 3, mfg_cost_increase_pct: 10, unprofitable_margin_pct: 0,
  },
  escalation: { notify_min_severity: 'high', notify_roles: ['owner', 'admin'] },
  // 'owner_direct' = owners may act directly; everyone else (and the AI) needs approval.
  approval_rules: { delete_record: 'owner_direct', change_price: 'approval', purchase_order: 'approval', send_external_message: 'approval', publish_marketing: 'approval', change_permissions: 'owner_direct' },
  workflow_modes: { low_stock_purchase: 'approval_required', customer_followup: 'approval_required', production_recommendation: 'automatic', sales_report: 'automatic', management_report: 'automatic', marketing_campaign_draft: 'approval_required' },
  monitoring_frequency: 'daily', event_monitoring: true,
  report_schedule: { weekly_review: true, daily_briefing: false, monthly_review: true },
  ai_model_routine: '', ai_model_complex: '', ai_fallback_models: [] as string[], ai_monthly_request_cap: 2000,
  integrations_enabled: true, departments: ['Sales', 'Marketing', 'Production', 'Finance', 'Operations', 'Management'], data_retention_days: 0,
};
export const COST_PER_1K_TOKENS_USD = { routine: 0.002, complex: 0.01 }; // planning estimate only, shown as an estimate

const SEV = ['informational', 'low', 'moderate', 'high', 'critical'];
export const sevRank = (s: string) => SEV.indexOf(s);

export async function getSettings(svc: any, businessId: string) {
  const rows = await svc.entities.BusinessSettings.filter({ business_id: businessId }, '-created_date', 1);
  if (rows[0]) return { ...DEFAULT_SETTINGS, ...rows[0], thresholds: { ...DEFAULT_SETTINGS.thresholds, ...(rows[0].thresholds || {}) }, agents_enabled: { ...DEFAULT_SETTINGS.agents_enabled, ...(rows[0].agents_enabled || {}) }, approval_rules: { ...DEFAULT_SETTINGS.approval_rules, ...(rows[0].approval_rules || {}) }, workflow_modes: { ...DEFAULT_SETTINGS.workflow_modes, ...(rows[0].workflow_modes || {}) }, escalation: { ...DEFAULT_SETTINGS.escalation, ...(rows[0].escalation || {}) }, report_schedule: { ...DEFAULT_SETTINGS.report_schedule, ...(rows[0].report_schedule || {}) } };
  const created = await svc.entities.BusinessSettings.create({ business_id: businessId, ...DEFAULT_SETTINGS });
  return { ...DEFAULT_SETTINGS, ...created };
}
