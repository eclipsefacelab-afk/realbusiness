// AI usage, cost estimates, model routing, fallback and monthly caps (Section 32).
import { getSettings, COST_PER_1K_TOKENS_USD } from './settings.ts';
import type { LLMHooks } from '../llm.ts';

export function usageHooks(svc: any, businessId: string, user?: any): LLMHooks {
  let settingsP: Promise<any> | null = null;
  const settings = () => (settingsP ||= getSettings(svc, businessId).catch(() => ({})));
  const hooks: LLMHooks = {
    log: async (e: any) => {
      const tier = e.tier === 'complex' ? 'complex' : 'routine';
      const est = e.est_tokens ?? Math.ceil(((e.prompt_chars || 0) + (e.response_chars || 0)) / 4);
      try { await svc.entities.AIUsageLog.create({ business_id: businessId, user_id: user?.id, ...e, tier, est_tokens: est, est_cost_usd: Math.round((est / 1000) * COST_PER_1K_TOKENS_USD[tier] * 10000) / 10000 }); } catch { /* never block on logging */ }
    },
    cap: async () => {
      const s = await settings();
      const cap = Number(s.ai_monthly_request_cap) || 0;
      if (!cap) return true;
      const start = new Date(); start.setUTCDate(1); start.setUTCHours(0, 0, 0, 0);
      const rows = await svc.entities.AIUsageLog.filter({ business_id: businessId }, '-created_date', cap + 50).catch(() => []);
      return rows.filter((r: any) => r.created_date >= start.toISOString() && r.status !== 'blocked_cap').length < cap;
    },
  };
  // Model routing resolved lazily; empty = platform default model.
  Object.defineProperty(hooks, 'models', { enumerable: true, get() { return (hooks as any)._models; } });
  (hooks as any).ready = settings().then((s) => { (hooks as any)._models = { routine: s.ai_model_routine || undefined, complex: s.ai_model_complex || undefined, fallbacks: s.ai_fallback_models || [] }; });
  return hooks;
}

export function summariseUsage(rows: any[]) {
  const month = new Date().toISOString().slice(0, 7);
  const m = rows.filter((r) => String(r.created_date).startsWith(month));
  const by = (k: string) => Object.entries(m.reduce((o: any, r: any) => { const key = r[k] || 'other'; o[key] = o[key] || { requests: 0, tokens: 0, cost: 0, errors: 0 }; o[key].requests++; o[key].tokens += r.est_tokens || 0; o[key].cost += r.est_cost_usd || 0; if (['error', 'rate_limited'].includes(r.status)) o[key].errors++; return o; }, {})).map(([key, v]: any) => ({ key, ...v, cost: Math.round(v.cost * 100) / 100 }));
  return { month, requests: m.length, est_tokens: m.reduce((t, r) => t + (r.est_tokens || 0), 0), est_cost_usd: Math.round(m.reduce((t, r) => t + (r.est_cost_usd || 0), 0) * 100) / 100, errors: m.filter((r) => ['error', 'rate_limited'].includes(r.status)).length, blocked: m.filter((r) => r.status === 'blocked_cap').length, by_purpose: by('purpose'), by_agent: by('agent_key'), by_model: by('model'), note: 'Token counts and costs are estimates (characters ÷ 4 × configured planning rate), not provider invoices.' };
}
