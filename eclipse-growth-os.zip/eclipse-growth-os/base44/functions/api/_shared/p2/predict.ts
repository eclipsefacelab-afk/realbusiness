// Forecasting, scenario simulation and expansion readiness (Sections 9–13, 18; Prompt 1 §16–19).
import { computeSnapshot, monthlySeries, saleRevenue, toDate, DAY, round, iso, type BusinessData } from '../metrics.ts';

function regress(ys: number[]) {
  const n = ys.length, xs = ys.map((_, i) => i), mx = (n - 1) / 2, my = ys.reduce((a, b) => a + b, 0) / n;
  const b = xs.reduce((a, x, i) => a + (x - mx) * (ys[i] - my), 0) / (xs.reduce((a, x) => a + (x - mx) ** 2, 0) || 1);
  const a = my - b * mx;
  const resid = Math.sqrt(ys.reduce((s, y, i) => s + (y - (a + b * i)) ** 2, 0) / Math.max(1, n - 2));
  return { a, b, resid, my };
}

// Forecast a monthly series. Requires ≥3 complete months; otherwise returns a refusal with reason.
export function forecastSeries(history: { period: string; value: number }[], horizon = 6, opts: { label: string; allowNegative?: boolean } = { label: 'value' }) {
  const h = history.filter((x) => x.value !== null && x.value !== undefined);
  if (h.length < 3) return { ok: false, reason: `Not enough history for ${opts.label}: ${h.length} complete month(s); at least 3 needed.` };
  const ys = h.map((x) => x.value), r = regress(ys);
  const seasonal = h.length >= 13;
  const last = h[h.length - 1].period;
  const out = { conservative: [] as any[], expected: [] as any[], aggressive: [] as any[] };
  for (let i = 1; i <= horizon; i++) {
    const d = new Date(last + '-01T00:00:00Z'); d.setUTCMonth(d.getUTCMonth() + i);
    const period = iso(d).slice(0, 7);
    let exp = r.a + r.b * (ys.length - 1 + i);
    if (seasonal) { const ly = h.find((x) => x.period === `${Number(period.slice(0, 4)) - 1}${period.slice(4)}`); if (ly && r.my > 0) exp = exp * 0.6 + (ly.value * (1 + r.b / r.my * 12)) * 0.4; }
    const band = r.resid * Math.sqrt(1 + i / ys.length) * 1.28; // ~80% band
    const clamp = (v: number) => (opts.allowNegative ? v : Math.max(0, v));
    out.conservative.push({ period, value: round(clamp(exp - band)) }); out.expected.push({ period, value: round(clamp(exp)) }); out.aggressive.push({ period, value: round(clamp(exp + band)) });
  }
  const cv = r.my ? r.resid / Math.abs(r.my) : 1;
  return {
    ok: true, method: seasonal ? 'Linear trend blended with same-month-last-year (seasonal)' : 'Linear trend on monthly history', history_points: h.length, ...out,
    confidence: h.length >= 12 && cv < 0.15 ? 'high' : h.length >= 6 && cv < 0.3 ? 'moderate' : 'low',
    assumptions: [`Based on ${h.length} months of actual records.`, `Trend: ${r.b >= 0 ? '+' : ''}${Math.round(r.b)} per month.`, 'Conservative/aggressive = roughly an 80% range from past month-to-month variation.', 'Does not know about future events, launches, price changes or new channels unless you model them as a scenario.', 'A forecast is not a guarantee.'],
  };
}

function completeMonths(d: BusinessData, now: Date) {
  const series = monthlySeries(d.sales, 24, now).slice(0, -1); // drop current partial month
  const firstIdx = series.findIndex((x) => x.revenue > 0);
  return firstIdx < 0 ? [] : series.slice(firstIdx === 0 ? 0 : firstIdx + 1); // drop first (likely partial) month
}

export function buildForecasts(d: BusinessData, now = new Date(), horizon = 6) {
  const s = computeSnapshot(d, now);
  const months = completeMonths(d, now);
  const revenue = forecastSeries(months.map((m) => ({ period: m.period, value: m.revenue })), horizon, { label: 'revenue' });
  const units = forecastSeries(months.map((m) => ({ period: m.period, value: m.units })), horizon, { label: 'units' });
  // Expenses by month
  const expM: Record<string, number> = {}; for (const e of d.expenses || []) if (e.date) expM[String(e.date).slice(0, 7)] = (expM[String(e.date).slice(0, 7)] || 0) + (Number(e.amount) || 0);
  const cm = iso(now).slice(0, 7);
  const expenses = forecastSeries(Object.entries(expM).filter(([p]) => p < cm).sort().map(([period, value]) => ({ period, value })), horizon, { label: 'expenses' });
  // Cash flow: cash + expected revenue × margin − expected opex
  let cash: any = { ok: false, reason: 'Needs a cash balance, revenue forecast and margin.' };
  if (revenue.ok && s.cash.value !== null && s.gross_margin_pct.value !== null && (expenses.ok || s.opex_monthly.value !== null)) {
    const gm = s.gross_margin_pct.value / 100, opexNonCogs = s.opex_monthly.value || 0;
    const path = (rev: any[]) => { let c = s.cash.value!; return rev.map((r: any) => { c += r.value * gm - opexNonCogs; return { period: r.period, value: round(c) }; }); };
    cash = { ok: true, method: 'Starting cash + forecast revenue × gross margin − average running costs', conservative: path((revenue as any).conservative), expected: path((revenue as any).expected), aggressive: path((revenue as any).aggressive), confidence: (revenue as any).confidence === 'high' && s.cash.basis === 'actual' ? 'moderate' : 'low', assumptions: [`Starting cash ${Math.round(s.cash.value)} (${s.cash.basis}).`, `Gross margin ${round(s.gross_margin_pct.value, 1)}% (${s.gross_margin_pct.basis}).`, `Running costs ${Math.round(opexNonCogs)}/month (${s.opex_monthly.basis}).`, 'Ignores loan repayments, tax payments, timing of receivables/payables and capital purchases unless recorded as expenses.'] };
    const firstNeg = (cash.conservative as any[]).find((x) => x.value < 0);
    if (firstNeg) cash.warning = `In the conservative case cash could go negative around ${firstNeg.period} (forecast).`;
  }
  // Product demand & inventory requirements (per stock item)
  const demand = s.inventory.map((i) => {
    const v = i.velocity_per_day || 0, lead = i.lead_time_days ?? 21, cover = 30;
    const need = Math.max(0, Math.ceil(v * (lead + cover) - i.on_hand));
    return { id: i.id, name: i.name, velocity_per_day: i.velocity_per_day, demand_30d: Math.round(v * 30), demand_90d: Math.round(v * 90), on_hand: i.on_hand, lead_time_days: i.lead_time_days, recommended_order_qty: v > 0 ? need : 0, reorder_by: v > 0 && i.days_of_cover !== null ? iso(new Date(now.getTime() + Math.max(0, (i.days_of_cover - lead)) * DAY)) : null, assumptions: `Last-30-day rate ${i.velocity_per_day}/day; lead time ${i.lead_time_days ?? '21 (assumed)'} days; target 30 days of cover after arrival.` };
  });
  // Customer growth
  const firsts: Record<string, string> = {}; for (const x of d.sales) if (x.customer_id && (!firsts[x.customer_id] || x.date < firsts[x.customer_id])) firsts[x.customer_id] = x.date;
  const newByMonth: Record<string, number> = {}; for (const dt of Object.values(firsts)) newByMonth[dt.slice(0, 7)] = (newByMonth[dt.slice(0, 7)] || 0) + 1;
  const customers = forecastSeries(months.map((m) => ({ period: m.period, value: newByMonth[m.period] || 0 })), horizon, { label: 'new customers' });
  // Customer behaviour (Section 13)
  const custStats: Record<string, { n: number; last: string; spent: number; gaps: number[] }> = {};
  const sorted = [...d.sales].filter((x) => x.customer_id).sort((a, b) => String(a.date).localeCompare(String(b.date)));
  const lastDate: Record<string, string> = {};
  for (const x of sorted) { const c = (custStats[x.customer_id] ||= { n: 0, last: x.date, spent: 0, gaps: [] }); if (lastDate[x.customer_id] && lastDate[x.customer_id] !== x.date) c.gaps.push((toDate(x.date)!.getTime() - toDate(lastDate[x.customer_id])!.getTime()) / DAY); if (lastDate[x.customer_id] !== x.date) c.n++; c.last = x.date; c.spent += saleRevenue(x); lastDate[x.customer_id] = x.date; }
  const behaviour = Object.entries(custStats).filter(([, c]) => c.n >= 2).map(([id, c]) => { const avgGap = c.gaps.reduce((a, b) => a + b, 0) / (c.gaps.length || 1); const since = (now.getTime() - toDate(c.last)!.getTime()) / DAY; return { customer_id: id, orders: c.n, spent: round(c.spent), avg_days_between: Math.round(avgGap), days_since_last: Math.round(since), status: since > avgGap * 2 ? 'declining' : since >= avgGap * 0.8 ? 'likely_to_buy_soon' : 'active' }; });
  const pairs: Record<string, number> = {}; const byOrder: Record<string, Set<string>> = {}; for (const x of d.sales) if (x.order_id) (byOrder[x.order_id] ||= new Set()).add(x.variant_id || x.product_id);
  for (const set of Object.values(byOrder)) { const a = [...set].filter(Boolean).sort(); for (let i = 0; i < a.length; i++) for (let j = i + 1; j < a.length; j++) pairs[`${a[i]}|${a[j]}`] = (pairs[`${a[i]}|${a[j]}`] || 0) + 1; }
  const nameOf = (id: string) => s.variants.find((v) => v.id === id)?.name || s.products.find((p) => p.id === id)?.name || id;
  const combos = Object.entries(pairs).sort((a, b) => b[1] - a[1]).slice(0, 8).filter(([, n]) => n >= 3).map(([k, n]) => ({ items: k.split('|').map(nameOf), orders: n }));
  return { revenue, units, expenses, cash, customers, demand, customer_behaviour: { likely_to_buy_soon: behaviour.filter((b) => b.status === 'likely_to_buy_soon').length, declining: behaviour.filter((b) => b.status === 'declining').length, list: behaviour.sort((a, b) => (b.spent || 0) - (a.spent || 0)).slice(0, 50), combos, note: 'Based on purchase intervals of customers with 2+ orders; identities are shown as record IDs and only to roles with customer access.' }, generated_at: now.toISOString() };
}

// Compare stored forecasts with actuals.
export function compareForecastActuals(forecast: any, months: { period: string; revenue: number }[]) {
  return (forecast.expected || []).map((f: any) => { const a = months.find((m) => m.period === f.period); return { period: f.period, forecast: f.value, actual: a ? a.revenue : null, error_pct: a && a.revenue ? round(((f.value - a.revenue) / a.revenue) * 100, 1) : null }; }).filter((x: any) => x.actual !== null);
}

// ── Scenario simulation (estimates only)
export type ScenarioInput = { kind: string; params: Record<string, number>; name?: string };
export const SCENARIO_KINDS: Record<string, { label: string; params: [string, string, number][] }> = {
  sales_change: { label: 'Sales change', params: [['sales_change_pct', 'Change in sales (%)', 20]] },
  price_change: { label: 'Price change', params: [['price_change_pct', 'Price change (%)', -10], ['elasticity', 'Volume response per 1% price change (assumption)', -1.2]] },
  material_cost: { label: 'Raw material / product cost change', params: [['cost_change_pct', 'Product cost change (%)', 15]] },
  marketing_budget: { label: 'Marketing budget change', params: [['budget_change_pct', 'Marketing budget change (%)', 20], ['return_per_dollar', 'Revenue per extra $1 of marketing (assumption)', 1.5]] },
  hire: { label: 'Hire employees', params: [['count', 'Number of hires', 2], ['monthly_cost_each', 'Monthly cost per hire (salary + benefits)', 4000], ['revenue_uplift_pct', 'Expected sales uplift (%) (assumption)', 0]] },
  new_product: { label: 'Introduce a product', params: [['monthly_units', 'Expected units / month (assumption)', 150], ['price', 'Price', 30], ['unit_cost', 'Unit cost', 8], ['launch_cost', 'One-time launch cost', 5000], ['cannibalization_pct', 'Share taken from existing sales (%)', 10]] },
  new_location: { label: 'Open a location', params: [['monthly_rent', 'Monthly rent', 4000], ['monthly_staff', 'Monthly staff cost', 7000], ['other_monthly', 'Other monthly costs', 1500], ['fitout_cost', 'One-time setup cost', 40000], ['expected_monthly_sales', 'Expected monthly sales (assumption)', 18000], ['ramp_months', 'Months to reach expected sales', 6], ['cannibalization_pct', 'Cannibalization of existing sales (%)', 5]] },
  new_market: { label: 'Enter a new province/country (e.g. expand in Jamaica)', params: [['setup_cost', 'One-time setup (registration, compliance, shipping setup)', 15000], ['monthly_fixed', 'Monthly fixed costs in market', 3000], ['expected_monthly_sales', 'Expected monthly sales (assumption)', 8000], ['ramp_months', 'Months to reach expected sales', 9], ['extra_cost_pct', 'Extra cost per sale: duties/shipping (% of sales)', 12]] },
};

export function simulate(d: BusinessData, input: ScenarioInput, now = new Date()) {
  const s = computeSnapshot(d, now);
  const rev = s.revenue_monthly_avg_90d.value ?? s.revenue_30d.value, gm = s.gross_margin_pct.value, opex = s.opex_monthly.value, cash = s.cash.value;
  const missing = [!rev && 'monthly revenue', gm === null && 'gross margin', opex === null && 'running costs'].filter(Boolean);
  if (missing.length) return { ok: false, reason: `Cannot simulate without: ${missing.join(', ')}. Add data or onboarding estimates first.` };
  const p = { ...Object.fromEntries((SCENARIO_KINDS[input.kind]?.params || []).map(([k, , v]) => [k, v])), ...(input.params || {}) } as Record<string, number>;
  const base = { revenue: rev!, gross_profit: rev! * gm! / 100, opex: opex!, net: rev! * gm! / 100 - opex! };
  let r = { ...base }; let oneTime = 0, ramp = 0; const assumptions: string[] = [`Baseline monthly revenue ${Math.round(rev!)} (${s.revenue_monthly_avg_90d.value !== null ? 'actual 90-day average' : s.revenue_30d.basis}), margin ${round(gm!, 1)}% (${s.gross_margin_pct.basis}), running costs ${Math.round(opex!)} (${s.opex_monthly.basis}).`];
  const risks: string[] = [];
  switch (input.kind) {
    case 'sales_change': r.revenue = rev! * (1 + p.sales_change_pct / 100); r.gross_profit = r.revenue * gm! / 100; assumptions.push('Margin % unchanged; running costs unchanged (more sales may need more stock and staff).'); if (p.sales_change_pct > 25) risks.push('Large growth needs inventory and production capacity — check stock cover.'); break;
    case 'price_change': { const vol = 1 + (p.elasticity * p.price_change_pct) / 100; r.revenue = rev! * (1 + p.price_change_pct / 100) * vol; const cogs = rev! * (1 - gm! / 100) * vol; r.gross_profit = r.revenue - cogs; assumptions.push(`Volume changes ${round((vol - 1) * 100, 1)}% (elasticity ${p.elasticity} is an assumption — test before rolling out).`); risks.push('Price perception and competitor response are not modelled.'); break; }
    case 'material_cost': { const cogs = rev! * (1 - gm! / 100) * (1 + p.cost_change_pct / 100); r.gross_profit = rev! - cogs; assumptions.push('Prices and volumes unchanged.'); risks.push('Consider price change or supplier negotiation to recover margin.'); break; }
    case 'marketing_budget': { const spend = (s.marketing_spend_90d.value || 0) / 3; const extra = spend * p.budget_change_pct / 100; r.opex = opex! + extra; r.revenue = rev! + extra * p.return_per_dollar; r.gross_profit = r.revenue * gm! / 100; assumptions.push(`Current marketing ≈${Math.round(spend)}/month; extra ${Math.round(extra)}. Return of ${p.return_per_dollar} revenue per $1 is an assumption — your tracked campaigns can refine it.`); if (!spend) risks.push('No recorded marketing spend; result depends entirely on the assumption.'); break; }
    case 'hire': r.opex = opex! + p.count * p.monthly_cost_each; r.revenue = rev! * (1 + p.revenue_uplift_pct / 100); r.gross_profit = r.revenue * gm! / 100; assumptions.push(`${p.count} hire(s) at ${p.monthly_cost_each}/month each.`); risks.push('Recruiting and training time before productivity.'); break;
    case 'new_product': { const add = p.monthly_units * p.price, cann = rev! * p.cannibalization_pct / 100 * 0.1; r.revenue = rev! + add - cann; r.gross_profit = base.gross_profit + p.monthly_units * (p.price - p.unit_cost) - cann * gm! / 100; oneTime = p.launch_cost; ramp = 3; assumptions.push(`${p.monthly_units} units/month at ${p.price} (assumption); 3-month ramp.`); risks.push('New-product demand is uncertain; consider a limited test batch.'); break; }
    case 'new_location': case 'new_market': { const isLoc = input.kind === 'new_location'; const sales = p.expected_monthly_sales; const fixed = isLoc ? p.monthly_rent + p.monthly_staff + p.other_monthly : p.monthly_fixed; const extra = isLoc ? 0 : sales * p.extra_cost_pct / 100; const cann = isLoc ? rev! * p.cannibalization_pct / 100 : 0; r.revenue = rev! + sales - cann; r.gross_profit = base.gross_profit + sales * gm! / 100 - extra - cann * gm! / 100; r.opex = opex! + fixed; oneTime = isLoc ? p.fitout_cost : p.setup_cost; ramp = p.ramp_months; assumptions.push(`Expected sales ${sales}/month after ${ramp} months (assumption — no market research is included; enter your own evidence).`, `Fixed costs ${fixed}/month.`); risks.push(isLoc ? 'Lease commitments are hard to reverse.' : 'Import duties, regulations and product registration vary by country — consult a qualified advisor.', 'Management attention is diverted from the existing business.'); break; }
    default: return { ok: false, reason: 'Unknown scenario type.' };
  }
  r.net = r.gross_profit - r.opex;
  const delta = r.net - base.net;
  // Cash requirement during ramp: one-time + losses until ramped (linear ramp)
  let cum = -oneTime, minCash = -oneTime, breakEvenMonth: number | null = null;
  for (let m = 1; m <= 36; m++) { const f = ramp ? Math.min(1, m / ramp) : 1; const monthDelta = delta * f + (ramp ? (base.net - base.net) : 0); cum += monthDelta; minCash = Math.min(minCash, cum); if (breakEvenMonth === null && cum >= 0) breakEvenMonth = m; }
  const cashNeed = Math.max(0, -minCash);
  if (cash !== null && cashNeed > cash * 0.5) risks.push(`Needs about ${Math.round(cashNeed)} of cash — more than half of current cash (${Math.round(cash)}).`);
  return { ok: true, label: 'ESTIMATE — simulated, not actual results', kind: input.kind, params: p, baseline: mapRound(base), scenario: mapRound(r), change: { revenue: round(r.revenue - base.revenue), net_monthly: round(delta) }, one_time_cost: oneTime, cash_requirement: round(cashNeed), break_even_month: breakEvenMonth, break_even_note: breakEvenMonth ? `Recovers the one-time cost and ramp losses in about ${breakEvenMonth} months (estimate).` : delta <= 0 ? 'Does not break even under these assumptions.' : 'Does not break even within 36 months.', assumptions, risks };
}
const mapRound = (o: any) => Object.fromEntries(Object.entries(o).map(([k, v]) => [k, round(v as number)]));

// Expansion readiness gate — willing to say "not yet".
export function expansionReadiness(d: BusinessData, now = new Date(), health?: number | null) {
  const s = computeSnapshot(d, now);
  const checks = [
    { key: 'health', label: 'Business health ≥ 60', pass: health !== null && health !== undefined ? health >= 60 : null, detail: `Score ${health ?? 'n/a'}` },
    { key: 'profit', label: 'Profitable (estimated monthly profit > 0)', pass: s.net_profit_monthly.value === null ? null : s.net_profit_monthly.value > 0, detail: `${s.net_profit_monthly.value === null ? 'unknown' : Math.round(s.net_profit_monthly.value)} (${s.net_profit_monthly.basis || 'no data'})` },
    { key: 'cash', label: 'Cash ≥ 6 months of running costs', pass: s.cash.value === null || s.opex_monthly.value === null ? null : s.cash.value >= 6 * s.opex_monthly.value, detail: `${s.cash.value ?? 'n/a'} cash vs ${s.opex_monthly.value ? Math.round(6 * s.opex_monthly.value) : 'n/a'} needed` },
    { key: 'demand', label: 'Sales growing or stable for 60+ days', pass: s.revenue_change_pct.value === null ? null : s.revenue_change_pct.value >= -5, detail: s.revenue_change_pct.value === null ? 'Trend not measured' : `${round(s.revenue_change_pct.value, 1)}%` },
    { key: 'ops', label: 'No critical stock-outs on best sellers', pass: s.inventory.length ? !s.inventory.some((i) => i.is_best_seller && i.flags.includes('stockout_risk')) : null, detail: `${s.inventory.filter((i) => i.is_best_seller && i.flags.includes('stockout_risk')).length} at risk` },
    { key: 'repeat', label: 'Customers come back (repeat rate ≥ 25%)', pass: s.repeat_rate_pct.value === null ? null : s.repeat_rate_pct.value >= 25, detail: s.repeat_rate_pct.value === null ? 'Not measured' : `${round(s.repeat_rate_pct.value, 1)}%` },
  ];
  const failed = checks.filter((c) => c.pass === false), unknown = checks.filter((c) => c.pass === null);
  const verdict = failed.length ? 'not_yet' : unknown.length > 2 ? 'insufficient_data' : unknown.length ? 'conditional' : 'ready_to_evaluate';
  const message = { not_yet: `I would not recommend expanding yet. ${failed.map((f) => f.label).join('; ')} — not met.`, insufficient_data: 'There is not enough data to judge expansion readiness. Add financial and sales data first.', conditional: `Core checks pass, but ${unknown.map((u) => u.label.toLowerCase()).join('; ')} could not be verified.`, ready_to_evaluate: 'The business meets the basic readiness checks. Model specific options in Scenarios before committing.' }[verdict];
  return { verdict, message, checks, note: 'Readiness checks are platform planning rules, not a guarantee. Expansion into new countries involves legal, tax and regulatory steps — consult qualified professionals.' };
}
