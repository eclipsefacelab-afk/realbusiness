// Role-based access control. Pure functions — used by every backend function and mirrored in the UI.
export type Role = 'owner' | 'admin' | 'manager' | 'marketing_manager' | 'accountant' | 'employee' | 'read_only';
export type Action = 'read' | 'write' | 'delete' | 'approve' | 'admin';
export type Resource =
  | 'business' | 'members' | 'sales' | 'customers' | 'customer_pii' | 'products' | 'inventory' | 'marketing'
  | 'finance' | 'operations' | 'strategy' | 'tasks' | 'competitors' | 'events' | 'documents' | 'reports'
  | 'ai' | 'integrations' | 'audit' | 'settings' | 'imports' | 'alerts' | 'approvals';

export const ROLES: Role[] = ['owner', 'admin', 'manager', 'marketing_manager', 'accountant', 'employee', 'read_only'];
export const ROLE_LABELS: Record<Role, string> = {
  owner: 'Owner', admin: 'Administrator', manager: 'Manager', marketing_manager: 'Marketing Manager',
  accountant: 'Accountant / Financial Advisor', employee: 'Employee', read_only: 'Read-only',
};

const R = (...a: Action[]) => a;
const ALL: Action[] = ['read', 'write', 'delete', 'approve', 'admin'];

// Default matrix. Owners control access to sensitive financial information by choosing roles.
const MATRIX: Record<Role, Partial<Record<Resource, Action[]>>> = {
  owner: Object.fromEntries((['business', 'members', 'sales', 'customers', 'customer_pii', 'products', 'inventory', 'marketing', 'finance', 'operations', 'strategy', 'tasks', 'competitors', 'events', 'documents', 'reports', 'ai', 'integrations', 'audit', 'settings', 'imports', 'alerts', 'approvals'] as Resource[]).map((r) => [r, ALL])),
  admin: {
    business: R('read', 'write'), members: R('read', 'write', 'admin'), sales: R('read', 'write', 'delete'), customers: R('read', 'write', 'delete'),
    customer_pii: R('read'), products: R('read', 'write', 'delete'), inventory: R('read', 'write', 'delete'), marketing: R('read', 'write', 'delete'),
    finance: R('read', 'write', 'delete'), operations: R('read', 'write', 'delete'), strategy: R('read', 'write', 'delete', 'approve'), tasks: R('read', 'write', 'delete'),
    competitors: R('read', 'write', 'delete'), events: R('read', 'write', 'delete'), documents: R('read', 'write', 'delete'), reports: R('read', 'write', 'delete'),
    ai: R('read', 'write'), integrations: R('read', 'write', 'admin'), audit: R('read'), settings: R('read', 'write', 'admin'), imports: R('read', 'write'),
    alerts: R('read', 'write', 'approve'), approvals: R('read', 'approve'),
  },
  manager: {
    business: R('read'), sales: R('read', 'write'), customers: R('read', 'write'), customer_pii: R('read'), products: R('read', 'write'),
    inventory: R('read', 'write'), marketing: R('read', 'write'), operations: R('read', 'write'), strategy: R('read', 'write', 'approve'), tasks: R('read', 'write'),
    competitors: R('read', 'write'), events: R('read', 'write'), documents: R('read', 'write'), reports: R('read', 'write'), ai: R('read', 'write'),
    integrations: R('read'), imports: R('read', 'write'), alerts: R('read', 'write'), approvals: R('read'),
  },
  marketing_manager: {
    business: R('read'), sales: R('read'), customers: R('read', 'write'), customer_pii: R('read'), products: R('read'), inventory: R('read'),
    marketing: R('read', 'write', 'delete'), strategy: R('read'), tasks: R('read', 'write'), competitors: R('read', 'write'), events: R('read', 'write'),
    documents: R('read'), reports: R('read', 'write'), ai: R('read', 'write'), imports: R('read', 'write'), alerts: R('read'),
  },
  accountant: {
    business: R('read'), sales: R('read'), products: R('read'), inventory: R('read'), finance: R('read', 'write'), operations: R('read'),
    strategy: R('read'), tasks: R('read', 'write'), documents: R('read', 'write'), reports: R('read', 'write'), ai: R('read', 'write'), imports: R('read', 'write'), alerts: R('read'),
  },
  employee: {
    business: R('read'), sales: R('read', 'write'), customers: R('read'), products: R('read'), inventory: R('read', 'write'), operations: R('read'),
    tasks: R('read', 'write'), events: R('read', 'write'), documents: R('read'), ai: R('read', 'write'), alerts: R('read'),
  },
  read_only: {
    business: R('read'), sales: R('read'), customers: R('read'), products: R('read'), inventory: R('read'), marketing: R('read'), operations: R('read'),
    strategy: R('read'), tasks: R('read'), competitors: R('read'), events: R('read'), reports: R('read'), alerts: R('read'),
  },
};

export function can(role: Role | null | undefined, resource: Resource, action: Action): boolean {
  if (!role) return false;
  return (MATRIX[role]?.[resource] || []).includes(action);
}

export function permissionsFor(role: Role) {
  return MATRIX[role] || {};
}

// Which resource guards each entity.
export const ENTITY_RESOURCE: Record<string, Resource> = {
  Business: 'business', BusinessMember: 'members', BusinessLocation: 'business', BusinessGoal: 'strategy', BusinessStageHistory: 'strategy',
  BusinessMetric: 'strategy', HealthAssessment: 'strategy', Product: 'products', ProductVariant: 'products', Customer: 'customers',
  Order: 'sales', Sale: 'sales', InventoryItem: 'inventory', MarketingChannel: 'marketing', MarketingCampaign: 'marketing', Expense: 'finance',
  FinancialMetric: 'finance', Forecast: 'strategy', Scenario: 'strategy', Recommendation: 'strategy', Task: 'tasks', Risk: 'strategy',
  Opportunity: 'strategy', Competitor: 'competitors', Event: 'events', EventResult: 'events', Decision: 'strategy', Document: 'documents',
  Report: 'reports', AIConversation: 'ai', Notification: 'business', Integration: 'integrations', ImportBatch: 'imports', AuditLog: 'audit',
  // Prompt 2
  BusinessSettings: 'settings', Alert: 'alerts', AgentRun: 'ai', ContextMemory: 'strategy', ApprovalRequest: 'approvals', WorkflowRun: 'operations',
  AIUsageLog: 'settings', Supplier: 'operations', ProductionRun: 'operations', Invoice: 'finance', PurchaseOrder: 'operations', LearningStat: 'strategy',
};

// Fields never writable through the generic API (system-managed).
export const PROTECTED_FIELDS = ['id', 'business_id', 'created_date', 'updated_date', 'created_by', 'created_by_id'];
// Entities that are append-only / system-written.
export const SYSTEM_ONLY_WRITE = new Set(['AuditLog', 'BusinessStageHistory', 'HealthAssessment', 'AIUsageLog', 'AgentRun', 'LearningStat']);

// Reports of financial kind require finance read.
export const FINANCE_REPORT_KINDS = new Set(['financial_overview', 'monthly_review', 'quarterly_growth', 'annual_plan']);

export const PII_FIELDS: Record<string, string[]> = { Customer: ['email', 'phone'], Supplier: ['contact_email'] };

export function maskRecord(entity: string, rec: Record<string, any>, role: Role): Record<string, any> {
  const pii = PII_FIELDS[entity];
  if (!pii || can(role, 'customer_pii', 'read')) return rec;
  const out = { ...rec };
  for (const f of pii) if (out[f]) out[f] = '•••• (restricted)';
  return out;
}

// Only owners may grant owner/admin; admins may manage roles below admin.
export function canAssignRole(actor: Role, target: Role): boolean {
  if (actor === 'owner') return true;
  if (actor === 'admin') return !['owner', 'admin'].includes(target);
  return false;
}
