// Base44 backend function: intelligence — analysis, recommendations, plans, reviews, AI advisor/agents.
import { createClientFromRequest } from 'npm:@base44/sdk';
import { handleIntelligence } from './_shared/intelligence-handler.ts';
import { respond } from './_shared/http.ts';
import './_shared/register.ts';

Deno.serve((req: Request) => respond(req, async (body) => {
  const base44 = createClientFromRequest(req);
  return handleIntelligence(body, { client: base44, svc: base44.asServiceRole });
}));
