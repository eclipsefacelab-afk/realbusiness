# Integration framework

**Status: no external integrations are connected.** The platform says so in the UI and refuses to mark an integration "connected" unless a server-side test passes. Today the `integration.test` action always reports `not_configured`.

## How data gets in today
- Manual entry on every module.
- CSV import is validated in the browser and on the server, then shown for review before commit.
- Excel and other files go through Base44 `ExtractDataFromUploadedFile`, then the same validation and review.

## Adding a connector (e.g. Shopify, QuickBooks, Stripe)
1. Store credentials in a **Base44 connector or secret**. Never put them in an entity, and never expose them to the frontend.
2. Add a backend function `functions/sync<Provider>/entry.ts` that:
   - authenticates using the secret or connector (`base44.asServiceRole.connectors.getConnection(...)`);
   - maps provider records to platform entities (Sale, Order, Customer, InventoryItem, Expense, FinancialMetric, MarketingCampaign) and tags them `source: 'integration'`;
   - runs rows through `shared/validation.ts` (`validateRows`), skips duplicates, and creates an `ImportBatch` record for traceability;
   - calls the Prompt 2 detectors (`runMonitoringFor`) for event-driven alerts.
3. Implement the real test in `extensions.api['integration.test']` (shared/p2/register.ts): call a read-only endpoint, and set `status` to `connected` or `failed` with the result.
4. Add a scheduled automation in `function.jsonc` for periodic sync.
5. Outbound actions (supplier emails, publishing campaigns, price pushes) must **only** execute inside `decideApproval` (shared/p2/workflows.ts) after approval.
