# Moving off Base44 later (private or enterprise deployment)

Private deployment is **not** available inside Base44, and the platform does not claim it is. The code is organised to keep a future migration small:

| Concern | Today (Base44) | To migrate |
|---|---|---|
| Business logic | `shared/*.ts` — pure TypeScript; the only dependency is a `svc` object with `entities.X.filter/get/create/update/delete` and `integrations.Core.InvokeLLM` | Implement that interface over Postgres (e.g. Prisma/Drizzle) and any LLM provider |
| HTTP | `base44/functions/*/entry.ts` (Deno.serve, ~10 lines each) | Wrap `handleApi` / `handleIntelligence` / `handleMonitor` in Express, Fastify or Cloud Run |
| Auth | Base44 auth (`auth.me()`) | Swap `requireUser()` in shared/context.ts for OIDC/SAML |
| Data model | `scripts/entity-spec*.mjs` (single source) | Generate SQL DDL from the same spec; every tenant table has `business_id` |
| Tenant isolation | Enforced in code (context.ts + api-handler.ts) and RLS deny-all | Keep the code checks; add Postgres RLS on `business_id` as a second layer |
| Scheduling | Base44 automation → `monitor` | Cron or Cloud Scheduler calling the same handler |
| Files | Base44 private storage | S3 or GCS with signed URLs |
| AI | `shared/llm.ts` `callLLM` (model routing, fallback, logging, caps) | Point `svc.integrations.Core.InvokeLLM` at your provider SDK |

Data export: every list has CSV export, and the Base44 dashboard can export entities. Tests in `tests/` run against an in-memory adapter (`tests/mock-base44.ts`), which is a working example of the adapter interface.
