# Deploying to Base44

The repository follows Base44's project structure: a Vite + React app at the root and a `base44/` folder holding `config.jsonc`, `entities/` and `functions/<name>/entry.ts`.

## Option A — Import from GitHub (no terminal)
1. Push this folder to a GitHub repository you own.
2. In Base44, go to **+** → **Bring your own project** and pick the repository.
3. Base44 creates the app, installs dependencies and starts the preview.
4. Open **Code / Dashboard** and confirm that 47 entities and 3 functions (`api`, `intelligence`, `monitor`) exist.

## Option B — Base44 CLI
```
npm install -g base44        # see Base44 docs for the current CLI package
base44 login
base44 link                  # or: base44 create, then copy these files in
npm run sync:shared
base44 deploy                # pushes entities, functions (incl. the hourly automation) and the site
```
Base44's backend functions require the **Builder plan or higher**. GitHub import/sync also needs Builder.

> Note: Base44 says apps with *Workflows* enabled cannot deploy `function.jsonc` automations (HTTP 409). If that happens, recreate the hourly `monitor` schedule in Base44's Workflows/automations UI (call function `monitor` with `{ "mode": "auto" }` every hour).

## After the first deploy
1. Open the app and sign in, then complete onboarding. Click **Pre-fill Eclipse basics** and enter approximate figures.
2. Go to **Data Import**, download each template, and import products → shades (variants) → inventory → customers → sales → expenses → monthly financial summaries.
3. Click **Refresh analysis** on the Overview page, then open **What Should I Do Next?**
4. In **Settings → Team & roles**, invite staff. Invited people get access the first time they sign in with that email; in Base44 the app must also be shared with them, or set to allow sign-ups.
5. In **Settings → AI & automation**, review the alert thresholds, which agents are on, the approval rules, the monitoring frequency and the monthly AI cap.
6. Optional: as a platform admin, add `PlanConfig` records in the Base44 data dashboard. Plans and prices are data, not code.

## Things to verify in Base44 (these could not be tested offline)
- `npm install` and `vite build` succeed. Dependencies: react 18, react-dom, react-icons, @base44/sdk, plus vite and @vitejs/plugin-react.
- The `@base44/sdk` client options (`appId`, `requiresAuth`) and the sign-in redirect behave as expected.
- `Core.InvokeLLM` with `response_json_schema`, plus the optional `model` and `file_urls` parameters.
- `Core.UploadPrivateFile`, `CreateFileSignedUrl` and `ExtractDataFromUploadedFile` (used for documents and Excel imports).
- The hourly automation fires (check the function logs).
- Entity RLS is set to `false` for every operation. All access goes through the functions, which use `asServiceRole` and check membership and role themselves. Confirm the Base44 data dashboard still works for you as the app owner.

## Offline preview (optional)
`node preview/build.mjs && node preview/serve.mjs` serves the real UI and real backend handlers on port 5199, using an in-memory database and a stubbed AI. It needs the esbuild/react modules available on this machine. `preview/e2e.mjs` runs the Playwright walkthrough.
