// Lightweight SVG charts (no chart library dependency). Forecast segments are drawn dashed.
import React from 'react';
import { fmtNum } from '../lib/format';

export function LineChart({ data, height = 200, series = [{ key: 'value', label: 'Value', color: 'var(--brand-2)' }], xKey = 'period', format = (v) => fmtNum(v) }) {
  if (!data?.length) return <div className="empty small">No data to chart yet.</div>;
  const W = 640, H = height, P = { l: 48, r: 12, t: 12, b: 26 };
  const vals = data.flatMap((d) => series.map((s) => d[s.key])).filter((v) => v !== null && v !== undefined);
  const max = Math.max(...vals, 0) * 1.1 || 1, min = Math.min(0, ...vals);
  const x = (i) => P.l + (i * (W - P.l - P.r)) / Math.max(1, data.length - 1);
  const y = (v) => P.t + (1 - (v - min) / (max - min)) * (H - P.t - P.b);
  const ticks = [0, 0.5, 1].map((t) => min + t * (max - min));
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label={series.map((s) => s.label).join(', ')}>
      {ticks.map((t, i) => <g key={i}><line x1={P.l} x2={W - P.r} y1={y(t)} y2={y(t)} stroke="var(--border)" /><text x={P.l - 6} y={y(t) + 4} fontSize="10" textAnchor="end" fill="var(--muted)">{format(t)}</text></g>)}
      {series.map((s) => {
        const pts = data.map((d, i) => [i, d[s.key]]).filter(([, v]) => v !== null && v !== undefined);
        return <g key={s.key}><polyline fill="none" stroke={s.color} strokeWidth="2.2" strokeDasharray={s.dashed ? '5 4' : undefined} points={pts.map(([i, v]) => `${x(i)},${y(v)}`).join(' ')} />{pts.map(([i, v]) => <circle key={i} cx={x(i)} cy={y(v)} r="2.6" fill={s.color}><title>{`${data[i][xKey]}: ${format(v)} (${s.label})`}</title></circle>)}</g>;
      })}
      {data.map((d, i) => (data.length <= 12 || i % Math.ceil(data.length / 12) === 0) && <text key={i} x={x(i)} y={H - 8} fontSize="10" textAnchor="middle" fill="var(--muted)">{String(d[xKey]).slice(-5)}</text>)}
    </svg>
  );
}

export function BarList({ rows, valueKey = 'value', labelKey = 'label', format = (v) => fmtNum(v), max }) {
  if (!rows?.length) return <div className="empty small">No data yet.</div>;
  const m = max || Math.max(...rows.map((r) => r[valueKey] || 0), 1);
  return (
    <div className="stack sm">
      {rows.map((r, i) => (
        <div key={i}>
          <div className="row between small"><span>{r[labelKey]}</span><b>{format(r[valueKey])}</b></div>
          <div className="progress"><div style={{ width: `${((r[valueKey] || 0) / m) * 100}%`, background: r.color || 'var(--brand-2)' }} /></div>
        </div>
      ))}
    </div>
  );
}

export function ScoreRing({ score, size = 92, label }) {
  const r = size / 2 - 7, c = 2 * Math.PI * r, pct = score === null || score === undefined ? 0 : score / 100;
  const color = score === null ? 'var(--faint)' : score >= 75 ? 'var(--pos)' : score >= 55 ? 'var(--accent)' : score >= 35 ? 'var(--high)' : 'var(--crit)';
  return (
    <div className="score-ring" style={{ width: size, height: size }} aria-label={label || `Score ${score ?? 'not available'}`}>
      <svg width={size} height={size}><circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(150,140,160,.25)" strokeWidth="7" fill="none" /><circle cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth="7" fill="none" strokeDasharray={`${c * pct} ${c}`} strokeLinecap="round" transform={`rotate(-90 ${size / 2} ${size / 2})`} /></svg>
      <b style={{ fontSize: size > 70 ? 22 : 14 }}>{score ?? '—'}</b>
    </div>
  );
}
