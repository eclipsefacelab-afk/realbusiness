// Recommendation card: Situation → Analysis → Impact → Recommendation → Priority → Action → Measurement.
import React, { useState } from 'react';
import { api } from '../lib/api';
import { useApp } from '../lib/store';
import { LevelBadge, PriorityBadge, Confidence, Basis, Modal, Field, AsyncButton, Badge } from './ui';
import { fmtDate, labelize, fmtNum } from '../lib/format';

export default function Recommendation({ rec, onChanged, compact }) {
  const { businessId, can, notify } = useApp();
  const [open, setOpen] = useState(!compact);
  const [outcome, setOutcome] = useState(false);
  const decide = async (decision) => { await api('recommendation.decide', { business_id: businessId, id: rec.id, decision }); notify(decision === 'approve' ? 'Approved — a task was added to your plan.' : `Recommendation ${decision === 'defer' ? 'deferred' : decision + 'ed'}.`); onChanged?.(); };
  return (
    <article className={`rec ${rec.finding_level}`}>
      <div className="row between top">
        <div className="stack sm" style={{ gap: 4 }}>
          <div className="row wrap" style={{ gap: 6 }}><LevelBadge level={rec.finding_level} />{!(rec.priority === 'critical' && rec.finding_level === 'critical') && !(rec.priority === 'high' && rec.finding_level === 'high') && <PriorityBadge p={rec.priority} />}<Confidence c={rec.confidence} />{rec.status !== 'proposed' && <Badge kind="neutral">{labelize(rec.status)}</Badge>}{rec.generated_by === 'rules+ai' && <Badge kind="neutral">AI-worded</Badge>}</div>
          <h3 style={{ fontSize: 15 }}>{rec.title}</h3>
        </div>
        <button className="btn ghost sm no-print" onClick={() => setOpen(!open)} aria-expanded={open}>{open ? 'Less' : 'Details'}</button>
      </div>
      <div className="meta"><span>⏱ Effort: {labelize(rec.effort)}</span><span>📅 By {fmtDate(rec.suggested_deadline)}</span><span>👤 {rec.responsible_department || '—'}</span>{rec.dependencies?.length > 0 && <span>Depends on: {rec.dependencies.join(', ')}</span>}</div>
      {open && (
        <dl>
          <dt>Situation</dt><dd>{rec.situation}</dd>
          <dt>Analysis</dt><dd>{rec.analysis}</dd>
          <dt>Why it matters</dt><dd>{rec.why_it_matters} {rec.impact}</dd>
          <dt>Recommendation</dt><dd><b>{rec.recommendation}</b></dd>
          <dt>Next step</dt><dd>{rec.next_step}</dd>
          <dt>Expected benefit</dt><dd>{rec.expected_benefit} <span className="faint small">(estimate, not guaranteed)</span></dd>
          <dt>Risks</dt><dd>{rec.risks}</dd>
          <dt>Measurement</dt><dd>{rec.measurement}</dd>
          <dt>Evidence</dt><dd><div className="evidence">{(rec.evidence || []).map((e, i) => <span key={i}>{e.label}: <b>{typeof e.value === 'number' ? fmtNum(e.value, 2) : e.value ?? '—'}</b> <Basis b={e.basis} /></span>)}</div></dd>
          {rec.confidence_gaps?.length > 0 && <><dt>To raise confidence</dt><dd className="muted">{rec.confidence_gaps.join('; ')}</dd></>}
          {rec.actual_result && <><dt>Actual result</dt><dd>{rec.actual_result} ({labelize(rec.outcome)})</dd></>}
        </dl>
      )}
      {can('strategy', 'approve') && rec.status === 'proposed' && (
        <div className="row wrap no-print" style={{ marginTop: 12, gap: 6 }}>
          <AsyncButton className="btn primary sm" onClick={() => decide('approve')}>Approve → add task</AsyncButton>
          <AsyncButton className="btn sm" onClick={() => decide('defer')}>Defer</AsyncButton>
          <AsyncButton className="btn sm" onClick={() => decide('reject')}>Reject</AsyncButton>
        </div>
      )}
      {can('strategy', 'write') && ['approved', 'assigned', 'in_progress'].includes(rec.status) && <div className="no-print" style={{ marginTop: 10 }}><button className="btn sm" onClick={() => setOutcome(true)}>Record result</button></div>}
      {outcome && <OutcomeModal rec={rec} onClose={() => setOutcome(false)} onSaved={() => { setOutcome(false); onChanged?.(); notify('Result recorded — it will inform future recommendations.'); }} businessId={businessId} />}
    </article>
  );
}

function OutcomeModal({ rec, onClose, onSaved, businessId }) {
  const [o, setO] = useState('worked'); const [t, setT] = useState('');
  return (
    <Modal title="What happened?" onClose={onClose} footer={<><button className="btn" onClick={onClose}>Cancel</button><AsyncButton className="btn primary" onClick={async () => { await api('recommendation.outcome', { business_id: businessId, id: rec.id, outcome: o, actual_result: t }); onSaved(); }}>Save result</AsyncButton></>}>
      <div className="stack">
        <p className="muted">Expected: {rec.measurement}</p>
        <Field label="Outcome"><select value={o} onChange={(e) => setO(e.target.value)}><option value="worked">Worked</option><option value="partially">Partially worked</option><option value="did_not_work">Did not work</option><option value="unknown">Too early to tell</option></select></Field>
        <Field label="Actual result" hint="e.g. 'Sales of Cocoa 550 up 24%, no stock-out'"><textarea value={t} onChange={(e) => setT(e.target.value)} /></Field>
      </div>
    </Modal>
  );
}
