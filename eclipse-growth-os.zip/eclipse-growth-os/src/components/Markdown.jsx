// Tiny, safe markdown renderer (headings, lists, bold, italics, blockquotes). No raw HTML.
import React from 'react';

function inline(text) {
  const parts = String(text).split(/(\*\*[^*]+\*\*|_[^_]+_)/g);
  return parts.map((p, i) => (p.startsWith('**') ? <b key={i}>{p.slice(2, -2)}</b> : p.startsWith('_') && p.endsWith('_') && p.length > 2 ? <i key={i}>{p.slice(1, -1)}</i> : p));
}
export default function Markdown({ text }) {
  const lines = String(text || '').split('\n');
  const out = []; let list = [];
  const flush = () => { if (list.length) { out.push(<ul key={out.length}>{list.map((l, i) => <li key={i}>{inline(l)}</li>)}</ul>); list = []; } };
  for (const line of lines) {
    if (/^\s*[-*] /.test(line)) { list.push(line.replace(/^\s*[-*] /, '')); continue; }
    flush();
    if (line.startsWith('### ')) out.push(<h3 key={out.length}>{inline(line.slice(4))}</h3>);
    else if (line.startsWith('## ')) out.push(<h2 key={out.length}>{inline(line.slice(3))}</h2>);
    else if (line.startsWith('# ')) out.push(<h1 key={out.length} style={{ fontSize: 20 }}>{inline(line.slice(2))}</h1>);
    else if (line.startsWith('> ')) out.push(<blockquote key={out.length}>{inline(line.slice(2))}</blockquote>);
    else if (line.trim()) out.push(<p key={out.length}>{inline(line)}</p>);
  }
  flush();
  return <div className="md">{out}</div>;
}
