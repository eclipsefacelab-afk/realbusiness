import React, { useState } from 'react';
import { labelize, fmtNum } from '../lib/format';

export const Card = ({ title, action, children, className = '', ...rest }) => (
  <section className={`card ${className}`} {...rest}>
    {(title || action) && <div className="card-head"><h2>{title}</h2>{action}</div>}
    {children}
  </section>
);
export const PageHead = ({ title, subtitle, children }) => (
  <div className="page-head"><div><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div><div className="row wrap no-print">{children}</div></div>
);
export const Badge = ({ kind = 'neutral', children }) => <span className={`badge b-${kind}`}>{children}</span>;
export const LevelBadge = ({ level }) => <Badge kind={level}>{({ critical: 'Critical', high: 'High priority', opportunity: 'Opportunity', monitor: 'Monitor', positive: 'Positive' })[level] || labelize(level)}</Badge>;
export const PriorityBadge = ({ p }) => <Badge kind={p === 'critical' ? 'critical' : p === 'high' ? 'high' : p === 'medium' ? 'medium' : 'low'}>{labelize(p)}</Badge>;
const BASIS_HELP = { actual: 'Calculated from your recorded data', estimated: 'Based on your approximate figures or partial data', forecast: 'A projection — not guaranteed', assumption: 'A platform planning assumption, not research about your market', self_assessment: 'Your own rating from onboarding', insufficient_data: 'Not enough data', mixed: 'Combination of actual data and estimates' };
export const Basis = ({ b }) => (b ? <span className={`basis basis-${['actual', 'estimated', 'forecast', 'assumption'].includes(b) ? b : b === 'mixed' || b === 'self_assessment' ? 'estimated' : 'none'}`} title={BASIS_HELP[b] || ''}>{b === 'insufficient_data' ? 'no data' : labelize(b)}</span> : null);
export const Confidence = ({ c }) => (c ? <Badge kind={c === 'high' ? 'positive' : c === 'moderate' ? 'medium' : 'low'}>{labelize(c)} confidence</Badge> : null);

export function Stat({ label, m, value, format = (v) => fmtNum(v), sub, delta }) {
  const v = m ? m.value : value;
  return (
    <div className="card stat">
      <div className="label">{label} {m && <Basis b={m.basis} />}</div>
      <div className="value">{v === null || v === undefined ? '—' : format(v)}</div>
      {delta !== undefined && delta !== null && <div className={`sub delta ${delta >= 0 ? 'up' : 'down'}`}>{delta >= 0 ? '▲' : '▼'} {fmtNum(Math.abs(delta), 1)}% vs prior 30 days</div>}
      <div className="sub">{sub || (m && v === null ? m.source : m?.source)}</div>
    </div>
  );
}
export const Loading = ({ label = 'Loading…' }) => <div className="loading"><span className="spinner" /> {label}</div>;
export const Skeleton = ({ n = 3 }) => <div className="grid g3">{Array.from({ length: n }).map((_, i) => <div key={i} className="skeleton" />)}</div>;
export const ErrorBox = ({ error, retry }) => (error ? <div className="alert-box err row between"><span>{error.status === 403 ? 'You do not have permission to view this. Ask the business owner to change your role.' : error.message || String(error)}</span>{retry && <button className="btn sm" onClick={retry}>Retry</button>}</div> : null);
export const Empty = ({ title, children, action }) => <div className="empty"><h3>{title}</h3><div>{children}</div>{action && <div style={{ marginTop: 12 }}>{action}</div>}</div>;
export const Notice = ({ kind = 'info', children }) => <div className={`alert-box ${kind}`}>{children}</div>;

export function Modal({ title, onClose, children, wide, footer }) {
  return (
    <div className="modal-bg" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${wide ? 'wide' : ''}`} role="dialog" aria-modal="true" aria-label={title}>
        <div className="row between" style={{ marginBottom: 14 }}><h2>{title}</h2><button className="btn ghost sm" onClick={onClose} aria-label="Close">✕</button></div>
        {children}
        {footer && <div className="row" style={{ justifyContent: 'flex-end', marginTop: 16 }}>{footer}</div>}
      </div>
    </div>
  );
}
export function Tabs({ tabs, value, onChange }) {
  return <div className="tabs" role="tablist">{tabs.map(([k, l]) => <button key={k} role="tab" aria-selected={value === k} className={value === k ? 'on' : ''} onClick={() => onChange(k)}>{l}</button>)}</div>;
}
export function Field({ label, hint, children }) { return <label className="field">{label}{children}{hint && <span className="hint">{hint}</span>}</label>; }
export function Progress({ pct, status }) { return <div className={`progress ${status || ''}`}><div style={{ width: `${Math.max(0, Math.min(100, pct || 0))}%` }} /></div>; }
export function AsyncButton({ onClick, children, className = 'btn', ...rest }) {
  const [busy, setBusy] = useState(false);
  return <button className={className} disabled={busy || rest.disabled} onClick={async (e) => { setBusy(true); try { await onClick(e); } finally { setBusy(false); } }} {...rest}>{busy && <span className="spinner" style={{ width: 14, height: 14 }} />}{children}</button>;
}
export function Table({ cols, rows, onRow, empty = 'Nothing here yet.' }) {
  if (!rows?.length) return <Empty title={empty} />;
  return (
    <div className="table-wrap"><table><thead><tr>{cols.map((c) => <th key={c.key || c.label} className={c.num ? 'num' : ''}>{c.label}</th>)}</tr></thead>
      <tbody>{rows.map((r, i) => <tr key={r.id || i} className={onRow ? 'click' : ''} onClick={() => onRow?.(r)}>{cols.map((c) => <td key={c.key || c.label} className={c.num ? 'num' : ''}>{c.render ? c.render(r) : r[c.key] ?? '—'}</td>)}</tr>)}</tbody></table></div>
  );
}
