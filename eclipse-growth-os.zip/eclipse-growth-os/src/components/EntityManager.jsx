// Config-driven list + form for any business entity, using the permission-checked API.
import React, { useEffect, useMemo, useState } from 'react';
import { api } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { Table, Modal, Field, AsyncButton, ErrorBox, Loading, Empty, Notice } from './ui';
import { labelize, toCSV, download, fmtDate, fmtNum } from '../lib/format';

const RESOURCE = { Product: 'products', ProductVariant: 'products', Customer: 'customers', Sale: 'sales', Order: 'sales', InventoryItem: 'inventory', MarketingChannel: 'marketing', MarketingCampaign: 'marketing', Expense: 'finance', FinancialMetric: 'finance', Competitor: 'competitors', Event: 'events', EventResult: 'events', Decision: 'strategy', Risk: 'strategy', Opportunity: 'strategy', BusinessGoal: 'strategy', Task: 'tasks', BusinessLocation: 'business', Supplier: 'operations', ProductionRun: 'operations', Invoice: 'finance', PurchaseOrder: 'operations', ContextMemory: 'strategy', Integration: 'integrations', Scenario: 'strategy' };
const nameOf = (r) => r?.name || r?.title || r?.display_name || r?.shade_name || r?.decision || r?.invoice_number || r?.id;

function useRefOptions(fields, businessId) {
  const [opts, setOpts] = useState({});
  useEffect(() => {
    let alive = true;
    (async () => {
      const out = {};
      for (const f of fields.filter((x) => x.type === 'ref')) {
        try { const r = await api('list', { business_id: businessId, entity: f.ref, limit: 2000 }); out[f.key] = r.items; } catch { out[f.key] = []; }
      }
      if (alive) setOpts(out);
    })();
    return () => { alive = false; };
  }, [businessId, fields.map((f) => f.key).join()]); // eslint-disable-line react-hooks/exhaustive-deps
  return opts;
}

export function RecordForm({ fields, initial = {}, onSubmit, onCancel, refOptions = {}, submitLabel = 'Save' }) {
  const [v, setV] = useState(initial);
  const [err, setErr] = useState(null);
  const set = (k, x) => setV((s) => ({ ...s, [k]: x }));
  return (
    <form className="stack" onSubmit={async (e) => { e.preventDefault(); setErr(null); try { await onSubmit(v); } catch (x) { setErr(x); } }}>
      <div className="grid g2">
        {fields.map((f) => (
          <div key={f.key} className={f.type === 'textarea' || f.wide ? 'span2' : ''}>
            <Field label={`${f.label}${f.required ? ' *' : ''}`} hint={f.hint}>
              {f.type === 'select' ? (
                <select value={v[f.key] ?? ''} onChange={(e) => set(f.key, e.target.value || null)} required={f.required}><option value="">—</option>{f.options.map((o) => <option key={o} value={o}>{labelize(o)}</option>)}</select>
              ) : f.type === 'ref' ? (
                <select value={v[f.key] ?? ''} onChange={(e) => set(f.key, e.target.value || null)} required={f.required}><option value="">—</option>{(refOptions[f.key] || []).filter((o) => !f.filterRef || f.filterRef(o, v)).map((o) => <option key={o.id} value={o.id}>{f.refLabel ? f.refLabel(o, refOptions) : nameOf(o)}</option>)}</select>
              ) : f.type === 'textarea' ? (
                <textarea value={v[f.key] ?? ''} onChange={(e) => set(f.key, e.target.value)} required={f.required} />
              ) : f.type === 'checkbox' ? (
                <input type="checkbox" style={{ width: 'auto' }} checked={!!v[f.key]} onChange={(e) => set(f.key, e.target.checked)} />
              ) : f.type === 'list' ? (
                <input value={(v[f.key] || []).join(', ')} onChange={(e) => set(f.key, e.target.value.split(',').map((x) => x.trim()).filter(Boolean))} placeholder="Comma-separated" />
              ) : (
                <input type={f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text'} step={f.type === 'number' ? 'any' : undefined} value={v[f.key] ?? ''} onChange={(e) => set(f.key, f.type === 'number' ? (e.target.value === '' ? null : Number(e.target.value)) : e.target.value)} required={f.required} />
              )}
            </Field>
          </div>
        ))}
      </div>
      <ErrorBox error={err} />
      <div className="row" style={{ justifyContent: 'flex-end' }}>{onCancel && <button type="button" className="btn" onClick={onCancel}>Cancel</button>}<button className="btn primary" type="submit">{submitLabel}</button></div>
    </form>
  );
}

export default function EntityManager({ entity, title, columns, fields, sort = '-created_date', filter, intro, rowActions, onChanged, defaults = {}, emptyHint, searchKeys = ['name', 'title', 'display_name', 'decision', 'description'] }) {
  const { businessId, can, notify } = useApp();
  const res = RESOURCE[entity];
  const writable = can(res, 'write'), deletable = can(res, 'delete');
  const list = useLoad((bid) => api('list', { business_id: bid, entity, sort, filter, limit: 2000 }).then((r) => r.items), [entity, JSON.stringify(filter)]);
  const refOptions = useRefOptions(fields, businessId);
  const [editing, setEditing] = useState(null);
  const [q, setQ] = useState('');
  const rows = useMemo(() => (list.data || []).filter((r) => !q || searchKeys.some((k) => String(r[k] || '').toLowerCase().includes(q.toLowerCase()))), [list.data, q]); // eslint-disable-line react-hooks/exhaustive-deps

  const save = async (v) => {
    if (editing?.id) await api('update', { business_id: businessId, entity, id: editing.id, data: v });
    else await api('create', { business_id: businessId, entity, data: { ...defaults, ...v } });
    setEditing(null); notify('Saved'); list.reload(); onChanged?.();
  };
  const remove = async (r) => {
    if (!window.confirm(`Delete "${nameOf(r)}"? This is recorded in the audit log.`)) return;
    const out = await api('delete', { business_id: businessId, entity, id: r.id });
    if (out?.approval_required) notify('Deletion requires approval — a request was created in Approvals.'); else notify('Deleted');
    list.reload(); onChanged?.();
  };
  const cols = [...columns.map((c) => ({ ...c, render: c.render || ((r) => fmtCell(r[c.key], c, refOptions)) })), ...((writable || deletable || rowActions) ? [{ key: '_a', label: '', render: (r) => (
    <div className="row" style={{ justifyContent: 'flex-end', gap: 4 }} onClick={(e) => e.stopPropagation()}>
      {rowActions?.(r, list.reload)}
      {writable && <button className="btn sm" onClick={() => setEditing(r)}>Edit</button>}
      {deletable && <button className="btn sm danger" onClick={() => remove(r)} aria-label="Delete">✕</button>}
    </div>) }] : [])];

  return (
    <div className="stack">
      {intro && <Notice>{intro}</Notice>}
      <div className="row between wrap">
        <input placeholder={`Search ${title || labelize(entity)}…`} value={q} onChange={(e) => setQ(e.target.value)} style={{ maxWidth: 320 }} aria-label="Search" />
        <div className="row">
          {rows.length > 0 && <button className="btn sm" onClick={() => download(`${entity}.csv`, toCSV(rows))}>Export CSV</button>}
          {writable && <button className="btn primary sm" onClick={() => setEditing({})}>+ Add</button>}
        </div>
      </div>
      <ErrorBox error={list.error} retry={list.reload} />
      {list.loading && !list.data ? <Loading /> : rows.length ? <Table cols={cols} rows={rows} onRow={writable ? (r) => setEditing(r) : undefined} /> : <Empty title={`No ${title || labelize(entity)} yet`}>{emptyHint || (writable ? 'Add records manually or use Data Import for spreadsheets.' : 'Nothing has been recorded yet.')}</Empty>}
      {editing && <Modal title={`${editing.id ? 'Edit' : 'Add'} ${title ? title.replace(/s$/, '') : labelize(entity)}`} onClose={() => setEditing(null)} wide><RecordForm fields={fields} initial={editing} refOptions={refOptions} onSubmit={save} onCancel={() => setEditing(null)} /></Modal>}
    </div>
  );
}

function fmtCell(v, c, refOptions) {
  if (v === null || v === undefined || v === '') return '—';
  if (c.type === 'ref') return nameOf((refOptions[c.key] || []).find((o) => o.id === v)) || '…';
  if (c.type === 'date') return fmtDate(v);
  if (c.type === 'number' || typeof v === 'number') return fmtNum(v, 2);
  if (c.type === 'select' || c.type === 'enum') return labelize(v);
  if (typeof v === 'boolean') return v ? 'Yes' : 'No';
  if (Array.isArray(v)) return v.join(', ');
  if (typeof v === 'object') return JSON.stringify(v).slice(0, 60);
  return String(v);
}
