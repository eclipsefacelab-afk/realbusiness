// Base44 SDK client. The app id is injected by Base44 at build time (VITE_BASE44_APP_ID).
import { createClient } from '@base44/sdk';

export const base44 = createClient({
  appId: import.meta.env.VITE_BASE44_APP_ID,
  requiresAuth: true,
});
