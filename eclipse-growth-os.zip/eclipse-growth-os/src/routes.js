// Navigation and route registry. The Prompt 2 layer extends these in routes.p2.js.
import { FiHome, FiActivity, FiMap, FiZap, FiTrendingUp, FiUsers, FiPackage, FiBox, FiSpeaker, FiDollarSign, FiSettings, FiTarget, FiCheckSquare, FiFileText, FiFolder, FiMessageCircle, FiUpload, FiLink, FiShield, FiEye, FiTool, FiGrid } from 'react-icons/fi';
import Overview from './pages/Overview';
import Health from './pages/Health';
import GrowthPlan from './pages/GrowthPlan';
import NextActions from './pages/NextActions';
import Sales from './pages/Sales';
import Customers from './pages/Customers';
import Products from './pages/Products';
import Inventory from './pages/Inventory';
import Marketing from './pages/Marketing';
import Finance from './pages/Finance';
import Operations from './pages/Operations';
import Competitors from './pages/Competitors';
import Risks from './pages/Risks';
import Goals from './pages/Goals';
import Decisions from './pages/Decisions';
import Reports from './pages/Reports';
import Documents from './pages/Documents';
import Advisor from './pages/Advisor';
import DataImport from './pages/DataImport';
import Integrations from './pages/Integrations';
import Settings from './pages/Settings';
import Portfolio from './pages/Portfolio';
import { extendRoutes } from './routes.p2';

const base = {
  nav: [
    { label: '', items: [
      { to: '/', label: 'Overview', icon: FiHome },
      { to: '/next', label: 'What Should I Do Next?', icon: FiZap, cta: true, perm: ['strategy', 'read'] },
      { to: '/health', label: 'Business Health', icon: FiActivity, perm: ['strategy', 'read'] },
      { to: '/plan', label: 'Growth Plan', icon: FiMap, perm: ['tasks', 'read'] },
      { to: '/advisor', label: 'AI Business Advisor', icon: FiMessageCircle, perm: ['ai', 'write'] },
    ] },
    { label: 'Business', items: [
      { to: '/sales', label: 'Sales', icon: FiTrendingUp, perm: ['sales', 'read'] },
      { to: '/customers', label: 'Customers', icon: FiUsers, perm: ['customers', 'read'] },
      { to: '/products', label: 'Products', icon: FiPackage, perm: ['products', 'read'] },
      { to: '/inventory', label: 'Inventory', icon: FiBox, perm: ['inventory', 'read'] },
      { to: '/marketing', label: 'Marketing & Events', icon: FiSpeaker, perm: ['marketing', 'read'] },
      { to: '/finance', label: 'Finance', icon: FiDollarSign, perm: ['finance', 'read'] },
      { to: '/operations', label: 'Operations', icon: FiTool, perm: ['operations', 'read'] },
      { to: '/competitors', label: 'Competitors', icon: FiEye, perm: ['competitors', 'read'] },
    ] },
    { label: 'Strategy', items: [
      { to: '/risks', label: 'Risks', icon: FiShield, perm: ['strategy', 'read'] },
      { to: '/goals', label: 'Goals', icon: FiTarget, perm: ['strategy', 'read'] },
      { to: '/decisions', label: 'Decisions', icon: FiCheckSquare, perm: ['strategy', 'read'] },
      { to: '/reports', label: 'Reports', icon: FiFileText, perm: ['reports', 'read'] },
      { to: '/documents', label: 'Documents', icon: FiFolder, perm: ['documents', 'read'] },
    ] },
    { label: 'Data & admin', items: [
      { to: '/import', label: 'Data Import', icon: FiUpload, perm: ['imports', 'write'] },
      { to: '/integrations', label: 'Integrations', icon: FiLink, perm: ['integrations', 'read'] },
      { to: '/portfolio', label: 'Portfolio', icon: FiGrid },
      { to: '/settings', label: 'Settings', icon: FiSettings },
    ] },
  ],
  routes: {
    '/': { component: Overview }, '/next': { component: NextActions }, '/health': { component: Health }, '/plan': { component: GrowthPlan },
    '/sales': { component: Sales }, '/customers': { component: Customers }, '/products': { component: Products }, '/inventory': { component: Inventory },
    '/marketing': { component: Marketing }, '/finance': { component: Finance }, '/operations': { component: Operations }, '/competitors': { component: Competitors },
    '/risks': { component: Risks }, '/goals': { component: Goals }, '/decisions': { component: Decisions }, '/reports': { component: Reports },
    '/documents': { component: Documents }, '/advisor': { component: Advisor }, '/import': { component: DataImport }, '/integrations': { component: Integrations },
    '/settings': { component: Settings }, '/portfolio': { component: Portfolio },
  },
};

const ext = extendRoutes(base);
export const NAV = ext.nav;
export const ROUTES = ext.routes;
