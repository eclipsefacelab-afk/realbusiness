// Prompt 2 enhancement layer: adds the intelligence screens to navigation.
import { FiCpu, FiBell, FiCheckCircle, FiTrendingUp, FiSliders, FiGlobe, FiStar, FiCompass, FiRepeat } from 'react-icons/fi';
import CommandCenter from './pages/p2/CommandCenter';
import Alerts from './pages/p2/Alerts';
import Approvals from './pages/p2/Approvals';
import Forecasts from './pages/p2/Forecasts';
import Scenarios from './pages/p2/Scenarios';
import Expansion from './pages/p2/Expansion';
import Opportunities from './pages/p2/Opportunities';
import Strategy from './pages/p2/Strategy';
import Workflows from './pages/p2/Workflows';

export function extendRoutes(base) {
  const nav = base.nav.map((s) => ({ ...s, items: [...s.items] }));
  nav[0].items.splice(1, 0, { to: '/command', label: 'AI Command Center', icon: FiCpu, perm: ['strategy', 'read'] });
  nav[0].items.push({ to: '/alerts', label: 'Alerts', icon: FiBell, perm: ['alerts', 'read'] }, { to: '/approvals', label: 'Approvals', icon: FiCheckCircle, perm: ['approvals', 'read'] });
  nav.splice(3, 0, { label: 'Intelligence', items: [
    { to: '/forecasts', label: 'Forecasts', icon: FiTrendingUp, perm: ['strategy', 'read'] },
    { to: '/scenarios', label: 'Scenarios', icon: FiSliders, perm: ['finance', 'read'] },
    { to: '/expansion', label: 'Expansion', icon: FiGlobe, perm: ['finance', 'read'] },
    { to: '/opportunities', label: 'Opportunities', icon: FiStar, perm: ['strategy', 'read'] },
    { to: '/strategy', label: 'Strategy Generator', icon: FiCompass, perm: ['strategy', 'write'] },
    { to: '/workflows', label: 'AI Workflows', icon: FiRepeat, perm: ['strategy', 'read'] },
  ] });
  return { nav, routes: { ...base.routes, '/command': { component: CommandCenter }, '/alerts': { component: Alerts }, '/approvals': { component: Approvals }, '/forecasts': { component: Forecasts }, '/scenarios': { component: Scenarios }, '/expansion': { component: Expansion }, '/opportunities': { component: Opportunities }, '/strategy': { component: Strategy }, '/workflows': { component: Workflows } } };
}
