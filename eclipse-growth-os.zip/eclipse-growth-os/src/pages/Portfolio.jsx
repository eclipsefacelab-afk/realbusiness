import React from 'react';
import { api } from '../lib/api';
import { useApp } from '../lib/store';
import { PageHead, Table, Badge, ErrorBox, Loading, Basis } from '../components/ui';
import { ScoreRing } from '../components/charts';
import { fmtMoney, labelize } from '../lib/format';
import { STAGE_LABELS } from '../lib/constants';

export default function Portfolio() {
  const app = useApp();
  const [s, set] = React.useState({ loading: true });
  React.useEffect(() => { api('portfolio').then((r) => set({ data: r.businesses })).catch((e) => set({ error: e })); }, []);
  if (s.error) return <ErrorBox error={s.error} />;
  if (!s.data) return <Loading />;
  return (
    <div className="stack lg">
      <PageHead title="Portfolio" subtitle="All businesses you have access to. Each business's data stays separate; this view shows only summary figures your role allows." />
      <Table cols={[{ key: 'name', label: 'Business', render: (r) => <b>{r.name}{r.is_demo ? ' (demo)' : ''}</b> }, { key: 'health_score', label: 'Health', render: (r) => <ScoreRing score={r.health_score} size={40} /> }, { key: 'stage', label: 'Stage', render: (r) => STAGE_LABELS[r.stage] || '—' }, { key: 'revenue_30d', label: 'Revenue (30d)', num: true, render: (r) => <>{fmtMoney(r.revenue_30d)} <Basis b={r.revenue_basis} /></> }, { key: 'alerts', label: 'Open alerts', render: (r) => r.open_alerts ? <Badge kind={r.critical_alerts ? 'critical' : 'medium'}>{r.open_alerts}</Badge> : '—' }, { key: 'role', label: 'Your role', render: (r) => labelize(r.role) }]} rows={s.data} onRow={(r) => { app.select(r.id); window.history.pushState({}, '', '/'); window.dispatchEvent(new PopStateEvent('popstate')); }} />
    </div>
  );
}
