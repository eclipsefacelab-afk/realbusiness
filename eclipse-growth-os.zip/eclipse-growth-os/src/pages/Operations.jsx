import React, { useState } from 'react';
import { useApp } from '../lib/store';
import { PageHead, Tabs, Notice } from '../components/ui';
import EntityManager from '../components/EntityManager';
import { OPERATIONS_TABS } from './operations.tabs';

export default function Operations() {
  const { can } = useApp();
  const tabs = [['locations', 'Locations'], ...OPERATIONS_TABS.filter((t) => !t.perm || can(...t.perm)).map((t) => [t.key, t.label])];
  const [tab, setTab] = useState('locations');
  const ext = OPERATIONS_TABS.find((t) => t.key === tab);
  return (
    <div className="stack lg">
      <PageHead title="Operations" subtitle="Locations, suppliers, production and operational efficiency." />
      <Tabs tabs={tabs} value={tab} onChange={setTab} />
      {tab === 'locations' && <EntityManager entity="BusinessLocation" title="Locations"
        columns={[{ key: 'name', label: 'Name' }, { key: 'kind', label: 'Type', type: 'select' }, { key: 'country', label: 'Country' }, { key: 'city', label: 'City' }, { key: 'status', label: 'Status', type: 'select' }, { key: 'monthly_rent', label: 'Rent', num: true }]}
        fields={[{ key: 'name', label: 'Name', required: true }, { key: 'kind', label: 'Type', type: 'select', options: ['retail_store', 'warehouse', 'production', 'office', 'online', 'market', 'popup'] }, { key: 'country', label: 'Country' }, { key: 'province_state', label: 'Province/state' }, { key: 'city', label: 'City' }, { key: 'opened_date', label: 'Opened', type: 'date' }, { key: 'status', label: 'Status', type: 'select', options: ['active', 'planned', 'closed'] }, { key: 'monthly_rent', label: 'Monthly rent', type: 'number' }, { key: 'notes', label: 'Notes', type: 'textarea' }]} />}
      {ext && <ext.component />}
      {OPERATIONS_TABS.length === 0 && <Notice>Supplier, production and bottleneck intelligence are added by the intelligence layer.</Notice>}
    </div>
  );
}
