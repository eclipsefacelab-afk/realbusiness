const r = (kind, label, perm) => ({ kind, label, fn: 'intelligence', action: 'report.generate', args: { kind }, perm });
export const P2_REPORT_KINDS = [
  r('briefing', 'Management Briefing', ['strategy', 'read']), r('daily', 'Daily Performance', ['sales', 'read']), r('quarterly_growth', 'Quarterly Growth Report', ['finance', 'read']),
  r('financial_overview', 'Financial Overview', ['finance', 'read']), r('sales', 'Sales Performance', ['sales', 'read']), r('marketing', 'Marketing Report', ['marketing', 'read']),
  r('product', 'Product Report', ['products', 'read']), r('inventory', 'Inventory Report', ['inventory', 'read']), r('manufacturing', 'Manufacturing Report', ['operations', 'read']),
  r('expansion', 'Expansion Analysis', ['finance', 'read']), r('competitor', 'Competitor Report', ['competitors', 'read']), r('risk', 'Risk Report', ['strategy', 'read']),
  r('operations_risk', 'Operational Risk Report', ['operations', 'read']), r('forecast', 'Forecast Report', ['strategy', 'read']), r('six_month_plan', '6-Month Plan', ['strategy', 'write']),
];
