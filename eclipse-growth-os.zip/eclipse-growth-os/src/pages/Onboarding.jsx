// Business onboarding: plain-language questions, approximate figures allowed, nothing required except a name.
import React, { useState } from 'react';
import { api, intel } from '../lib/api';
import { useApp } from '../lib/store';
import { useRouter } from '../lib/router';
import { Card, Field, AsyncButton, ErrorBox, Notice } from '../components/ui';
import { GOAL_OPTIONS, INDUSTRY_OPTIONS, HEALTH_CATEGORIES, MATURITY_QUESTIONS } from '../lib/constants';

const STEPS = ['Your company', 'Money (approximate is fine)', 'Goals', 'Quick self-assessment', 'Review'];
const ECLIPSE = { name: 'Eclipse Cosmetics', industry: 'Cosmetics', industry_module: 'cosmetics', business_type: 'Cosmetics manufacturer and consumer brand', country: 'Canada', operating_countries: ['Canada', 'Jamaica'], sales_channels: ['ecommerce', 'retail', 'wholesale', 'event'], currency: 'CAD' };

const MONEY_HELP = {
  avg_monthly_revenue: ['Average monthly sales', 'Roughly how much money comes in from sales in a typical month.'],
  gross_margin_pct: ['Gross margin (%)', 'Of every $100 of sales, how much is left after paying for the product itself (ingredients, packaging, making it)? e.g. 60 means $60 left.'],
  monthly_operating_expenses: ['Monthly running costs', 'Rent, wages, software, marketing, shipping — everything except the cost of making products.'],
  cash_available: ['Cash available today', 'Money in the business bank account right now.'],
  debt: ['Debt owed', 'Loans, credit lines or credit cards the business owes.'],
  avg_transaction_value: ['Average sale size', 'What a customer typically spends in one purchase.'],
  est_customer_acquisition_cost: ['Cost to win a customer', 'Marketing spend divided by new customers. Leave blank if unsure.'],
};

export default function Onboarding() {
  const app = useApp();
  const { navigate } = useRouter();
  const [step, setStep] = useState(0);
  const [d, setD] = useState({ goals: [], maturity_answers: {}, operating_countries: [], sales_channels: [], financials_basis: 'estimated', currency: 'CAD' });
  const [err, setErr] = useState(null);
  const set = (k, v) => setD((s) => ({ ...s, [k]: v }));
  const toggle = (k, v) => set(k, (d[k] || []).includes(v) ? d[k].filter((x) => x !== v) : [...(d[k] || []), v]);
  const num = (k) => <input type="number" step="any" min="0" value={d[k] ?? ''} onChange={(e) => set(k, e.target.value === '' ? null : Number(e.target.value))} placeholder="Leave blank if unknown" />;

  const create = async () => {
    setErr(null);
    try {
      const { business } = await api('createBusiness', { data: d });
      await app.reload(business.id);
      try { await intel('refresh', { business_id: business.id, ai: false }); } catch { /* analysis can run later */ }
      app.notify('Business created. Your first analysis is ready.');
      navigate('/');
    } catch (e) { setErr(e); }
  };
  const demo = async () => { const { business } = await api('demo.load'); await app.reload(business.id); try { await intel('refresh', { business_id: business.id, ai: false }); } catch { /* ignore */ } navigate('/'); };

  return (
    <div className="content" style={{ maxWidth: 860, margin: '0 auto' }}>
      <div className="row" style={{ margin: '12px 0 20px' }}><div className="logo" /><div><h1>Set up your business</h1><p className="muted">About 5 minutes. Approximate numbers are fine — the platform labels them as estimates and never treats them as facts.</p></div></div>
      <div className="row wrap small" style={{ marginBottom: 14 }}>{STEPS.map((s, i) => <span key={s} className={`badge ${i === step ? 'b-opportunity' : i < step ? 'b-positive' : 'b-neutral'}`}>{i + 1}. {s}</span>)}</div>
      <Card>
        {step === 0 && (
          <div className="stack">
            {!d.name && <Notice>Setting up Eclipse Cosmetics? <button className="btn sm" onClick={() => setD((s) => ({ ...s, ...ECLIPSE }))}>Pre-fill Eclipse basics</button> (you can edit everything).</Notice>}
            <div className="grid g2">
              <Field label="Business name *"><input value={d.name || ''} onChange={(e) => set('name', e.target.value)} required /></Field>
              <Field label="Industry"><select value={d.industry_module || 'general'} onChange={(e) => set('industry_module', e.target.value)}>{INDUSTRY_OPTIONS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></Field>
              <Field label="Business type" hint="e.g. manufacturer + brand, retailer, service"><input value={d.business_type || ''} onChange={(e) => set('business_type', e.target.value)} /></Field>
              <Field label="Year established"><input type="number" value={d.year_established ?? ''} onChange={(e) => set('year_established', e.target.value ? Number(e.target.value) : null)} /></Field>
              <Field label="Country (head office)"><input value={d.country || ''} onChange={(e) => set('country', e.target.value)} /></Field>
              <Field label="Province / state"><input value={d.province_state || ''} onChange={(e) => set('province_state', e.target.value)} /></Field>
              <Field label="City"><input value={d.city || ''} onChange={(e) => set('city', e.target.value)} /></Field>
              <Field label="Currency"><select value={d.currency} onChange={(e) => set('currency', e.target.value)}>{['CAD', 'USD', 'JMD', 'GBP', 'EUR'].map((c) => <option key={c}>{c}</option>)}</select></Field>
              <Field label="Number of employees"><input type="number" min="0" value={d.employees ?? ''} onChange={(e) => set('employees', e.target.value ? Number(e.target.value) : null)} /></Field>
              <Field label="Number of locations"><input type="number" min="0" value={d.locations_count ?? ''} onChange={(e) => set('locations_count', e.target.value ? Number(e.target.value) : null)} /></Field>
              <Field label="Countries you operate in" hint="Comma-separated, e.g. Canada, Jamaica"><input value={(d.operating_countries || []).join(', ')} onChange={(e) => set('operating_countries', e.target.value.split(',').map((x) => x.trim()).filter(Boolean))} /></Field>
              <Field label="How you sell"><div className="checks">{['ecommerce', 'retail', 'wholesale', 'event', 'popup', 'social'].map((c) => <label key={c} className={`check ${d.sales_channels.includes(c) ? 'on' : ''}`}><input type="checkbox" checked={d.sales_channels.includes(c)} onChange={() => toggle('sales_channels', c)} />{c}</label>)}</div></Field>
              <Field label="Business model" hint="How you make money, in your words"><textarea value={d.business_model || ''} onChange={(e) => set('business_model', e.target.value)} /></Field>
              <Field label="Products / services"><textarea value={d.products_services || ''} onChange={(e) => set('products_services', e.target.value)} /></Field>
              <div className="span2"><Field label="Target customers"><textarea value={d.target_customers || ''} onChange={(e) => set('target_customers', e.target.value)} /></Field></div>
            </div>
          </div>
        )}
        {step === 1 && (
          <div className="stack">
            <Notice>Don't worry about accounting terms — each box explains what it means. Leave anything blank you don't know. These figures will be labelled <b>estimated</b> until real data (sales, expenses, statements) is imported.</Notice>
            <div className="grid g2">
              <Field label="Revenue range"><select value={d.revenue_range || ''} onChange={(e) => set('revenue_range', e.target.value || null)}><option value="">Not sure</option>{[['pre_revenue', 'No sales yet'], ['under_100k', 'Under $100k / year'], ['100k_500k', '$100k–$500k'], ['500k_1m', '$500k–$1M'], ['1m_5m', '$1M–$5M'], ['5m_20m', '$5M–$20M'], ['over_20m', 'Over $20M']].map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></Field>
              {Object.entries(MONEY_HELP).map(([k, [l, h]]) => <Field key={k} label={l} hint={h}>{num(k)}</Field>)}
              <Field label="Major recurring expenses" hint="e.g. rent, packaging supplier, booth fees"><textarea value={d.major_recurring_expenses || ''} onChange={(e) => set('major_recurring_expenses', e.target.value)} /></Field>
              <Field label="How accurate are these numbers?"><select value={d.financials_basis} onChange={(e) => set('financials_basis', e.target.value)}><option value="estimated">Rough estimates</option><option value="actual">From my accounting records</option></select></Field>
            </div>
          </div>
        )}
        {step === 2 && (
          <div className="stack">
            <h3>What do you want to accomplish? (choose any)</h3>
            <div className="checks">{GOAL_OPTIONS.map(([k, l]) => <label key={k} className={`check ${d.goals.includes(k) ? 'on' : ''}`}><input type="checkbox" checked={d.goals.includes(k)} onChange={() => toggle('goals', k)} />{l}</label>)}</div>
            <div className="grid g2">
              <Field label="Other goal"><input value={d.other_goal || ''} onChange={(e) => set('other_goal', e.target.value)} /></Field>
              <Field label="Timeframe"><select value={d.goal_timeframe_months || ''} onChange={(e) => set('goal_timeframe_months', e.target.value ? Number(e.target.value) : null)}><option value="">Not sure</option>{[3, 6, 12, 24, 36].map((m) => <option key={m} value={m}>{m} months</option>)}</select></Field>
            </div>
            <p className="muted small">Each goal becomes a trackable goal. You'll set exact targets (e.g. "$60,000 monthly revenue by June") on the Goals page.</p>
          </div>
        )}
        {step === 3 && (
          <div className="stack">
            <Notice>Optional. Rate each area 1–5. Your answers are used only where no data exists yet, and are always labelled <b>self-assessment</b>.</Notice>
            {HEALTH_CATEGORIES.map(([k, l]) => (
              <div key={k} className="row between wrap" style={{ borderBottom: '1px solid var(--border)', paddingBottom: 8 }}>
                <div style={{ flex: 1, minWidth: 240 }}><b>{l}</b><div className="small muted">{MATURITY_QUESTIONS[k]}</div></div>
                <div className="scale">{[1, 2, 3, 4, 5].map((n) => <button type="button" key={n} className={d.maturity_answers[k] === n ? 'on' : ''} onClick={() => set('maturity_answers', { ...d.maturity_answers, [k]: d.maturity_answers[k] === n ? undefined : n })}>{n}</button>)}</div>
              </div>
            ))}
          </div>
        )}
        {step === 4 && (
          <div className="stack">
            <h3>Ready to create {d.name || 'your business'}</h3>
            <p className="muted">After creation the platform runs a first analysis: health score, growth stage and your first "What should I do next?" list — based on what you entered. Import sales, inventory and expenses to make it much more accurate.</p>
            <ul className="small"><li>Industry: {d.industry_module || 'general'}</li><li>Goals: {d.goals.length || 'none selected'}</li><li>Financial figures entered: {Object.keys(MONEY_HELP).filter((k) => d[k] !== null && d[k] !== undefined).length} of {Object.keys(MONEY_HELP).length}</li><li>Self-assessment answers: {Object.values(d.maturity_answers).filter(Boolean).length} of {HEALTH_CATEGORIES.length}</li></ul>
            <ErrorBox error={err} />
          </div>
        )}
        <div className="divider" />
        <div className="row between">
          <div className="row">{step > 0 && <button className="btn" onClick={() => setStep(step - 1)}>Back</button>}{app.businesses.length > 0 && <button className="btn ghost" onClick={() => navigate('/')}>Cancel</button>}</div>
          {step < STEPS.length - 1 ? <button className="btn primary" disabled={step === 0 && !d.name} onClick={() => setStep(step + 1)}>Continue</button> : <AsyncButton className="btn primary" onClick={create}>Create business</AsyncButton>}
        </div>
      </Card>
      <p className="center small muted" style={{ marginTop: 16 }}>Just exploring? <AsyncButton className="btn sm" onClick={demo}>Open a sample business with demo data</AsyncButton> <span className="faint">(fictional data, clearly labelled, kept separate)</span></p>
    </div>
  );
}
