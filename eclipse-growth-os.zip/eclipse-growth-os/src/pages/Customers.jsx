import React from 'react';
import { intel } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { PageHead, Stat, Card, Notice } from '../components/ui';
import EntityManager from '../components/EntityManager';
import { fmtMoney, fmtPct } from '../lib/format';

export default function Customers() {
  const { business, can } = useApp();
  const a = useLoad((bid) => intel('analysis', { business_id: bid }));
  const s = a.data?.snapshot;
  return (
    <div className="stack lg">
      <PageHead title="Customer Intelligence" subtitle="New vs returning customers, value and retention. Personal details are visible only to roles allowed to see them." />
      {s && <div className="grid g4">
        <Stat label="Customers" m={s.customers_total} /><Stat label="New (30 days)" m={s.new_customers_30d} />
        <Stat label="Repeat rate" m={s.repeat_rate_pct} format={(v) => fmtPct(v)} /><Stat label="Largest customer share" m={s.top_customer_share_pct} format={(v) => fmtPct(v)} />
      </div>}
      {s && s.repeat_rate_pct.value === null && <Notice kind="warn">Link sales to customers (customer column in sales imports) to measure repeat purchases, lifetime value and retention.</Notice>}
      {!can('customer_pii', 'read') && <Notice>Email and phone are hidden for your role.</Notice>}
      <EntityManager entity="Customer" title="Customers" onChanged={a.reload}
        columns={[{ key: 'display_name', label: 'Name' }, { key: 'type', label: 'Type', type: 'select' }, { key: 'email', label: 'Email' }, { key: 'country', label: 'Country' }, { key: 'total_orders', label: 'Orders', num: true }, { key: 'total_spent', label: 'Spent', num: true }, { key: 'marketing_consent', label: 'Consent' }]}
        fields={[{ key: 'display_name', label: 'Name' }, { key: 'type', label: 'Type', type: 'select', options: ['consumer', 'wholesale', 'retail_partner', 'distributor'] }, { key: 'email', label: 'Email' }, { key: 'phone', label: 'Phone' }, { key: 'country', label: 'Country' }, { key: 'city', label: 'City' }, { key: 'acquisition_channel', label: 'How they found you' }, { key: 'acquisition_event_id', label: 'Met at event', type: 'ref', ref: 'Event' }, { key: 'segment', label: 'Segment' }, { key: 'marketing_consent', label: 'Agreed to marketing messages', type: 'checkbox' }, { key: 'notes', label: 'Notes', type: 'textarea' }]}
        searchKeys={['display_name', 'email', 'segment', 'country']} />
    </div>
  );
}
