import React from 'react';
import { api } from '../lib/api';
import { useApp } from '../lib/store';
import { AsyncButton } from '../components/ui';

function TestButton({ i, reload }) {
  const { businessId, can, notify } = useApp();
  if (!can('integrations', 'admin')) return null;
  return <AsyncButton className="btn sm" onClick={async () => { const r = await api('integration.test', { business_id: businessId, id: i.id }); notify(r.result, r.ok ? 'ok' : 'err'); reload(); }}>Test</AsyncButton>;
}
export const INTEGRATION_TEST = (i, reload) => <TestButton i={i} reload={reload} />;
