import React from 'react';
import { PageHead, Notice } from '../components/ui';
import EntityManager from '../components/EntityManager';

export default function Decisions() {
  return (
    <div className="stack lg">
      <PageHead title="Decision Center" subtitle="Record important decisions with your reasons and expected results, then compare against what actually happened at the review date." />
      <EntityManager entity="Decision" title="Decisions" sort="-date"
        columns={[{ key: 'decision', label: 'Decision' }, { key: 'date', label: 'Date', type: 'date' }, { key: 'responsible_person', label: 'Responsible' }, { key: 'review_date', label: 'Review', type: 'date' }, { key: 'outcome', label: 'Outcome', type: 'select' }]}
        fields={[{ key: 'decision', label: 'Decision', required: true, wide: true, hint: 'e.g. "We decided to launch a travel-size foundation"' }, { key: 'date', label: 'Date', type: 'date' }, { key: 'responsible_person', label: 'Person responsible' }, { key: 'reason', label: 'Reason', type: 'textarea' }, { key: 'expected_result', label: 'Expected result', type: 'textarea' }, { key: 'assumptions', label: 'Assumptions', type: 'list' }, { key: 'review_date', label: 'Review date', type: 'date' }, { key: 'actual_result', label: 'Actual result', type: 'textarea' }, { key: 'outcome', label: 'Outcome', type: 'select', options: ['pending', 'better_than_expected', 'as_expected', 'worse_than_expected'] }, { key: 'lessons', label: 'Lessons learned', type: 'textarea' }]}
        searchKeys={['decision', 'reason']} />
      <Notice>Decisions with recorded outcomes are added to the AI's business memory so future advice can refer to what worked before.</Notice>
    </div>
  );
}
