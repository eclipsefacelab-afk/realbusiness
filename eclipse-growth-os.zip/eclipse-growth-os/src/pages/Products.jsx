import React, { useState } from 'react';
import { intel } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { PageHead, Tabs, Table, Notice } from '../components/ui';
import EntityManager from '../components/EntityManager';
import { Tags } from './Sales';
import { fmtMoney, fmtPct, fmtNum } from '../lib/format';
import { VARIANT_LABEL } from '../lib/constants';

export default function Products() {
  const { business } = useApp();
  const V = VARIANT_LABEL(business?.industry_module);
  const [tab, setTab] = useState('intel');
  const a = useLoad((bid) => intel('analysis', { business_id: bid }));
  const s = a.data?.snapshot;
  return (
    <div className="stack lg">
      <PageHead title="Product Intelligence" subtitle={`Profitability, sales velocity and signals for each product and ${V.toLowerCase()}. The platform never suggests discontinuing an item on low sales alone — margin, strategic role, seasonality and acquisition value are considered.`} />
      <Tabs tabs={[['intel', 'Intelligence'], ['products', 'Products'], ['variants', `${V}s`]]} value={tab} onChange={setTab} />
      {tab === 'intel' && s && (
        <>
          <Table cols={[{ key: 'name', label: 'Product / ' + V }, { key: 'velocity_per_day', label: 'Units/day', num: true, render: (r) => fmtNum(r.velocity_per_day, 2) }, { key: 'growth_pct', label: 'Growth', num: true, render: (r) => (r.growth_pct === null ? '—' : fmtPct(r.growth_pct)) }, { key: 'revenue_90d', label: 'Revenue 90d', num: true, render: (r) => fmtMoney(r.revenue_90d, business?.currency) }, { key: 'margin_pct', label: 'Margin', num: true, render: (r) => (r.margin_pct === null ? 'add cost' : fmtPct(r.margin_pct)) }, { key: 'strategic_role', label: 'Role' }, { key: 'tags', label: 'Signals', render: (r) => <Tags tags={r.tags} /> }]} rows={[...s.products, ...s.variants]} empty="Add products and sales to see product intelligence" />
          {s.top3_shade_share_pct.value !== null && <Notice>Top 3 {V.toLowerCase()}s = {fmtPct(s.top3_shade_share_pct.value)} of 90-day revenue.</Notice>}
        </>
      )}
      {tab === 'products' && <EntityManager entity="Product" title="Products" onChanged={a.reload}
        columns={[{ key: 'name', label: 'Name' }, { key: 'sku', label: 'SKU' }, { key: 'category', label: 'Category' }, { key: 'price', label: 'Price', num: true }, { key: 'unit_cost', label: 'Unit cost', num: true }, { key: 'strategic_role', label: 'Role', type: 'select' }, { key: 'status', label: 'Status', type: 'select' }]}
        fields={[{ key: 'name', label: 'Name', required: true }, { key: 'sku', label: 'SKU' }, { key: 'category', label: 'Category', hint: 'e.g. Foundation, Lipstick' }, { key: 'product_line', label: 'Product line' }, { key: 'price', label: 'Retail price', type: 'number' }, { key: 'unit_cost', label: 'Unit cost (to make)', type: 'number', hint: 'Needed for margin & profitability' }, { key: 'strategic_role', label: 'Strategic role', type: 'select', options: ['core', 'hero', 'acquisition', 'seasonal', 'test', 'other'] }, { key: 'status', label: 'Status', type: 'select', options: ['active', 'in_development', 'seasonal', 'discontinued'] }, { key: 'launch_date', label: 'Launch date', type: 'date' }, { key: 'description', label: 'Description', type: 'textarea' }]} />}
      {tab === 'variants' && <EntityManager entity="ProductVariant" title={`${V}s`} onChanged={a.reload}
        columns={[{ key: 'product_id', label: 'Product', type: 'ref' }, { key: 'shade_name', label: V }, { key: 'sku', label: 'SKU' }, { key: 'price', label: 'Price', num: true }, { key: 'unit_cost', label: 'Unit cost', num: true }, { key: 'status', label: 'Status', type: 'select' }]}
        fields={[{ key: 'product_id', label: 'Product', type: 'ref', ref: 'Product', required: true }, { key: 'name', label: 'Name', required: true }, { key: 'shade_name', label: `${V} name` }, { key: 'shade_family', label: 'Family', hint: 'e.g. Deep, Medium' }, { key: 'undertone', label: 'Undertone' }, { key: 'size', label: 'Size' }, { key: 'sku', label: 'SKU' }, { key: 'price', label: 'Price (if different)', type: 'number' }, { key: 'unit_cost', label: 'Unit cost (if different)', type: 'number' }, { key: 'status', label: 'Status', type: 'select', options: ['active', 'discontinued', 'planned'] }, { key: 'launch_date', label: 'Launch date', type: 'date' }]}
        searchKeys={['name', 'shade_name', 'sku']} />}
    </div>
  );
}
