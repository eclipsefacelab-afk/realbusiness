import React, { useState } from 'react';
import { api, intel } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { Link } from '../lib/router';
import { PageHead, Card, Tabs, ErrorBox, Loading, Empty, AsyncButton, PriorityBadge, Notice, Progress } from '../components/ui';
import EntityManager from '../components/EntityManager';
import { fmtDate, labelize } from '../lib/format';

const STATUSES = ['not_started', 'in_progress', 'completed', 'delayed', 'cancelled'];
const HZ = [['30', '30-day plan', 'Immediate priorities'], ['60', '60-day plan', 'Medium-term improvements'], ['90', '90-day plan', 'Strategic growth objectives'], ['180', '6-month', 'Later items'], ['365', 'Annual', 'Annual roadmap actions']];

export default function GrowthPlan() {
  const { businessId, can, notify } = useApp();
  const [tab, setTab] = useState('30');
  const tasks = useLoad((bid) => api('list', { business_id: bid, entity: 'Task', sort: 'due_date', limit: 2000 }).then((r) => r.items));
  const setStatus = async (t, status) => { await api('update', { business_id: businessId, entity: 'Task', id: t.id, data: { status } }); tasks.reload(); };
  const gen = async () => { const r = await intel('plan.generate', { business_id: businessId, horizons: ['30', '60', '90', '180'] }); notify(`Plan updated: ${r.created} new tasks${r.delayed_carried_forward ? `, ${r.delayed_carried_forward} overdue tasks marked delayed` : ''}.`); tasks.reload(); };
  const annual = async () => { await intel('plan.annual', { business_id: businessId, create_tasks: true }); notify('Annual plan created — see Reports.'); tasks.reload(); };
  const list = (tasks.data || []).filter((t) => (tab === 'all' ? true : t.plan_horizon === tab));
  return (
    <div className="stack lg">
      <PageHead title="Growth Plan" subtitle="30/60/90-day plans built from your prioritised recommendations and goals. Completed and missed actions feed back into future recommendations.">
        {can('strategy', 'write') && <AsyncButton className="btn primary" onClick={gen}>Generate / update plan</AsyncButton>}
        {can('strategy', 'write') && <AsyncButton className="btn" onClick={annual}>Create annual plan</AsyncButton>}
      </PageHead>
      <div className="grid g3">
        {HZ.slice(0, 3).map(([k, l, d]) => { const t = (tasks.data || []).filter((x) => x.plan_horizon === k && x.status !== 'cancelled'); const done = t.filter((x) => x.status === 'completed').length; return <Card key={k} title={l}><div className="small muted">{d}</div><div className="row between small" style={{ marginTop: 8 }}><span>{done}/{t.length} done</span><span>{t.filter((x) => x.status === 'delayed').length} delayed</span></div><Progress pct={t.length ? (done / t.length) * 100 : 0} /></Card>; })}
      </div>
      <Tabs tabs={[...HZ.map(([k, l]) => [k, l]), ['all', 'All tasks'], ['manage', 'Add / edit']]} value={tab} onChange={setTab} />
      <ErrorBox error={tasks.error} retry={tasks.reload} />
      {tab === 'manage' ? (
        <EntityManager entity="Task" title="Tasks" sort="due_date" columns={[{ key: 'title', label: 'Task' }, { key: 'plan_horizon', label: 'Plan' }, { key: 'priority', label: 'Priority', type: 'select' }, { key: 'owner_name', label: 'Owner' }, { key: 'due_date', label: 'Due', type: 'date' }, { key: 'status', label: 'Status', type: 'select' }]}
          fields={[{ key: 'title', label: 'Task', required: true, wide: true }, { key: 'objective', label: 'Objective' }, { key: 'plan_horizon', label: 'Plan', type: 'select', options: ['30', '60', '90', '180', '365', 'none'] }, { key: 'priority', label: 'Priority', type: 'select', options: ['critical', 'high', 'medium', 'low'] }, { key: 'owner_name', label: 'Owner' }, { key: 'due_date', label: 'Deadline', type: 'date' }, { key: 'status', label: 'Status', type: 'select', options: STATUSES }, { key: 'kpi', label: 'KPI' }, { key: 'estimated_cost', label: 'Estimated cost', type: 'number' }, { key: 'expected_outcome', label: 'Expected outcome', type: 'textarea' }, { key: 'actual_outcome', label: 'Actual outcome', type: 'textarea' }, { key: 'completion_notes', label: 'Completion notes', type: 'textarea' }]}
          onChanged={tasks.reload} />
      ) : tasks.loading && !tasks.data ? <Loading /> : list.length ? (
        <div className="table-wrap"><table><thead><tr><th>Task / objective</th><th>Priority</th><th>Owner</th><th>Deadline</th><th>KPI / expected outcome</th><th>Status</th></tr></thead><tbody>
          {list.map((t) => <tr key={t.id}><td><b>{t.title}</b><div className="small muted">{t.objective}</div></td><td><PriorityBadge p={t.priority} /></td><td>{t.owner_name || '—'}</td><td className={t.status === 'delayed' ? 'delta down' : ''}>{fmtDate(t.due_date)}</td><td className="small">{t.kpi}<div className="muted">{t.expected_outcome}</div></td>
            <td>{can('tasks', 'write') ? <select value={t.status} onChange={(e) => setStatus(t, e.target.value)} aria-label="Status">{STATUSES.map((s) => <option key={s} value={s}>{labelize(s)}</option>)}</select> : labelize(t.status)}</td></tr>)}
        </tbody></table></div>
      ) : <Empty title="No tasks in this plan yet">Generate a plan from your recommendations, or approve actions on <Link to="/next">What should I do next?</Link></Empty>}
      <Notice>Plans adjust automatically: overdue tasks are marked <b>Delayed</b> and carried forward; completed recommendations are not repeated; recorded results inform ranking once there are at least 3 outcomes of a kind.</Notice>
    </div>
  );
}
