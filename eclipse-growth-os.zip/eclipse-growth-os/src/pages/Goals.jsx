import React from 'react';
import { api } from '../lib/api';
import { useLoad } from '../lib/store';
import { PageHead, Card, Badge, Progress, ErrorBox } from '../components/ui';
import EntityManager from '../components/EntityManager';
import { fmtNum, fmtDate, labelize } from '../lib/format';

const METRICS = ['revenue_30d', 'gross_margin_pct', 'repeat_rate_pct', 'units_30d', 'customers_total', 'net_profit_monthly', 'cash'];
export default function Goals() {
  const g = useLoad((bid) => api('goals.refresh', { business_id: bid }).then((r) => r.goals));
  return (
    <div className="stack lg">
      <PageHead title="Goals" subtitle="Measurable goals with pace tracking. Link a goal to a platform metric and it updates automatically from actual data." />
      <ErrorBox error={g.error} retry={g.reload} />
      <div className="grid g3">
        {(g.data || []).map((x) => (
          <Card key={x.id} title={x.title} action={<Badge kind={x.status === 'behind' ? 'critical' : x.status === 'at_risk' ? 'medium' : ['ahead', 'achieved'].includes(x.status) ? 'positive' : 'neutral'}>{labelize(x.status)}</Badge>}>
            <div className="row between small"><span>Start {fmtNum(x.start_value)}</span><b>Now {fmtNum(x.current_value ?? x.start_value)}</b><span>Target {fmtNum(x.target_value)} {x.unit}</span></div>
            <Progress pct={x.progress_pct} status={x.status} />
            <p className="small muted" style={{ marginTop: 8 }}>{x.explanation}</p>
            <div className="small faint">Deadline {fmtDate(x.deadline)}{x.metric_key ? ` · auto-updates from ${x.metric_key}` : ' · update the current value manually'}</div>
          </Card>
        ))}
      </div>
      <EntityManager entity="BusinessGoal" title="Goals" onChanged={g.reload}
        columns={[{ key: 'title', label: 'Goal' }, { key: 'category', label: 'Category', type: 'select' }, { key: 'current_value', label: 'Current', num: true }, { key: 'target_value', label: 'Target', num: true }, { key: 'deadline', label: 'Deadline', type: 'date' }]}
        fields={[{ key: 'title', label: 'Goal', required: true, wide: true, hint: 'e.g. Reach $1M revenue, Sell 10,000 units' }, { key: 'category', label: 'Category', type: 'select', options: ['revenue', 'profit', 'customers', 'repeat_customers', 'units', 'margin', 'locations', 'market', 'ecommerce', 'wholesale', 'hiring', 'operations', 'financing', 'other'] }, { key: 'metric_key', label: 'Auto-track metric (optional)', type: 'select', options: METRICS }, { key: 'unit', label: 'Unit', hint: 'e.g. CAD, %, units' }, { key: 'start_value', label: 'Starting value', type: 'number' }, { key: 'current_value', label: 'Current value', type: 'number' }, { key: 'target_value', label: 'Target', type: 'number', required: true }, { key: 'start_date', label: 'Start date', type: 'date' }, { key: 'deadline', label: 'Deadline', type: 'date' }, { key: 'notes', label: 'Notes', type: 'textarea' }]} />
    </div>
  );
}
