import React, { useState } from 'react';
import { api, uploadPrivateFile } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { PageHead, Card, Field, AsyncButton, ErrorBox, Notice, Table, Badge } from '../components/ui';
import { fmtDateTime, labelize, download } from '../lib/format';

// CSV parsing in the browser (same rules as the server-side validator).
function parseCSV(text) {
  const out = []; let row = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) { const c = text[i]; if (q) { if (c === '"' && text[i + 1] === '"') { cell += '"'; i++; } else if (c === '"') q = false; else cell += c; } else if (c === '"') q = true; else if (c === ',') { row.push(cell); cell = ''; } else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cell); out.push(row); row = []; cell = ''; } else cell += c; }
  if (cell !== '' || row.length) { row.push(cell); out.push(row); }
  const [h, ...body] = out.filter((r) => r.some((x) => x.trim() !== '')); if (!h) return [];
  const keys = h.map((x) => x.trim().toLowerCase().replace(/\s+/g, '_'));
  return body.map((r) => Object.fromEntries(keys.map((k, i) => [k, (r[i] ?? '').trim()])));
}
const TEMPLATES = {
  Sale: 'date,product,shade,quantity,unit_price,revenue,channel,customer_email,location,currency\n2026-11-01,Silk Foundation,Cocoa 550,2,42,84,ecommerce,jane@example.com,Online store,CAD',
  Product: 'name,sku,category,price,unit_cost,strategic_role,status\nSilk Foundation,SF-001,Foundation,42,11,hero,active',
  ProductVariant: 'product,name,shade_name,sku,unit_cost\nSilk Foundation,Cocoa 550,Cocoa 550,SF-550,11',
  InventoryItem: 'product,shade,location,on_hand,reorder_point,lead_time_days,unit_cost\nSilk Foundation,Cocoa 550,Toronto,120,40,21,11',
  Customer: 'display_name,email,type,country,marketing_consent\nJane Doe,jane@example.com,consumer,Canada,true',
  Expense: 'date,category,amount,vendor,cost_type,description\n2026-11-01,rent,3200,Landlord,fixed,November rent',
  FinancialMetric: 'period_start,period_end,period_type,revenue,cogs,operating_expenses,net_profit,cash_balance,data_basis\n2026-10-01,2026-10-31,month,30000,11000,19000,0,48500,actual',
  MarketingCampaign: 'name,start_date,end_date,spend,customers_acquired,attributed_revenue,attribution_method\nSpring launch,2026-03-01,2026-03-31,1800,24,3900,promo_code',
  Event: 'name,kind,start_date,location_text,cost,status\nBeauty Expo,trade_show,2026-10-27,Toronto,3500,completed',
};

export default function DataImport() {
  const { businessId, notify } = useApp();
  const batches = useLoad((bid) => api('list', { business_id: bid, entity: 'ImportBatch', limit: 50 }).then((r) => r.items));
  const [entity, setEntity] = useState('Sale');
  const [res, setRes] = useState(null);
  const [err, setErr] = useState(null);
  const onFile = async (file) => {
    setErr(null); setRes(null);
    try {
      let rows;
      if (/\.csv$/i.test(file.name) || file.type === 'text/csv') rows = parseCSV(await file.text());
      else { const up = await uploadPrivateFile(file); rows = (await api('import.extract', { business_id: businessId, entity, file_uri: up.file_uri })).rows; }
      if (!rows?.length) throw new Error('No rows found in this file.');
      setRes({ file: file.name, ...(await api('import.validate', { business_id: businessId, entity, rows, file_name: file.name, source: /\.csv$/i.test(file.name) ? 'csv' : 'excel' })) });
    } catch (e) { setErr(e); }
  };
  const commit = async () => { const r = await api('import.commit', { business_id: businessId, batch_id: res.batch_id }); notify(`Imported ${r.committed} records`); setRes(null); batches.reload(); };
  const reject = async () => { await api('import.reject', { business_id: businessId, batch_id: res.batch_id }); setRes(null); batches.reload(); };
  const errors = res?.issues.filter((i) => i.severity === 'error') || [], warnings = res?.issues.filter((i) => i.severity === 'warning') || [];
  return (
    <div className="stack lg">
      <PageHead title="Data Import" subtitle="Bring in sales, products, shades, inventory, customers, expenses and more from CSV or Excel. Every file is checked and shown for review before anything is saved." />
      <Card title="1. Choose what you are importing">
        <div className="grid g3">
          <Field label="Data type"><select value={entity} onChange={(e) => { setEntity(e.target.value); setRes(null); }}>{Object.keys(TEMPLATES).map((k) => <option key={k} value={k}>{labelize(k.replace(/([A-Z])/g, ' $1').trim())}</option>)}</select></Field>
          <Field label="File (CSV, or Excel via Base44 file extraction)"><input type="file" accept=".csv,.xlsx,.xls" onChange={(e) => e.target.files?.[0] && onFile(e.target.files[0])} /></Field>
          <div className="stack sm"><span className="small muted">Need a template?</span><button className="btn sm" onClick={() => download(`${entity}_template.csv`, TEMPLATES[entity])}>Download {entity} template</button></div>
        </div>
        <p className="small muted" style={{ marginTop: 8 }}>Dates must be YYYY-MM-DD (ambiguous dates like 03/04/2026 are rejected, not guessed). Products, shades, customers and locations can be referenced by name, SKU or email.</p>
      </Card>
      <ErrorBox error={err} />
      {res && (
        <Card title={`2. Review — ${res.file}`}>
          <div className="row wrap"><Badge kind="positive">{res.valid_count} ready</Badge><Badge kind="critical">{res.row_count - res.valid_count} with errors (skipped)</Badge><Badge kind="medium">{warnings.length} warnings</Badge></div>
          {errors.length > 0 && <><h3 style={{ marginTop: 12 }}>Errors</h3><Table cols={[{ key: 'row', label: 'Row' }, { key: 'field', label: 'Field' }, { key: 'message', label: 'Problem' }]} rows={errors.slice(0, 50)} /></>}
          {warnings.length > 0 && <><h3 style={{ marginTop: 12 }}>Warnings (please check)</h3><Table cols={[{ key: 'row', label: 'Row' }, { key: 'type', label: 'Type', render: (r) => labelize(r.type) }, { key: 'message', label: 'Detail' }]} rows={warnings.slice(0, 50)} /></>}
          <Notice>Duplicates are skipped on import. Rows with errors are never saved. Nothing is filled in automatically.</Notice>
          <div className="row" style={{ marginTop: 12 }}><AsyncButton className="btn primary" disabled={!res.valid_count} onClick={commit}>Import {res.valid_count} records</AsyncButton><AsyncButton className="btn" onClick={reject}>Discard</AsyncButton></div>
        </Card>
      )}
      <Card title="Import history"><Table cols={[{ key: 'file_name', label: 'File' }, { key: 'target_entity', label: 'Type' }, { key: 'row_count', label: 'Rows', num: true }, { key: 'committed_count', label: 'Imported', num: true }, { key: 'status', label: 'Status', render: (r) => labelize(r.status) }, { key: 'created_date', label: 'When', render: (r) => fmtDateTime(r.created_date) }]} rows={batches.data || []} empty="No imports yet" /></Card>
    </div>
  );
}
