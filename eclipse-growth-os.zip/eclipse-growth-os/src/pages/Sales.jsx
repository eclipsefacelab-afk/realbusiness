import React, { useMemo, useState } from 'react';
import { api, intel } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { PageHead, Card, Stat, Tabs, Table, ErrorBox, Skeleton, Badge, Empty } from '../components/ui';
import { LineChart, BarList } from '../components/charts';
import EntityManager from '../components/EntityManager';
import { fmtMoney, fmtNum, fmtPct, labelize } from '../lib/format';
import { VARIANT_LABEL } from '../lib/constants';

const TAG = { best_seller: ['positive', 'Best seller'], fast_growing: ['opportunity', 'Fast growing'], declining: ['high', 'Declining'], slow_seller: ['monitor', 'Slow seller'], no_recent_sales: ['monitor', 'No recent sales'], low_margin: ['medium', 'Low margin'] };
export const Tags = ({ tags }) => <span className="chip-list">{(tags || []).map((t) => <Badge key={t} kind={TAG[t]?.[0] || 'neutral'}>{TAG[t]?.[1] || labelize(t)}</Badge>)}</span>;

function compare(sales, unit) {
  const key = (d) => { const x = new Date(d + 'T00:00:00'); if (unit === 'day') return d; if (unit === 'week') { const t = new Date(x); t.setDate(x.getDate() - x.getDay()); return t.toISOString().slice(0, 10); } if (unit === 'month') return d.slice(0, 7); if (unit === 'quarter') return `${d.slice(0, 4)}-Q${Math.floor((x.getMonth()) / 3) + 1}`; return d.slice(0, 4); };
  const m = {}; for (const s of sales) { if (!s.date) continue; const k = key(s.date); m[k] = (m[k] || 0) + (Number(s.revenue) || (Number(s.quantity) || 0) * (Number(s.unit_price) || 0)); }
  const n = { day: 30, week: 12, month: 12, quarter: 8, year: 5 }[unit];
  return Object.entries(m).sort(([a], [b]) => a.localeCompare(b)).slice(-n).map(([period, revenue]) => ({ period, revenue: Math.round(revenue) })); // eslint-disable-line no-unused-vars
}

export default function Sales() {
  const { business } = useApp();
  const cur = business?.currency;
  const [tab, setTab] = useState('overview');
  const [unit, setUnit] = useState('month');
  const a = useLoad((bid) => intel('analysis', { business_id: bid }));
  const sales = useLoad((bid) => api('list', { business_id: bid, entity: 'Sale', sort: '-date', limit: 5000 }).then((r) => r.items));
  const series = useMemo(() => compare(sales.data || [], unit), [sales.data, unit]);
  if (a.error) return <ErrorBox error={a.error} retry={a.reload} />;
  const s = a.data?.snapshot;
  return (
    <div className="stack lg">
      <PageHead title="Sales Intelligence" subtitle="What happened, why, and what it means — by product, shade, channel, location and period." />
      <Tabs tabs={[['overview', 'Overview'], ['products', 'Products'], ['variants', `${VARIANT_LABEL(business?.industry_module)}s`], ['records', 'Sales records']]} value={tab} onChange={setTab} />
      {!s ? <Skeleton /> : tab === 'overview' ? (
        <>
          <div className="grid g4">
            <Stat label="Revenue (30 days)" m={s.revenue_30d} format={(v) => fmtMoney(v, cur)} delta={s.revenue_change_pct.value} />
            <Stat label="Units (30 days)" m={s.units_30d} />
            <Stat label="Average sale" m={s.avg_transaction_value} format={(v) => fmtMoney(v, cur)} />
            <Stat label="Repeat customers" m={s.repeat_rate_pct} format={(v) => fmtPct(v)} />
          </div>
          <Card title="Revenue by period" action={<select value={unit} onChange={(e) => setUnit(e.target.value)} style={{ width: 'auto' }} aria-label="Period">{['day', 'week', 'month', 'quarter', 'year'].map((u) => <option key={u} value={u}>{labelize(u)}</option>)}</select>}>
            {series.length ? <LineChart data={series} series={[{ key: 'revenue', label: 'Revenue', color: 'var(--brand-2)' }]} format={(v) => fmtMoney(v, cur)} /> : <Empty title="No sales records yet" />}
          </Card>
          <div className="grid g2">
            <Card title="Sales by channel (90 days)"><BarList rows={s.channels.map((c) => ({ label: `${labelize(c.key)} · ${fmtPct(c.share_pct)}`, value: c.revenue }))} format={(v) => fmtMoney(v, cur)} /></Card>
            <Card title="Sales by location (90 days)"><BarList rows={s.locations.map((c) => ({ label: `${c.name} · ${fmtPct(c.share_pct)}`, value: c.revenue }))} format={(v) => fmtMoney(v, cur)} /></Card>
          </div>
          <div className="grid g3">
            {[['best_seller', 'Best sellers'], ['fast_growing', 'Fast-growing'], ['declining', 'Declining / needs attention']].map(([t, l]) => <Card key={t} title={l}>{(s.variants.length ? s.variants : s.products).filter((p) => p.tags.includes(t)).slice(0, 6).map((p) => <div key={p.id} className="row between small"><span>{p.name}</span><b>{p.growth_pct !== null ? fmtPct(p.growth_pct) : fmtNum(p.units_30d)}</b></div>)}</Card>)}
          </div>
        </>
      ) : tab === 'records' ? (
        <EntityManager entity="Sale" title="Sales" sort="-date" onChanged={() => { sales.reload(); a.reload(); }}
          columns={[{ key: 'date', label: 'Date', type: 'date' }, { key: 'product_id', label: 'Product', type: 'ref' }, { key: 'variant_id', label: VARIANT_LABEL(business?.industry_module), type: 'ref' }, { key: 'quantity', label: 'Qty', num: true }, { key: 'revenue', label: 'Revenue', num: true }, { key: 'channel', label: 'Channel', type: 'select' }]}
          fields={[{ key: 'date', label: 'Date', type: 'date', required: true }, { key: 'product_id', label: 'Product', type: 'ref', ref: 'Product' }, { key: 'variant_id', label: VARIANT_LABEL(business?.industry_module), type: 'ref', ref: 'ProductVariant', filterRef: (o, v) => !v.product_id || o.product_id === v.product_id }, { key: 'quantity', label: 'Quantity', type: 'number', required: true }, { key: 'unit_price', label: 'Unit price', type: 'number' }, { key: 'revenue', label: 'Revenue (after discounts)', type: 'number' }, { key: 'unit_cost', label: 'Unit cost', type: 'number', hint: 'Leave blank to use the product cost' }, { key: 'channel', label: 'Channel', type: 'select', options: ['retail', 'ecommerce', 'wholesale', 'event', 'popup', 'social', 'other'] }, { key: 'location_id', label: 'Location', type: 'ref', ref: 'BusinessLocation' }, { key: 'customer_id', label: 'Customer', type: 'ref', ref: 'Customer' }, { key: 'event_id', label: 'Event', type: 'ref', ref: 'Event' }, { key: 'campaign_id', label: 'Campaign', type: 'ref', ref: 'MarketingCampaign' }]}
          searchKeys={['date', 'channel']} />
      ) : (
        <Table cols={[{ key: 'name', label: 'Name' }, { key: 'units_30d', label: 'Units 30d', num: true }, { key: 'units_prev_30d', label: 'Prior 30d', num: true }, { key: 'growth_pct', label: 'Growth', num: true, render: (r) => (r.growth_pct === null ? '—' : fmtPct(r.growth_pct)) }, { key: 'revenue_90d', label: 'Revenue 90d', num: true, render: (r) => fmtMoney(r.revenue_90d, cur) }, { key: 'share_90d_pct', label: 'Share', num: true, render: (r) => fmtPct(r.share_90d_pct) }, { key: 'margin_pct', label: 'Margin', num: true, render: (r) => (r.margin_pct === null ? '—' : fmtPct(r.margin_pct)) }, { key: 'tags', label: 'Signals', render: (r) => <Tags tags={r.tags} /> }]} rows={tab === 'products' ? s.products : s.variants} empty="No product sales yet" />
      )}
    </div>
  );
}
