import React from 'react';
import { api } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { PageHead, Card, Badge, Notice, AsyncButton } from '../components/ui';
import { fmtDateTime, labelize } from '../lib/format';
import { INTEGRATION_TEST } from './integrations.ext';

// Catalogue of supported integration targets. None is "connected" until configured AND tested.
export const CATALOG = [
  ['ecommerce', ['Shopify', 'WooCommerce', 'Wix', 'Squarespace']], ['accounting', ['QuickBooks Online', 'Xero', 'Wave']], ['payments', ['Stripe', 'Square', 'PayPal']],
  ['crm', ['HubSpot', 'Salesforce']], ['advertising', ['Meta Ads', 'Google Ads', 'TikTok Ads']], ['analytics', ['Google Analytics 4']], ['erp', ['NetSuite', 'Odoo']],
  ['inventory', ['Cin7', 'inFlow']], ['manufacturing', ['Katana MRP']], ['marketing', ['Mailchimp', 'Klaviyo']], ['webhook', ['Generic webhook']],
];
const KIND = { connected: 'positive', pending: 'medium', failed: 'critical', disconnected: 'low', not_configured: 'neutral' };

export default function Integrations() {
  const { businessId, can, notify } = useApp();
  const list = useLoad((bid) => api('list', { business_id: bid, entity: 'Integration', limit: 200 }).then((r) => r.items));
  const by = Object.fromEntries((list.data || []).map((i) => [i.provider, i]));
  const plan = async (provider, category) => { await api('create', { business_id: businessId, entity: 'Integration', data: { provider, category, status: 'pending', enabled: false } }); notify(`${provider} marked as pending setup`); list.reload(); };
  const counts = ['connected', 'pending', 'failed', 'disconnected'].map((s) => [s, (list.data || []).filter((i) => i.status === s).length]);
  return (
    <div className="stack lg">
      <PageHead title="Integrations" subtitle="Connection status for external systems. An integration is shown as connected only after it has been configured with secure credentials and passed a live test." />
      <div className="row wrap">{counts.map(([s, n]) => <Badge key={s} kind={KIND[s]}>{labelize(s)}: {n}</Badge>)}</div>
      <Notice kind="warn"><b>No external integrations are connected yet.</b> Each one needs an API connection configured in Base44 (Connectors or secrets, never stored in this app's database) and a backend sync function. Until then, use <b>Data Import</b> (CSV/Excel) or manual entry. See <span className="kbd">docs/INTEGRATIONS.md</span> for the framework.</Notice>
      <div className="grid g3">
        {CATALOG.map(([cat, providers]) => (
          <Card key={cat} title={labelize(cat)}>
            <div className="stack sm">{providers.map((p) => { const i = by[p]; return (
              <div key={p} className="row between small"><span>{p}</span>
                <span className="row" style={{ gap: 6 }}><Badge kind={KIND[i?.status || 'not_configured']}>{labelize(i?.status || 'not configured')}</Badge>
                  {!i && can('integrations', 'write') && <AsyncButton className="btn sm" onClick={() => plan(p, cat)}>Plan setup</AsyncButton>}
                  {i && INTEGRATION_TEST(i, list.reload)}</span>
              </div>); })}</div>
          </Card>
        ))}
      </div>
      {(list.data || []).some((i) => i.last_tested_at) && <Card title="Test history">{list.data.filter((i) => i.last_tested_at).map((i) => <p key={i.id} className="small">{i.provider}: {i.last_test_result} — {fmtDateTime(i.last_tested_at)}</p>)}</Card>}
    </div>
  );
}
