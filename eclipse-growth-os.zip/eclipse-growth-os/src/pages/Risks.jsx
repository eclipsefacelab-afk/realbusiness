import React from 'react';
import { api } from '../lib/api';
import { useLoad } from '../lib/store';
import { PageHead, Card, LevelBadge, Notice } from '../components/ui';
import EntityManager from '../components/EntityManager';

export default function Risks() {
  const recs = useLoad((bid) => api('list', { business_id: bid, entity: 'Recommendation', sort: '-priority_score', limit: 200 }).then((r) => r.items.filter((x) => ['critical', 'high'].includes(x.finding_level) && !['superseded', 'done', 'rejected'].includes(x.status))));
  return (
    <div className="stack lg">
      <PageHead title="Risks" subtitle="Risks detected from your data plus your own risk register. Each risk has severity, probability (where supportable), impact, early-warning signs and a recommended action." />
      <Card title="Detected from your data">{(recs.data || []).length ? recs.data.map((r) => <div key={r.id} className="row between small" style={{ padding: '6px 0', borderBottom: '1px solid var(--border)' }}><span><LevelBadge level={r.finding_level} /> {r.title}</span><span className="muted">{r.recommendation}</span></div>) : <p className="muted small">No high-severity risks detected from current data.</p>}</Card>
      <EntityManager entity="Risk" title="Risk register"
        columns={[{ key: 'title', label: 'Risk' }, { key: 'category', label: 'Category', type: 'select' }, { key: 'severity', label: 'Severity', type: 'select' }, { key: 'probability', label: 'Probability', type: 'select' }, { key: 'status', label: 'Status', type: 'select' }, { key: 'detected_by', label: 'Source', type: 'select' }]}
        fields={[{ key: 'title', label: 'Risk', required: true, wide: true }, { key: 'category', label: 'Category', type: 'select', options: ['cash_flow', 'inventory', 'customer_concentration', 'supplier', 'marketing_dependency', 'operational', 'staffing', 'expansion', 'financial', 'competitive', 'technology', 'regulatory', 'other'] }, { key: 'severity', label: 'Severity', type: 'select', options: ['low', 'moderate', 'high', 'critical'] }, { key: 'probability', label: 'Probability', type: 'select', options: ['unknown', 'low', 'medium', 'high'], hint: 'Use "unknown" unless you have evidence' }, { key: 'impact', label: 'Impact', type: 'textarea' }, { key: 'early_warning_indicators', label: 'Early warning signs', type: 'list' }, { key: 'recommended_action', label: 'Recommended action', type: 'textarea' }, { key: 'status', label: 'Status', type: 'select', options: ['open', 'mitigating', 'closed'] }]} />
      <Notice>Legal, tax and regulatory risks: the platform can flag them but cannot give professional advice — consult a qualified professional.</Notice>
    </div>
  );
}
