// Executive dashboard — answers: Where are we? Are we healthy? What is changing? Biggest problems?
// Opportunities? What next? On track for goals?
import React from 'react';
import { api, intel } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { Link } from '../lib/router';
import { Card, PageHead, Stat, ErrorBox, Skeleton, Basis, LevelBadge, Progress, AsyncButton, Empty, Notice, Badge } from '../components/ui';
import { LineChart, ScoreRing } from '../components/charts';
import { fmtMoney, fmtPct, fmtNum, fmtDate, labelize } from '../lib/format';
import { STAGE_LABELS } from '../lib/constants';

export default function Overview() {
  const { business, can, notify } = useApp();
  const cur = business?.currency;
  const strategy = can('strategy', 'read');
  const a = useLoad((bid) => intel('analysis', { business_id: bid }));
  const recs = useLoad((bid) => (strategy ? api('list', { business_id: bid, entity: 'Recommendation', sort: '-priority_score', limit: 50 }).then((r) => r.items.filter((x) => !['rejected', 'superseded', 'done'].includes(x.status))) : Promise.resolve([])));
  const goals = useLoad((bid) => (strategy ? api('goals.refresh', { business_id: bid }).then((r) => r.goals) : Promise.resolve([])));
  const tasks = useLoad((bid) => (can('tasks', 'read') ? api('list', { business_id: bid, entity: 'Task', limit: 1000 }).then((r) => r.items) : Promise.resolve([])));
  const refresh = async () => { await intel('refresh', { business_id: business.id }); notify('Analysis refreshed'); a.reload(); recs.reload(); goals.reload(); };

  if (a.error) return <ErrorBox error={a.error} retry={a.reload} />;
  if (!a.data) return <><PageHead title="Overview" /><Skeleton n={6} /></>;
  const s = a.data.snapshot, h = a.data.health, st = a.data.stage;
  const crit = (recs.data || []).filter((r) => ['critical', 'high'].includes(r.finding_level)).slice(0, 4);
  const opps = (recs.data || []).filter((r) => r.finding_level === 'opportunity').slice(0, 3);
  const next = (recs.data || []).filter((r) => r.horizon === 'this_week').slice(0, 3);
  const invAlerts = (s.inventory || []).filter((i) => i.flags.some((f) => ['out_of_stock', 'stockout_risk', 'low_stock'].includes(f))).slice(0, 5);
  const plan = ['30', '60', '90'].map((hz) => { const t = (tasks.data || []).filter((x) => x.plan_horizon === hz && x.status !== 'cancelled'); return { hz, total: t.length, done: t.filter((x) => x.status === 'completed').length, delayed: t.filter((x) => x.status === 'delayed').length }; });
  const myTasks = (tasks.data || []).filter((t) => !['completed', 'cancelled'].includes(t.status)).sort((x, y) => String(x.due_date).localeCompare(String(y.due_date))).slice(0, 6);
  const reliableCampaigns = (s.campaigns || []).filter((c) => c.reliable);

  return (
    <div className="stack lg">
      <PageHead title={`Good to see you`} subtitle={`Here is where ${business.name} stands today. Labels show whether a number is actual data, an estimate or a forecast.`}>
        {strategy && <AsyncButton className="btn" onClick={refresh}>↻ Refresh analysis</AsyncButton>}
        {strategy && <Link to="/next" className="btn accent">What should I do next? →</Link>}
      </PageHead>

      {strategy && (
        <div className="grid g3">
          <div className="card hero span2">
            <div className="row top" style={{ gap: 20 }}>
              <ScoreRing score={h.overall_score} size={104} />
              <div className="stack sm" style={{ flex: 1 }}>
                <div className="muted small">BUSINESS HEALTH {h.preliminary && '· preliminary'} · <span style={{ textTransform: 'uppercase' }}>{labelize(h.overall_basis)}</span></div>
                <h2 style={{ fontSize: 22 }}>Stage: {st.label}</h2>
                <div style={{ color: '#efe4f6' }}>{st.focus}</div>
                <div className="small muted">{st.reason}</div>
                <div className="small muted">Data coverage: {h.data_coverage_pct}% of areas scored{h.preliminary ? ' — add more data for a reliable score.' : '.'}</div>
              </div>
            </div>
          </div>
          <Card title="Are we on track?" action={<Link to="/goals" className="small">Goals →</Link>}>
            {(goals.data || []).length ? <div className="stack sm">{goals.data.slice(0, 4).map((g) => <div key={g.id}><div className="row between small"><span>{g.title}</span><Badge kind={g.status === 'behind' ? 'critical' : g.status === 'at_risk' ? 'medium' : g.status === 'ahead' || g.status === 'achieved' ? 'positive' : 'neutral'}>{labelize(g.status)}</Badge></div><Progress pct={g.progress_pct} status={g.status} /></div>)}</div> : <Empty title="No goals yet"><Link to="/goals">Set a measurable goal</Link></Empty>}
          </Card>
        </div>
      )}

      <div className="grid g4">
        <Stat label="Revenue (30 days)" m={s.revenue_30d} format={(v) => fmtMoney(v, cur)} delta={s.revenue_change_pct.value} />
        <Stat label="Est. monthly profit" m={s.net_profit_monthly} format={(v) => fmtMoney(v, cur)} />
        <Stat label="Cash position" m={s.cash} format={(v) => fmtMoney(v, cur)} sub={s.runway_months.note === 'positive' ? 'Cash-flow positive' : s.runway_months.value !== null ? `≈ ${fmtNum(s.runway_months.value, 1)} months runway (estimate)` : s.cash.source} />
        <Stat label="New customers (30 days)" m={s.new_customers_30d} sub={s.repeat_rate_pct.value !== null ? `Repeat rate ${fmtPct(s.repeat_rate_pct.value)}` : s.new_customers_30d.source} />
      </div>

      <div className="grid g3">
        <Card title="Sales trend" className="span2" action={<Link to="/sales" className="small">Sales →</Link>}>
          {s.monthly?.length ? <LineChart data={s.monthly} series={[{ key: 'revenue', label: 'Revenue (actual)', color: 'var(--brand-2)' }]} format={(v) => fmtMoney(v, cur)} /> : <Empty title="No sales recorded yet">Import sales to see trends. <Link to="/import">Import data</Link></Empty>}
        </Card>
        <Card title="Inventory alerts" action={<Link to="/inventory" className="small">Inventory →</Link>}>
          {invAlerts.length ? <div className="stack sm">{invAlerts.map((i) => <div key={i.id} className="small"><b>{i.name}</b><div className="muted">{i.on_hand} on hand · {i.days_of_cover !== null ? `≈${i.days_of_cover} days left (forecast)` : labelize(i.flags[0])}</div></div>)}</div> : <div className="muted small">{s.inventory?.length ? 'No stock-out risks detected.' : 'No inventory recorded yet.'}</div>}
        </Card>
      </div>

      {strategy && (
        <div className="grid g3">
          <Card title="Biggest problems" action={<Link to="/risks" className="small">Risks →</Link>}>
            {crit.length ? <div className="stack sm">{crit.map((r) => <div key={r.id}><LevelBadge level={r.finding_level} /> <span className="small">{r.title}</span></div>)}</div> : <div className="muted small">No critical or high-priority issues detected from current data.</div>}
          </Card>
          <Card title="Opportunities">
            {opps.length ? <div className="stack sm">{opps.map((r) => <div key={r.id} className="small">✦ {r.title}</div>)}</div> : <div className="muted small">No clear opportunities yet — more data helps.</div>}
          </Card>
          <Card title="This week" action={<Link to="/next" className="small">All actions →</Link>}>
            {next.length ? <ol className="small" style={{ paddingLeft: 18, margin: 0 }}>{next.map((r) => <li key={r.id} style={{ marginBottom: 6 }}>{r.next_step || r.title}</li>)}</ol> : <div className="muted small">Nothing urgent this week. <Link to="/next">See the full plan</Link></div>}
          </Card>
        </div>
      )}

      <div className="grid g3">
        {can('tasks', 'read') && <Card title="30 / 60 / 90-day progress" action={<Link to="/plan" className="small">Plan →</Link>}>
          {plan.some((p) => p.total) ? <div className="stack sm">{plan.map((p) => <div key={p.hz}><div className="row between small"><span>{p.hz}-day plan</span><span>{p.done}/{p.total}{p.delayed ? ` · ${p.delayed} delayed` : ''}</span></div><Progress pct={p.total ? (p.done / p.total) * 100 : 0} /></div>)}</div> : <Empty title="No plan yet"><Link to="/plan">Generate a 30/60/90-day plan</Link></Empty>}
        </Card>}
        {can('tasks', 'read') && <Card title="Open tasks">
          {myTasks.length ? <div className="stack sm">{myTasks.map((t) => <div key={t.id} className="row between small"><span>{t.title}</span><span className={t.status === 'delayed' ? 'delta down' : 'muted'}>{fmtDate(t.due_date)}</span></div>)}</div> : <div className="muted small">No open tasks.</div>}
        </Card>}
        {can('marketing', 'read') && <Card title="Marketing performance" action={<Link to="/marketing" className="small">Marketing →</Link>}>
          {reliableCampaigns.length ? <div className="stack sm">{reliableCampaigns.slice(0, 4).map((c) => <div key={c.id} className="row between small"><span>{c.name}</span><span>CPA {fmtMoney(c.cpa, cur)} · ROAS {c.roas ?? '—'}</span></div>)}</div> : <div className="muted small">{(s.campaigns || []).length ? 'Campaigns exist but none have reliable tracking (promo code / UTM), so results are not attributed.' : 'No campaigns recorded.'}</div>}
        </Card>}
      </div>
      {a.data.missing?.length > 0 && strategy && <Notice kind="warn"><b>To improve accuracy:</b> {a.data.missing.slice(0, 4).map((m) => `${m.area}: ${m.what}`).join(' · ')}</Notice>}
    </div>
  );
}
