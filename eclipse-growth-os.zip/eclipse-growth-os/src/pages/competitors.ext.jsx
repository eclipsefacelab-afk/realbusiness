import React, { useState } from 'react';
import { api } from '../lib/api';
import { useApp } from '../lib/store';
import { Modal, Field, AsyncButton, Badge } from '../components/ui';
import { fmtDate, today } from '../lib/format';

function FactsButton({ r, reload }) {
  const { businessId, can } = useApp();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ type: 'pricing', fact: '', source: '', date: today(), verified: false });
  const add = async () => { await api('update', { business_id: businessId, entity: 'Competitor', id: r.id, data: { facts: [...(r.facts || []), f] } }); setOpen(false); reload(); };
  return (
    <>
      <button className="btn sm" onClick={() => setOpen(true)}>Facts</button>
      {open && <Modal title={`Facts — ${r.name}`} onClose={() => setOpen(false)} wide>
        <div className="stack">
          {(r.facts || []).map((x, i) => <div key={i} className="small"><Badge kind={x.verified ? 'positive' : 'low'}>{x.verified ? 'Verified' : 'Unverified'}</Badge> <b>{x.type}</b>: {x.fact} <span className="faint">— {x.source || 'no source'}, {fmtDate(x.date)}</span></div>)}
          {can('competitors', 'write') && <div className="grid g2">
            <Field label="Type"><select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}>{['pricing', 'product', 'promotion', 'positioning', 'review', 'location', 'marketing', 'launch'].map((t) => <option key={t}>{t}</option>)}</select></Field>
            <Field label="Date observed"><input type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} /></Field>
            <div className="span2"><Field label="Fact"><textarea value={f.fact} onChange={(e) => setF({ ...f, fact: e.target.value })} /></Field></div>
            <Field label="Source" hint="URL, store visit, customer comment…"><input value={f.source} onChange={(e) => setF({ ...f, source: e.target.value })} /></Field>
            <Field label="I verified this"><input type="checkbox" style={{ width: 'auto' }} checked={f.verified} onChange={(e) => setF({ ...f, verified: e.target.checked })} /></Field>
            <div className="span2"><AsyncButton className="btn primary" disabled={!f.fact} onClick={add}>Add fact</AsyncButton></div>
          </div>}
        </div>
      </Modal>}
    </>
  );
}
import { CompetitorSummary } from './competitors.ext.p2';
export const COMPETITOR_ACTIONS = (r, reload) => <><FactsButton r={r} reload={reload} /><CompetitorSummary r={r} reload={reload} /></>;
