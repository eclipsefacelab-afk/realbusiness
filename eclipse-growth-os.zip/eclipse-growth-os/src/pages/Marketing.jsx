import React, { useState } from 'react';
import { intel } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { PageHead, Tabs, Table, Notice, Modal, AsyncButton, Card, Badge } from '../components/ui';
import EntityManager from '../components/EntityManager';
import { fmtMoney, fmtPct, fmtDate } from '../lib/format';

export default function Marketing() {
  const { business, businessId, can } = useApp();
  const cur = business?.currency;
  const [tab, setTab] = useState('performance');
  const [report, setReport] = useState(null);
  const a = useLoad((bid) => intel('analysis', { business_id: bid }));
  const s = a.data?.snapshot;
  const runReport = async (e) => { const r = await intel('event.report', { business_id: businessId, event_id: e.id }); setReport({ event: e, ...r.report }); };
  return (
    <div className="stack lg">
      <PageHead title="Marketing & Events" subtitle="Which activities appear to produce customers. Attribution is shown only when tracking (promo codes, UTM, platform reports) supports it." />
      <Tabs tabs={[['performance', 'Performance'], ['campaigns', 'Campaigns'], ['channels', 'Channels'], ['events', 'Events & trade shows'], ['results', 'Event results']]} value={tab} onChange={setTab} />
      {tab === 'performance' && s && (
        <>
          <Table cols={[{ key: 'name', label: 'Campaign' }, { key: 'spend', label: 'Spend', num: true, render: (r) => fmtMoney(r.spend, cur) }, { key: 'customers', label: 'Customers', num: true }, { key: 'cpa', label: 'Cost / customer', num: true, render: (r) => (r.cpa === null ? '—' : fmtMoney(r.cpa, cur)) }, { key: 'roas', label: 'Return on ad spend', num: true, render: (r) => (r.roas === null ? '—' : `${r.roas}×`) }, { key: 'attribution', label: 'Tracking', render: (r) => <Badge kind={r.reliable ? 'positive' : 'low'}>{r.reliable ? r.attribution.replace('_', ' ') : 'not attributable'}</Badge> }]} rows={s.campaigns} empty="No campaigns recorded" />
          <Card title="Events at a glance"><Table cols={[{ key: 'name', label: 'Event' }, { key: 'date', label: 'Date', render: (r) => fmtDate(r.date) }, { key: 'cost', label: 'Cost', num: true, render: (r) => fmtMoney(r.cost, cur) }, { key: 'revenue', label: 'Sales', num: true, render: (r) => fmtMoney(r.revenue, cur) }, { key: 'leads', label: 'Leads', num: true }, { key: 'conversion_pct', label: 'Conversion', num: true, render: (r) => fmtPct(r.conversion_pct) }, { key: 'r', label: '', render: (r) => r.has_result && can('events', 'write') ? <AsyncButton className="btn sm" onClick={() => runReport(r)}>Performance report</AsyncButton> : <span className="small faint">{r.status === 'completed' ? 'add results' : r.status}</span> }]} rows={s.events} empty="No events recorded" /></Card>
          <Notice>Blended cost per customer (all marketing ÷ new customers): {s.cac.value !== null ? fmtMoney(s.cac.value, cur) : '—'} <span className="small">({s.cac.source})</span></Notice>
        </>
      )}
      {tab === 'campaigns' && <EntityManager entity="MarketingCampaign" title="Campaigns" onChanged={a.reload}
        columns={[{ key: 'name', label: 'Name' }, { key: 'channel_id', label: 'Channel', type: 'ref' }, { key: 'start_date', label: 'Start', type: 'date' }, { key: 'spend', label: 'Spend', num: true }, { key: 'customers_acquired', label: 'Customers', num: true }, { key: 'attribution_method', label: 'Tracking', type: 'select' }]}
        fields={[{ key: 'name', label: 'Name', required: true }, { key: 'channel_id', label: 'Channel', type: 'ref', ref: 'MarketingChannel' }, { key: 'start_date', label: 'Start', type: 'date' }, { key: 'end_date', label: 'End', type: 'date' }, { key: 'spend', label: 'Spend', type: 'number' }, { key: 'impressions', label: 'Impressions', type: 'number' }, { key: 'clicks', label: 'Clicks', type: 'number' }, { key: 'leads', label: 'Leads', type: 'number' }, { key: 'customers_acquired', label: 'Customers acquired', type: 'number' }, { key: 'attributed_revenue', label: 'Attributed revenue', type: 'number' }, { key: 'attribution_method', label: 'How results were tracked', type: 'select', options: ['none', 'promo_code', 'utm_tracking', 'platform_reported', 'survey', 'estimate'], hint: '"None" or "estimate" = results will not be attributed' }, { key: 'status', label: 'Status', type: 'select', options: ['planned', 'active', 'completed', 'cancelled'] }, { key: 'notes', label: 'Notes', type: 'textarea' }]} />}
      {tab === 'channels' && <EntityManager entity="MarketingChannel" title="Channels" columns={[{ key: 'name', label: 'Name' }, { key: 'kind', label: 'Kind', type: 'select' }, { key: 'monthly_budget', label: 'Monthly budget', num: true }, { key: 'status', label: 'Status', type: 'select' }]} fields={[{ key: 'name', label: 'Name', required: true }, { key: 'kind', label: 'Kind', type: 'select', options: ['website', 'social', 'email', 'paid_ads', 'influencer', 'events', 'trade_show', 'promotion', 'organic', 'other'] }, { key: 'monthly_budget', label: 'Monthly budget', type: 'number' }, { key: 'status', label: 'Status', type: 'select', options: ['active', 'paused'] }]} />}
      {tab === 'events' && <EntityManager entity="Event" title="Events" sort="-start_date" onChanged={a.reload}
        columns={[{ key: 'name', label: 'Event' }, { key: 'kind', label: 'Type', type: 'select' }, { key: 'start_date', label: 'Date', type: 'date' }, { key: 'location_text', label: 'Where' }, { key: 'cost', label: 'Cost', num: true }, { key: 'status', label: 'Status', type: 'select' }]}
        fields={[{ key: 'name', label: 'Event name', required: true }, { key: 'kind', label: 'Type', type: 'select', options: ['trade_show', 'exhibition', 'popup', 'market', 'launch', 'other'] }, { key: 'start_date', label: 'Start', type: 'date' }, { key: 'end_date', label: 'End', type: 'date' }, { key: 'location_text', label: 'Location' }, { key: 'country', label: 'Country' }, { key: 'cost', label: 'Total cost', type: 'number', hint: 'Booth, travel, samples, staff' }, { key: 'status', label: 'Status', type: 'select', options: ['planned', 'completed', 'cancelled'] }, { key: 'goals', label: 'Goals for this event', type: 'textarea' }]} />}
      {tab === 'results' && <EntityManager entity="EventResult" title="Event results" onChanged={a.reload}
        columns={[{ key: 'event_id', label: 'Event', type: 'ref' }, { key: 'visitors', label: 'Visitors', num: true }, { key: 'leads', label: 'Leads', num: true }, { key: 'customers', label: 'Customers', num: true }, { key: 'sales_revenue', label: 'Sales', num: true }]}
        fields={[{ key: 'event_id', label: 'Event', type: 'ref', ref: 'Event', required: true }, { key: 'visitors', label: 'Visitors', type: 'number' }, { key: 'leads', label: 'Leads (contacts collected)', type: 'number' }, { key: 'customers', label: 'Customers (bought)', type: 'number' }, { key: 'sales_revenue', label: 'Sales at event', type: 'number' }, { key: 'units_sold', label: 'Units sold', type: 'number' }, { key: 'customer_feedback', label: 'Customer feedback', type: 'textarea' }, { key: 'follow_up_opportunities', label: 'Follow-up opportunities', type: 'textarea' }]} />}
      {report && (
        <Modal title={`Event Performance Report — ${report.event.name}`} onClose={() => setReport(null)} wide footer={<button className="btn" onClick={() => window.print()}>Print / save PDF</button>}>
          <div className="grid g3"><Card className="tight flat" title="Revenue">{fmtMoney(report.revenue, cur)}</Card><Card className="tight flat" title="Cost">{fmtMoney(report.cost, cur)}</Card><Card className="tight flat" title="Estimated return">{report.estimated_return === null ? '—' : `${report.estimated_return}%`}</Card></div>
          <p className="small muted">{report.estimated_return_note}</p>
          <h3>What worked</h3><ul>{report.what_worked.map((x, i) => <li key={i}>{x}</li>)}</ul>
          <h3>What did not work</h3><ul>{report.what_did_not_work.map((x, i) => <li key={i}>{x}</li>)}</ul>
          <h3>Customer opportunities</h3><p>{report.customer_opportunities}</p>
          <h3>Follow-up actions</h3><ul>{report.follow_up_actions.map((x, i) => <li key={i}>{x}</li>)}</ul>
          <h3>Lessons for next time</h3><ul>{report.lessons.map((x, i) => <li key={i}>{x}</li>)}</ul>
        </Modal>
      )}
    </div>
  );
}
