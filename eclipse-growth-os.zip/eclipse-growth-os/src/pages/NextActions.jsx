import React from 'react';
import { intel } from '../lib/api';
import { useLoad } from '../lib/store';
import { PageHead, ErrorBox, Skeleton, Empty, Notice, Card } from '../components/ui';
import Recommendation from '../components/Recommendation';

export default function NextActions() {
  const r = useLoad((bid) => intel('nextActions', { business_id: bid }));
  if (r.error) return <ErrorBox error={r.error} retry={r.reload} />;
  const d = r.data;
  const Section = ({ title, items, hint }) => (
    <section className="stack">
      <div className="row between"><h2>{title}</h2><span className="small muted">{hint}</span></div>
      {items?.length ? items.map((rec) => <Recommendation key={rec.id} rec={rec} onChanged={r.reload} compact={title !== 'This week'} />) : <div className="muted small">Nothing here right now.</div>}
    </section>
  );
  return (
    <div className="stack lg">
      <PageHead title="What should I do next?" subtitle="A short, prioritised list based on your current data. Each action shows why it matters, the evidence, effort, and how to measure success. Estimates are never guarantees." />
      {!d ? <Skeleton n={3} /> : (
        <>
          {d.stage && <Notice>Stage: <b>{d.stage.label}</b> — {d.stage.focus}</Notice>}
          {![...d.this_week, ...d.this_month, ...d.this_quarter].length && <Empty title="No actions yet">Add sales, inventory and expense data (Data Import) so the platform can find problems and opportunities.</Empty>}
          <Section title="This week" items={d.this_week} hint="Max 3 — focus beats volume" />
          <Section title="This month" items={d.this_month} hint="Max 5" />
          <Section title="This quarter" items={d.this_quarter} />
          {d.later?.length > 0 && <Section title="Later (deprioritised to avoid overload)" items={d.later} />}
          {d.positives?.length > 0 && <Card title="What's working">{d.positives.map((p, i) => <p key={i}>✓ <b>{p.title}</b> — <span className="muted">{p.situation}</span></p>)}</Card>}
          {d.missing?.length > 0 && <Card title="Information that would improve these recommendations">{d.missing.map((m, i) => <p key={i} className="small"><b>{m.area}:</b> {m.what} — <span className="muted">{m.why}</span></p>)}</Card>}
          {Object.keys(d.learning || {}).length > 0 && <Notice>Learning from your results: {Object.entries(d.learning).map(([k, v]) => `${k.replace(/_/g, ' ')} worked ${Math.round(v.success_rate * 100)}% of ${v.total} times`).join(' · ')}</Notice>}
          <p className="small faint">{d.note}</p>
        </>
      )}
    </div>
  );
}
