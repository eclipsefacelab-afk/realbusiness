import React, { useState } from 'react';
import { api, intel, uploadPrivateFile } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { PageHead, Card, Table, Field, AsyncButton, ErrorBox, Notice, Modal } from '../components/ui';
import { fmtDate, labelize } from '../lib/format';

const CATS = ['financial_statement', 'sales_report', 'inventory_report', 'marketing_report', 'business_plan', 'supplier_document', 'product_list', 'pricing', 'strategic_plan', 'meeting_notes', 'procedure', 'manufacturing_spec', 'training', 'other'];
export default function Documents() {
  const { businessId, can, notify } = useApp();
  const list = useLoad((bid) => api('list', { business_id: bid, entity: 'Document', limit: 1000 }).then((r) => r.items));
  const [f, setF] = useState({ category: 'other', visibility: 'managers' });
  const [file, setFile] = useState(null);
  const [err, setErr] = useState(null);
  const [view, setView] = useState(null);
  const upload = async () => {
    setErr(null);
    try {
      const up = await uploadPrivateFile(file);
      await api('create', { business_id: businessId, entity: 'Document', data: { title: f.title || file.name, category: f.category, visibility: f.visibility, file_uri: up.file_uri, file_name: file.name, mime_type: file.type, size_bytes: file.size } });
      setFile(null); setF({ category: 'other', visibility: 'managers' }); notify('Uploaded'); list.reload();
    } catch (e) { setErr(e); }
  };
  const open = async (d) => { const r = await api('document.url', { business_id: businessId, id: d.id }); window.open(r.url, '_blank', 'noopener'); };
  const analyze = async (d) => { const r = await intel('document.analyze', { business_id: businessId, id: d.id }); if (r.ok) { notify('Summary ready'); list.reload(); } else setErr(new Error(r.error)); };
  return (
    <div className="stack lg">
      <PageHead title="Business Knowledge Center" subtitle="Central, private storage for financial statements, reports, plans, supplier documents and notes. Files are stored privately and opened with short-lived links." />
      {can('documents', 'write') && <Card title="Upload a document">
        <div className="grid g4">
          <Field label="File"><input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} /></Field>
          <Field label="Title"><input value={f.title || ''} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="Defaults to file name" /></Field>
          <Field label="Category"><select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{CATS.map((c) => <option key={c} value={c}>{labelize(c)}</option>)}</select></Field>
          <Field label="Who can see it"><select value={f.visibility} onChange={(e) => setF({ ...f, visibility: e.target.value })}><option value="owner_admin">Owner & admins only</option><option value="finance">People with finance access</option><option value="managers">Managers and above</option><option value="all_members">All members</option></select></Field>
        </div>
        <div style={{ marginTop: 10 }}><AsyncButton className="btn primary" disabled={!file} onClick={upload}>Upload</AsyncButton></div>
      </Card>}
      <ErrorBox error={err} />
      <Table cols={[{ key: 'title', label: 'Document' }, { key: 'category', label: 'Category', render: (r) => labelize(r.category) }, { key: 'visibility', label: 'Visible to', render: (r) => labelize(r.visibility) }, { key: 'created_date', label: 'Added', render: (r) => fmtDate(r.created_date) }, { key: 'a', label: '', render: (r) => <div className="row" onClick={(e) => e.stopPropagation()} style={{ gap: 4, justifyContent: 'flex-end' }}>{r.file_uri && <AsyncButton className="btn sm" onClick={() => open(r)}>Open</AsyncButton>}{r.file_uri && can('documents', 'write') && <AsyncButton className="btn sm" onClick={() => analyze(r)}>{r.extracted_summary ? 'Re-summarise' : 'AI summary'}</AsyncButton>}</div> }]} rows={list.data || []} onRow={(r) => r.extracted_summary && setView(r)} empty="No documents yet" />
      <Notice>Documents are treated as untrusted data: the AI summarises them but never follows instructions written inside them.</Notice>
      {view && <Modal title={view.title} onClose={() => setView(null)} wide><p style={{ whiteSpace: 'pre-wrap' }}>{view.extracted_summary}</p><p className="small faint">AI summary — verify important figures against the original document.</p></Modal>}
    </div>
  );
}
