import React from 'react';
import { PageHead, Notice } from '../components/ui';
import EntityManager from '../components/EntityManager';
import { COMPETITOR_ACTIONS } from './competitors.ext';

export default function Competitors() {
  return (
    <div className="stack lg">
      <PageHead title="Competitors" subtitle="Track what you know about competitors. Facts you verified are kept separate from AI interpretation." />
      <Notice>The platform never invents competitor information. Record facts with their source and date; mark them verified only when you have checked them.</Notice>
      <EntityManager entity="Competitor" title="Competitors" rowActions={COMPETITOR_ACTIONS}
        columns={[{ key: 'name', label: 'Name' }, { key: 'positioning', label: 'Positioning' }, { key: 'price_range', label: 'Price range' }, { key: 'facts', label: 'Facts', render: (r) => `${(r.facts || []).length} (${(r.facts || []).filter((f) => f.verified).length} verified)` }]}
        fields={[{ key: 'name', label: 'Name', required: true }, { key: 'website', label: 'Website' }, { key: 'positioning', label: 'Positioning', type: 'textarea' }, { key: 'price_range', label: 'Price range' }, { key: 'locations', label: 'Locations', type: 'textarea' }, { key: 'products', label: 'Products', type: 'textarea' }, { key: 'strengths', label: 'Strengths (your view)', type: 'textarea' }, { key: 'weaknesses', label: 'Weaknesses (your view)', type: 'textarea' }]} />
      <FactsHelp />
    </div>
  );
}
function FactsHelp() { return <p className="small faint">Tip: add individual facts (pricing, promotions, launches, reviews) from the competitor's row → Facts. Each fact stores source, date and whether you verified it.</p>; }
