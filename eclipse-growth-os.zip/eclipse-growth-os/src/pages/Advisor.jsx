import React, { useEffect, useRef, useState } from 'react';
import { api, intel } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { PageHead, Card, Basis, Confidence, ErrorBox, Notice, Badge } from '../components/ui';
import Markdown from '../components/Markdown';

const SUGGESTED = ['How is my business doing?', 'What should I focus on this month?', 'Why are sales down?', 'What should I produce more of?', 'Can I afford another location?', 'What is my biggest risk?', 'Where should I spend my next $10,000?', 'What should I do this week?', 'What are my biggest growth opportunities?'];

export function AnswerView({ s }) {
  return (
    <div className="stack sm">
      <Markdown text={s.answer} />
      <div className="row wrap" style={{ gap: 6 }}><Confidence c={s.confidence} />{s.agents?.map((a) => <Badge key={a} kind="neutral">{a}</Badge>)}</div>
      <dl style={{ display: 'grid', gridTemplateColumns: '120px 1fr', gap: '6px 12px', fontSize: 13, margin: 0 }}>
        <dt className="muted"><b>What</b></dt><dd style={{ margin: 0 }}>{s.what}</dd>
        <dt className="muted"><b>Why</b></dt><dd style={{ margin: 0 }}>{s.why}</dd>
        <dt className="muted"><b>Evidence</b></dt><dd style={{ margin: 0 }}>{(s.evidence || []).length ? s.evidence.map((e, i) => <div key={i}>• {e.fact} <Basis b={e.basis} /></div>) : <span className="faint">No supporting records</span>}</dd>
        <dt className="muted"><b>Expected impact</b></dt><dd style={{ margin: 0 }}>{s.expected_impact} <span className="faint small">(estimate)</span></dd>
        <dt className="muted"><b>Risks</b></dt><dd style={{ margin: 0 }}>{s.risks}</dd>
        <dt className="muted"><b>Next step</b></dt><dd style={{ margin: 0 }}><b>{s.next_step}</b></dd>
      </dl>
      {s.missing_information?.length > 0 && <div className="small muted">Would improve this answer: {s.missing_information.join('; ')}</div>}
      {s.unresolved_uncertainty?.length > 0 && <div className="small muted">Unresolved uncertainty: {s.unresolved_uncertainty.join('; ')}</div>}
      {s.professional_advice_needed && <Notice kind="warn">Consider consulting: {s.professional_advice_needed}</Notice>}
      {s.grounding_warning && <Notice kind="warn">{s.grounding_warning}</Notice>}
    </div>
  );
}

export default function Advisor() {
  const { businessId } = useApp();
  const convs = useLoad((bid) => api('list', { business_id: bid, entity: 'AIConversation', sort: '-last_message_at', limit: 30 }).then((r) => r.items));
  const [conv, setConv] = useState(null);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);
  const end = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }); }, [conv, busy]);
  const ask = async (question) => {
    const text = (question || q).trim(); if (!text) return;
    setBusy(true); setErr(null); setQ('');
    setConv((c) => ({ ...(c || {}), messages: [...(c?.messages || []), { role: 'user', content: text }] }));
    try {
      const r = await intel('advisor.ask', { business_id: businessId, question: text, conversation_id: conv?.id });
      const fresh = await api('get', { business_id: businessId, entity: 'AIConversation', id: r.conversation_id });
      setConv(fresh.item); convs.reload();
      if (!r.ok) setErr(new Error(r.error));
    } catch (e) { setErr(e); } finally { setBusy(false); }
  };
  return (
    <div className="grid" style={{ gridTemplateColumns: 'minmax(0,1fr) 260px', alignItems: 'start' }}>
      <div className="stack">
        <PageHead title="AI Business Advisor" subtitle="Ask anything about your business. Answers use only your data and say clearly what is fact, estimate or assumption — and when the data isn't enough." />
        <div className="chat">
          {!(conv?.messages?.length) && <Card title="Try asking"><div className="chip-list">{SUGGESTED.map((s) => <button key={s} className="btn sm" onClick={() => ask(s)}>{s}</button>)}</div></Card>}
          {(conv?.messages || []).map((m, i) => <div key={i} className={`msg ${m.role}`}>{m.role === 'assistant' && m.structured ? <AnswerView s={m.structured} /> : <span style={{ whiteSpace: 'pre-wrap' }}>{m.content}</span>}</div>)}
          {busy && <div className="msg assistant"><span className="spinner" /> Analysing your business data…</div>}
          <div ref={end} />
        </div>
        <ErrorBox error={err} />
        <form className="row" onSubmit={(e) => { e.preventDefault(); ask(); }} style={{ position: 'sticky', bottom: 12 }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="e.g. Which shades should we produce more of next month?" aria-label="Your question" disabled={busy} />
          <button className="btn primary" disabled={busy || !q.trim()}>Ask</button>
        </form>
        <p className="small faint">Not legal, tax or accounting advice. Forecasts and estimates are never guaranteed.</p>
      </div>
      <Card title="Conversations" className="no-print" action={<button className="btn sm" onClick={() => setConv(null)}>New</button>}>
        <div className="stack sm">{(convs.data || []).map((c) => <a key={c.id} href="#" className="small" onClick={(e) => { e.preventDefault(); setConv(c); }}>{c.title}</a>)}{!(convs.data || []).length && <span className="small muted">None yet</span>}</div>
      </Card>
    </div>
  );
}
