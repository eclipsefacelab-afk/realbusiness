import React from 'react';
import { intel } from '../../lib/api';
import { useApp } from '../../lib/store';
import { PageHead, AsyncButton, Badge, Confidence, Notice } from '../../components/ui';
import EntityManager from '../../components/EntityManager';
import { fmtMoney } from '../../lib/format';

export default function Opportunities() {
  const { businessId, notify, business } = useApp();
  const [k, setK] = React.useState(0);
  return (
    <div className="stack lg">
      <PageHead title="Opportunities" subtitle="Ranked by estimated value, feasibility, urgency, strength of evidence and implementation cost. Values are estimates, not guaranteed results.">
        <AsyncButton className="btn" onClick={async () => { const r = await intel('monitor.run', { business_id: businessId }); notify(`${r.opportunities} opportunities evaluated`); setK(k + 1); }}>Re-scan</AsyncButton>
      </PageHead>
      <EntityManager key={k} entity="Opportunity" title="Opportunities" sort="-rank_score"
        columns={[{ key: 'title', label: 'Opportunity' }, { key: 'estimated_value', label: 'Est. value', num: true, render: (r) => r.estimated_value ? <>{fmtMoney(r.estimated_value, business?.currency)} <span className="faint small">({r.value_basis})</span></> : '—' }, { key: 'feasibility', label: 'Feasibility', type: 'select' }, { key: 'urgency', label: 'Urgency', type: 'select' }, { key: 'confidence', label: 'Evidence', render: (r) => <Confidence c={r.confidence} /> }, { key: 'rank_score', label: 'Rank', num: true }, { key: 'status', label: 'Status', type: 'select' }]}
        fields={[{ key: 'title', label: 'Title', required: true, wide: true }, { key: 'description', label: 'Description', type: 'textarea' }, { key: 'category', label: 'Category' }, { key: 'estimated_value', label: 'Estimated value', type: 'number' }, { key: 'feasibility', label: 'Feasibility', type: 'select', options: ['low', 'medium', 'high'] }, { key: 'urgency', label: 'Urgency', type: 'select', options: ['low', 'medium', 'high'] }, { key: 'implementation_cost', label: 'Implementation cost', type: 'number' }, { key: 'status', label: 'Status', type: 'select', options: ['open', 'pursuing', 'won', 'dismissed'] }]} />
    </div>
  );
}
