import React, { useState } from 'react';
import { api } from '../../lib/api';
import { useApp, useLoad } from '../../lib/store';
import { Card, Field, AsyncButton, ErrorBox, Table, Notice, Badge, Stat } from '../../components/ui';
import { fmtDateTime, labelize, fmtNum } from '../../lib/format';

export function AutomationTab() {
  const { businessId, can, notify } = useApp();
  const s = useLoad((bid) => api('settings.get', { business_id: bid }));
  const [d, setD] = useState(null); const [err, setErr] = useState(null);
  if (s.error) return <ErrorBox error={s.error} />;
  if (!s.data) return null;
  const v = d || s.data.settings, admin = can('settings', 'admin');
  const set = (k, x) => setD({ ...v, [k]: x });
  const save = async () => { setErr(null); try { const { id, business_id, created_date, updated_date, created_by, created_by_id, is_demo, ...rest } = v; await api('settings.update', { business_id: businessId, data: rest }); notify('Settings saved (recorded in audit log)'); setD(null); s.reload(); } catch (e) { setErr(e); } };
  return (
    <div className="stack">
      <Card title="AI agents"><div className="grid g3">{s.data.agents.map((a) => <label key={a.key} className="row top small" style={{ gap: 8 }}><input type="checkbox" style={{ width: 'auto', marginTop: 3 }} disabled={!admin} checked={v.agents_enabled[a.key] !== false} onChange={(e) => set('agents_enabled', { ...v.agents_enabled, [a.key]: e.target.checked })} /><span><b>{a.name}</b><br /><span className="muted">{a.focus}</span></span></label>)}</div></Card>
      <Card title="Monitoring"><div className="grid g3">
        <Field label="Scheduled analysis frequency"><select disabled={!admin} value={v.monitoring_frequency} onChange={(e) => set('monitoring_frequency', e.target.value)}><option value="hourly">Hourly</option><option value="every_6_hours">Every 6 hours</option><option value="daily">Daily</option></select></Field>
        <Field label="Event-driven checks after data changes"><select disabled={!admin} value={v.event_monitoring ? 'on' : 'off'} onChange={(e) => set('event_monitoring', e.target.value === 'on')}><option value="on">On</option><option value="off">Off</option></select></Field>
        <Field label="Notify at severity ≥"><select disabled={!admin} value={v.escalation.notify_min_severity} onChange={(e) => set('escalation', { ...v.escalation, notify_min_severity: e.target.value })}>{['informational', 'low', 'moderate', 'high', 'critical'].map((x) => <option key={x}>{x}</option>)}</select></Field>
      </div></Card>
      <Card title="Alert thresholds"><div className="grid g3">{Object.entries(v.thresholds).map(([k, x]) => <Field key={k} label={labelize(k).replace(' pct', ' (%)')}><input type="number" disabled={!admin} value={x} onChange={(e) => set('thresholds', { ...v.thresholds, [k]: Number(e.target.value) })} /></Field>)}</div></Card>
      <Card title="Approvals & workflows"><div className="grid g3">
        <Field label="Deleting records" hint="Who can delete without an approval request"><select disabled={!admin} value={v.approval_rules.delete_record} onChange={(e) => set('approval_rules', { ...v.approval_rules, delete_record: e.target.value })}><option value="owner_direct">Owner directly; others need approval</option><option value="approval">Always needs approval</option><option value="none">Anyone with delete permission</option></select></Field>
        {Object.entries(s.data.workflows).map(([k, w]) => <Field key={k} label={w.label}><select disabled={!admin || w.consequential} value={w.consequential ? 'approval_required' : v.workflow_modes[k]} onChange={(e) => set('workflow_modes', { ...v.workflow_modes, [k]: e.target.value })}><option value="approval_required">Requires approval</option><option value="automatic">Automatic</option></select></Field>)}
      </div><p className="small faint">Payments, purchases, transfers, price changes, external messages, publishing, deletions, permission changes and agreements are never performed by the AI without explicit approval.</p></Card>
      <Card title="AI models & cost controls"><div className="grid g3">
        <Field label="Model for routine tasks" hint="Blank = Base44 default"><input disabled={!admin} value={v.ai_model_routine || ''} onChange={(e) => set('ai_model_routine', e.target.value)} /></Field>
        <Field label="Model for complex analysis" hint="Blank = Base44 default"><input disabled={!admin} value={v.ai_model_complex || ''} onChange={(e) => set('ai_model_complex', e.target.value)} /></Field>
        <Field label="Fallback models (comma-separated)"><input disabled={!admin} value={(v.ai_fallback_models || []).join(', ')} onChange={(e) => set('ai_fallback_models', e.target.value.split(',').map((x) => x.trim()).filter(Boolean))} /></Field>
        <Field label="Monthly AI request cap" hint="0 = no cap"><input type="number" disabled={!admin} value={v.ai_monthly_request_cap} onChange={(e) => set('ai_monthly_request_cap', Number(e.target.value))} /></Field>
      </div><p className="small faint">Model names must be ones your Base44 plan supports; unknown models fail and fall back.</p></Card>
      <Card title="Scheduled reports"><div className="row wrap">{Object.entries(v.report_schedule).map(([k, x]) => <label key={k} className="check"><input type="checkbox" style={{ display: 'inline', width: 'auto' }} disabled={!admin} checked={!!x} onChange={(e) => set('report_schedule', { ...v.report_schedule, [k]: e.target.checked })} />{labelize(k)}</label>)}</div></Card>
      <ErrorBox error={err} />
      {admin ? <div><AsyncButton className="btn primary" onClick={save}>Save settings</AsyncButton></div> : <Notice>Only owners and administrators can change these settings.</Notice>}
    </div>
  );
}

export function UsageTab() {
  const u = useLoad((bid) => api('usage.summary', { business_id: bid }));
  if (u.error) return <ErrorBox error={u.error} />;
  const d = u.data; if (!d) return null;
  return (
    <div className="stack">
      <div className="grid g4"><Stat label={`AI requests (${d.month})`} value={d.requests} /><Stat label="Estimated tokens" value={d.est_tokens} /><Stat label="Estimated cost (USD)" value={d.est_cost_usd} format={(v) => `$${fmtNum(v, 2)}`} /><Stat label="Errors / blocked" value={`${d.errors} / ${d.blocked}`} format={(v) => v} /></div>
      <div className="grid g3">{[['by_purpose', 'By purpose'], ['by_agent', 'By agent'], ['by_model', 'By model']].map(([k, l]) => <Card key={k} title={l}><Table cols={[{ key: 'key', label: '' }, { key: 'requests', label: 'Req', num: true }, { key: 'tokens', label: 'Tokens', num: true }, { key: 'cost', label: '$', num: true }]} rows={d[k]} empty="No usage" /></Card>)}</div>
      <p className="small faint">{d.note}</p>
    </div>
  );
}

export function AuditTab() {
  const a = useLoad((bid) => api('list', { business_id: bid, entity: 'AuditLog', limit: 500 }).then((r) => r.items));
  if (a.error) return <ErrorBox error={a.error} />;
  return <Table cols={[{ key: 'created_date', label: 'When', render: (r) => fmtDateTime(r.created_date) }, { key: 'actor_email', label: 'Who', render: (r) => <>{r.actor_email || 'system'} <Badge kind={r.actor_type === 'ai' ? 'opportunity' : 'neutral'}>{r.actor_type}</Badge></> }, { key: 'action', label: 'Action' }, { key: 'entity', label: 'Record' }, { key: 'summary', label: 'Details', render: (r) => <span className="small">{r.summary}</span> }]} rows={a.data || []} empty="No audit entries" />;
}

export function MemoryTab() {
  const { businessId, role, notify } = useApp();
  const mem = useLoad((bid) => api('list', { business_id: bid, entity: 'ContextMemory', sort: '-as_of_date', limit: 300 }).then((r) => r.items));
  const op = async (m, o) => { const content = o === 'correct' ? window.prompt('Corrected fact:', m.content) : null; if (o === 'correct' && !content) return; await api('memory.correct', { business_id: businessId, id: m.id, op: o, content }); notify('Memory updated'); mem.reload(); };
  return (
    <div className="stack">
      <Notice>What the AI remembers about this business (decisions, outcomes, objectives). Facts are dated; old facts are treated as historical. Owners and admins can correct or retract them.</Notice>
      <Table cols={[{ key: 'kind', label: 'Type', render: (r) => labelize(r.kind) }, { key: 'content', label: 'Fact', render: (r) => <span className="small">{r.content}</span> }, { key: 'as_of_date', label: 'As of' }, { key: 'status', label: 'Status', render: (r) => <Badge kind={r.status === 'current' ? 'positive' : 'low'}>{r.status}</Badge> }, { key: 'a', label: '', render: (r) => ['owner', 'admin'].includes(role) && r.status === 'current' && <div className="row" style={{ gap: 4 }}><button className="btn sm" onClick={() => op(r, 'correct')}>Correct</button><button className="btn sm" onClick={() => op(r, 'historical')}>Mark historical</button><button className="btn sm danger" onClick={() => op(r, 'retract')}>Retract</button></div> }]} rows={mem.data || []} empty="Nothing remembered yet. Record decision outcomes and recommendation results to build memory." />
    </div>
  );
}
