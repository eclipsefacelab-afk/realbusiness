import React, { useState } from 'react';
import { api, intel } from '../../lib/api';
import { useApp, useLoad } from '../../lib/store';
import { Link } from '../../lib/router';
import { PageHead, Card, AsyncButton, Badge, Table, ErrorBox, Notice } from '../../components/ui';
import { fmtDateTime, labelize } from '../../lib/format';

const WF = [['low_stock_purchase', 'Low-stock purchase recommendations', 'Drafts purchase orders from sales rate, lead time and target cover. Placing them needs approval.'], ['production_recommendation', 'Production recommendations', 'Creates planned production runs you can edit or cancel.'], ['customer_followup', 'Customer follow-up reminders', 'Creates follow-up tasks and a message draft for consenting contacts. Sending needs approval.'], ['marketing_campaign_draft', 'Marketing campaign draft', 'Drafts a trackable campaign. Publishing needs approval.'], ['sales_report', 'Sales performance report', 'Generates a report.'], ['management_report', 'Management briefing', 'Generates a briefing.']];
export default function Workflows() {
  const { businessId, notify } = useApp();
  const runs = useLoad((bid) => api('list', { business_id: bid, entity: 'WorkflowRun', limit: 100 }).then((r) => r.items.filter((x) => x.workflow_key !== 'scheduled_monitoring')));
  const [err, setErr] = useState(null);
  const run = async (k) => { setErr(null); try { const r = await intel('workflow.run', { business_id: businessId, key: k }); notify(r.duplicate ? r.message : r.approval ? 'Prepared — waiting for approval' : 'Completed'); runs.reload(); } catch (e) { setErr(e); } };
  return (
    <div className="stack lg">
      <PageHead title="AI Workflows" subtitle="The AI prepares the work; people approve anything consequential. Each workflow runs at most once per day (duplicate prevention) and every run is logged." />
      <ErrorBox error={err} />
      <div className="grid g3">{WF.map(([k, l, d]) => <Card key={k} title={l}><p className="small muted">{d}</p><AsyncButton className="btn sm primary" onClick={() => run(k)}>Run now</AsyncButton></Card>)}</div>
      <Notice>Configure which workflows run automatically in <Link to="/settings">Settings → AI & automation</Link>. Workflows that buy, send or publish always require approval.</Notice>
      <Card title="Run history"><Table cols={[{ key: 'workflow_key', label: 'Workflow', render: (r) => labelize(r.workflow_key) }, { key: 'status', label: 'Status', render: (r) => <Badge kind={r.status === 'completed' ? 'positive' : r.status === 'failed' ? 'critical' : 'medium'}>{labelize(r.status)}</Badge> }, { key: 'mode', label: 'Mode', render: (r) => labelize(r.mode) }, { key: 'started_by', label: 'By' }, { key: 'created_date', label: 'When', render: (r) => fmtDateTime(r.created_date) }, { key: 'error', label: 'Result', render: (r) => <span className="small">{r.error || r.output?.message || r.output?.note || (r.output?.purchase_orders ? `${r.output.purchase_orders.length} draft PO(s)` : '')}</span> }]} rows={runs.data || []} empty="No workflow runs yet" /></Card>
    </div>
  );
}
