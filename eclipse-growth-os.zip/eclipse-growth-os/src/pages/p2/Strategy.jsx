import React, { useState } from 'react';
import { intel } from '../../lib/api';
import { useApp } from '../../lib/store';
import { PageHead, Card, AsyncButton, ErrorBox, Field } from '../../components/ui';
import Markdown from '../../components/Markdown';

const TOPICS = ['revenue growth', 'marketing', 'sales improvement', 'product development', 'manufacturing improvement', 'cost reduction', 'market expansion', 'customer acquisition'];
export default function Strategy() {
  const { businessId } = useApp();
  const [topic, setTopic] = useState(TOPICS[0]); const [r, setR] = useState(null); const [err, setErr] = useState(null);
  return (
    <div className="stack lg">
      <PageHead title="AI Strategy Generator" subtitle="Complete strategies grounded in your actual data, resources, cash, goals and constraints. Saved to Reports." />
      <Card><div className="row wrap"><Field label="Strategy"><select value={topic} onChange={(e) => setTopic(e.target.value)}>{TOPICS.map((t) => <option key={t}>{t}</option>)}</select></Field><div style={{ alignSelf: 'end' }}><AsyncButton className="btn primary" onClick={async () => { setErr(null); try { setR((await intel('strategy.generate', { business_id: businessId, topic })).report); } catch (e) { setErr(e); } }}>Generate strategy</AsyncButton></div></div></Card>
      <ErrorBox error={err} />
      {r && <Card title={r.title} action={<button className="btn sm" onClick={() => window.print()}>Print / PDF</button>}><Markdown text={r.content_md} /></Card>}
    </div>
  );
}
