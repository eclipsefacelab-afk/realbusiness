import React from 'react';
import { intel } from '../../lib/api';
import { useApp, useLoad } from '../../lib/store';
import { Link } from '../../lib/router';
import { PageHead, Card, ErrorBox, Skeleton, Notice, Badge, Table } from '../../components/ui';
import { fmtMoney, fmtPct } from '../../lib/format';

export default function Expansion() {
  const { business } = useApp();
  const e = useLoad((bid) => intel('expansion.assess', { business_id: bid }));
  if (e.error) return <ErrorBox error={e.error} retry={e.reload} />;
  const d = e.data;
  const kind = { not_yet: 'warn', insufficient_data: 'warn', conditional: 'warn', ready_to_evaluate: 'ok' };
  return (
    <div className="stack lg">
      <PageHead title="Expansion Planner" subtitle="Before any new product line, location, province, country, wholesale or distribution push, the platform checks business health, cash, demand, operational and management capacity. It will say 'not yet' when the evidence doesn't support expanding." />
      {!d ? <Skeleton /> : <>
        <Notice kind={kind[d.verdict]}><b>{d.message}</b></Notice>
        <Card title="Readiness checks">{d.checks.map((c) => <div key={c.key} className="row between small" style={{ padding: '6px 0', borderBottom: '1px solid var(--border)' }}><span>{c.pass === null ? '❔' : c.pass ? '✅' : '❌'} {c.label}</span><span className="muted">{c.detail}</span></div>)}</Card>
        <Card title="Current markets / locations (90-day sales)"><Table cols={[{ key: 'name', label: 'Location' }, { key: 'revenue', label: 'Revenue', num: true, render: (r) => fmtMoney(r.revenue, business?.currency) }, { key: 'share_pct', label: 'Share', num: true, render: (r) => fmtPct(r.share_pct) }]} rows={d.locations} empty="Link sales to locations to compare markets (e.g. Canada vs Jamaica)." /></Card>
        <Card title="Model a specific option"><p className="small">Use <Link to="/scenarios">Scenarios</Link> → "Open a location" or "Enter a new province/country" with your own rent, staff, setup and expected-sales assumptions. Results show cash needed, break-even and cannibalisation. The platform never invents population, competition or market statistics — enter figures from sources you trust, with their source and date.</p></Card>
        <p className="small faint">{d.note}</p>
      </>}
    </div>
  );
}
