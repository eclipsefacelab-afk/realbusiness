import React, { useState } from 'react';
import { api, intel } from '../../lib/api';
import { useApp, useLoad } from '../../lib/store';
import { PageHead, Card, Badge, Tabs, AsyncButton, Empty, Modal, Field, ErrorBox } from '../../components/ui';
import { fmtDateTime, labelize } from '../../lib/format';

const SEVK = { critical: 'critical', high: 'high', moderate: 'medium', low: 'low', informational: 'neutral' };
export default function Alerts() {
  const { businessId, can, notify } = useApp();
  const [tab, setTab] = useState('open');
  const list = useLoad((bid) => api('list', { business_id: bid, entity: 'Alert', limit: 1000 }).then((r) => r.items));
  const [sel, setSel] = useState(null); const [text, setText] = useState(''); const [err, setErr] = useState(null);
  const op = async (a, o, extra = {}) => { setErr(null); try { await api('alert.update', { business_id: businessId, id: a.id, op: o, ...extra }); notify(`Alert ${o === 'annotate' ? 'note added' : o + 'd'}`); setSel(null); setText(''); list.reload(); } catch (e) { setErr(e); } };
  const rows = (list.data || []).filter((a) => (tab === 'open' ? a.status !== 'closed' : a.status === 'closed')).sort((a, b) => ['critical', 'high', 'moderate', 'low', 'informational'].indexOf(a.severity) - ['critical', 'high', 'moderate', 'low', 'informational'].indexOf(b.severity));
  return (
    <div className="stack lg">
      <PageHead title="Alerts" subtitle="Exceptions detected automatically after data changes (event-driven) and on the monitoring schedule. Repeated detections of an unchanged issue update the same alert instead of creating new ones.">
        <AsyncButton className="btn" onClick={async () => { const r = await intel('monitor.run', { business_id: businessId }); notify(`Checked: ${r.created} new, ${r.escalated} escalated, ${r.resolved} resolved`); list.reload(); }}>Run checks now</AsyncButton>
      </PageHead>
      <Tabs tabs={[['open', 'Open'], ['closed', 'History']]} value={tab} onChange={setTab} />
      <ErrorBox error={err} />
      {rows.length ? rows.map((a) => (
        <div key={a.id} className={`rec ${a.severity === 'critical' ? 'critical' : a.severity === 'high' ? 'high' : ''}`}>
          <div className="row between top"><div><div className="row wrap" style={{ gap: 6 }}><Badge kind={SEVK[a.severity]}>{labelize(a.severity)}</Badge><Badge kind="neutral">{a.business_area}</Badge><Badge kind="neutral">{labelize(a.status)}</Badge>{a.occurrences > 1 && <span className="small faint">seen {a.occurrences}×</span>}</div><h3 style={{ marginTop: 4 }}>{a.title}</h3></div><span className="small muted">{fmtDateTime(a.when_happened || a.created_date)}</span></div>
          <dl><dt>What happened</dt><dd>{a.what_happened}</dd><dt>Why it matters</dt><dd>{a.why_it_matters}</dd><dt>Potential impact</dt><dd>{a.potential_impact}</dd><dt>Recommended action</dt><dd><b>{a.recommended_action}</b></dd><dt>Supporting records</dt><dd className="small">{(a.supporting_records || []).map((r) => `${r.entity}${r.id ? ' ' + r.id.slice(-6) : ''}${r.count ? ` ×${r.count}` : ''}`).join(', ') || '—'}</dd>{a.assigned_to && <><dt>Assigned to</dt><dd>{a.assigned_to}</dd></>}{(a.notes || []).length > 0 && <><dt>Notes</dt><dd>{a.notes.map((n, i) => <div key={i} className="small">{n.text} <span className="faint">— {n.by}, {fmtDateTime(n.at)}</span></div>)}</dd></>}{a.resolution && <><dt>Resolution</dt><dd>{a.resolution}</dd></>}</dl>
          {can('alerts', 'write') && a.status !== 'closed' && <div className="row wrap" style={{ marginTop: 10, gap: 6 }}>{a.status === 'open' && <AsyncButton className="btn sm" onClick={() => op(a, 'acknowledge')}>Acknowledge</AsyncButton>}<button className="btn sm" onClick={() => setSel({ a, mode: 'assign' })}>Assign</button><button className="btn sm" onClick={() => setSel({ a, mode: 'annotate' })}>Add note</button><button className="btn sm primary" onClick={() => setSel({ a, mode: 'close' })}>Close</button></div>}
        </div>)) : <Empty title={tab === 'open' ? 'No open alerts' : 'No closed alerts'}>{tab === 'open' ? 'Nothing unusual detected. Checks run after data changes and on schedule.' : ''}</Empty>}
      {sel && <Modal title={{ assign: 'Assign alert', annotate: 'Add note', close: 'Close alert' }[sel.mode]} onClose={() => setSel(null)} footer={<AsyncButton className="btn primary" onClick={() => op(sel.a, sel.mode, { assigned_to: text, text, resolution: text })}>Save</AsyncButton>}><Field label={{ assign: 'Assign to (person or department)', annotate: 'Note', close: 'Resolution' }[sel.mode]}><textarea value={text} onChange={(e) => setText(e.target.value)} /></Field></Modal>}
    </div>
  );
}
