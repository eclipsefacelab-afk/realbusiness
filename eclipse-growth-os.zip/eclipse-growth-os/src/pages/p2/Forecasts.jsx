import React from 'react';
import { intel } from '../../lib/api';
import { useApp, useLoad } from '../../lib/store';
import { PageHead, Card, ErrorBox, Skeleton, Table, Badge, Notice, AsyncButton, Confidence } from '../../components/ui';
import { LineChart } from '../../components/charts';
import { fmtMoney, fmtNum, fmtDate } from '../../lib/format';

function FChart({ f, money, cur }) {
  if (!f) return null;
  if (!f.ok) return <p className="muted small">{f.reason}</p>;
  return <>
    <LineChart data={f.expected.map((x, i) => ({ period: x.period, conservative: f.conservative[i].value, expected: x.value, aggressive: f.aggressive[i].value }))} series={[{ key: 'conservative', label: 'Conservative', color: 'var(--faint)', dashed: true }, { key: 'expected', label: 'Expected', color: 'var(--brand-2)', dashed: true }, { key: 'aggressive', label: 'Aggressive', color: 'var(--accent)', dashed: true }]} format={(v) => (money ? fmtMoney(v, cur) : fmtNum(v))} />
    <div className="row wrap small"><Badge kind="neutral">FORECAST</Badge><Confidence c={f.confidence} />{f.method && <span className="muted">{f.method}</span>}</div>
    <ul className="small muted">{(f.assumptions || []).map((a, i) => <li key={i}>{a}</li>)}</ul>
    {f.warning && <Notice kind="err">{f.warning}</Notice>}
  </>;
}
export default function Forecasts() {
  const { business, businessId, notify } = useApp();
  const cur = business?.currency;
  const f = useLoad((bid) => intel('forecast', { business_id: bid, horizon: 6 }));
  if (f.error) return <ErrorBox error={f.error} retry={f.reload} />;
  const d = f.data;
  return (
    <div className="stack lg">
      <PageHead title="Forecasts" subtitle="Projections of revenue, expenses, cash, customers and product demand with conservative / expected / aggressive ranges. Forecasts are never guaranteed and always show their assumptions.">
        <AsyncButton className="btn" onClick={async () => { await intel('forecast', { business_id: businessId, save: true }); notify('Forecast saved — it will be compared with actual results as months complete.'); f.reload(); }}>Save this forecast</AsyncButton>
      </PageHead>
      {!d ? <Skeleton n={4} /> : <>
        <div className="grid g2">
          <Card title="Revenue (monthly)"><FChart f={d.revenue} money cur={cur} /></Card>
          <Card title="Cash outlook"><FChart f={d.cash} money cur={cur} /></Card>
          <Card title="Expenses (monthly)"><FChart f={d.expenses} money cur={cur} /></Card>
          <Card title="New customers (monthly)"><FChart f={d.customers} /></Card>
        </div>
        <Card title="Product demand & recommended purchase / production quantities">
          <Table cols={[{ key: 'name', label: 'Item' }, { key: 'velocity_per_day', label: 'Sells/day', num: true }, { key: 'demand_30d', label: 'Demand 30d', num: true }, { key: 'demand_90d', label: 'Demand 90d', num: true }, { key: 'on_hand', label: 'On hand', num: true }, { key: 'recommended_order_qty', label: 'Recommended qty', num: true, render: (r) => r.recommended_order_qty ? <b>{r.recommended_order_qty}</b> : '—' }, { key: 'reorder_by', label: 'Order by', render: (r) => fmtDate(r.reorder_by) }, { key: 'assumptions', label: 'Assumptions', render: (r) => <span className="small muted">{r.assumptions}</span> }]} rows={d.demand} empty="No inventory records" />
        </Card>
        {d.customer_behaviour && <Card title="Customer behaviour (predictions)">
          <div className="row wrap"><Badge kind="opportunity">{d.customer_behaviour.likely_to_buy_soon} likely to buy again soon</Badge><Badge kind="high">{d.customer_behaviour.declining} with declining activity</Badge></div>
          {d.customer_behaviour.combos.length > 0 && <><h3 style={{ marginTop: 12 }}>Frequently bought together</h3><ul className="small">{d.customer_behaviour.combos.map((c, i) => <li key={i}>{c.items.join(' + ')} — {c.orders} orders</li>)}</ul></>}
          <p className="small faint">{d.customer_behaviour.note}</p>
        </Card>}
        {d.accuracy?.length > 0 && <Card title="Forecast vs actual">{d.accuracy.map((a, i) => <div key={i}><div className="small muted">Saved {fmtDate(a.generated_at)}</div><Table cols={[{ key: 'period', label: 'Month' }, { key: 'forecast', label: 'Forecast', num: true }, { key: 'actual', label: 'Actual', num: true }, { key: 'error_pct', label: 'Error %', num: true }]} rows={a.comparison} /></div>)}</Card>}
      </>}
    </div>
  );
}
