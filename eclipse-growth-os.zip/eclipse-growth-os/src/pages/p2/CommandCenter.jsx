import React, { useState } from 'react';
import { intel } from '../../lib/api';
import { useApp, useLoad } from '../../lib/store';
import { Link } from '../../lib/router';
import { PageHead, Card, ErrorBox, Skeleton, Badge, Basis, Notice } from '../../components/ui';
import { ScoreRing, LineChart } from '../../components/charts';
import { AnswerView } from '../Advisor';
import { fmtMoney, fmtDate, labelize } from '../../lib/format';

const SEVK = { critical: 'critical', high: 'high', moderate: 'medium', low: 'low', informational: 'neutral' };
export default function CommandCenter() {
  const { businessId, business } = useApp();
  const c = useLoad((bid) => intel('command', { business_id: bid }));
  const [q, setQ] = useState(''); const [ans, setAns] = useState(null); const [busy, setBusy] = useState(false); const [err, setErr] = useState(null);
  const ask = async (e) => { e.preventDefault(); if (!q.trim()) return; setBusy(true); setErr(null); try { const r = await intel('advisor.ask', { business_id: businessId, question: q }); if (r.ok) setAns(r.answer); else setErr(new Error(r.error)); } catch (x) { setErr(x); } finally { setBusy(false); } };
  if (c.error) return <ErrorBox error={c.error} retry={c.reload} />;
  const d = c.data, cur = business?.currency;
  const rf = d?.forecast?.revenue;
  return (
    <div className="stack lg">
      <PageHead title="AI Business Command Center" subtitle="Your specialist AI team in one place: health, alerts, recommendations, opportunities, forecasts and outstanding actions." />
      <Card className="hero">
        <form onSubmit={ask} className="row"><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ask your AI team… e.g. Which products are costing me money?" style={{ background: '#fff' }} aria-label="Ask the AI team" /><button className="btn accent" disabled={busy}>{busy ? 'Thinking…' : 'Ask'}</button></form>
        <div className="small muted" style={{ marginTop: 6 }}>The central engine routes your question to the right specialists (finance, sales, marketing, manufacturing, inventory, customers, growth, risk) and combines their findings.</div>
      </Card>
      <ErrorBox error={err} />
      {ans && <Card title="Coordinated answer"><AnswerView s={ans} />{ans.blocked_agents?.length > 0 && <p className="small faint">Not consulted: {ans.blocked_agents.map((b) => `${b.key} (${b.reason})`).join(', ')}</p>}</Card>}
      {!d ? <Skeleton n={6} /> : <>
        <div className="grid g4">
          <Card><div className="row"><ScoreRing score={d.health.overall_score} size={64} /><div><b>{d.stage.label}</b><div className="small muted">Health · {labelize(d.health.overall_basis)}</div></div></div></Card>
          <Card title="Revenue (30d)"><b style={{ fontSize: 22 }}>{fmtMoney(d.snapshot.revenue_30d.value, cur)}</b> <Basis b={d.snapshot.revenue_30d.basis} /></Card>
          <Card title="Pending approvals">{d.approvals_pending === null ? <span className="muted small">n/a</span> : <Link to="/approvals"><b style={{ fontSize: 22 }}>{d.approvals_pending}</b></Link>}</Card>
          <Card title="Open alerts"><Link to="/alerts"><b style={{ fontSize: 22 }}>{d.alerts.length}</b></Link> <span className="small muted">{d.alerts.filter((a) => a.severity === 'critical').length} critical</span></Card>
        </div>
        {d.financial_warnings?.length > 0 && <Notice kind="err">{d.financial_warnings.join(' · ')}</Notice>}
        <div className="grid g3">
          <Card title="Important alerts" action={<Link to="/alerts" className="small">All →</Link>}>{d.alerts.length ? d.alerts.slice(0, 6).map((a) => <div key={a.id} className="small" style={{ marginBottom: 6 }}><Badge kind={SEVK[a.severity]}>{a.severity}</Badge> {a.title}</div>) : <span className="muted small">No open alerts.</span>}</Card>
          <Card title="AI recommendations" action={<Link to="/next" className="small">All →</Link>}>{d.recommendations.map((r) => <div key={r.id} className="small" style={{ marginBottom: 6 }}><Badge kind={r.finding_level}>{r.priority}</Badge> {r.title}</div>)}</Card>
          <Card title="Growth opportunities" action={<Link to="/opportunities" className="small">All →</Link>}>{d.opportunities.length ? d.opportunities.slice(0, 5).map((o) => <div key={o.id} className="small" style={{ marginBottom: 6 }}>✦ {o.title}{o.estimated_value ? <span className="muted"> · ≈{fmtMoney(o.estimated_value, cur)} (estimate)</span> : ''}</div>) : <span className="muted small">Run monitoring to detect opportunities.</span>}</Card>
        </div>
        <div className="grid g3">
          <Card title="Revenue forecast (not guaranteed)" className="span2" action={<Link to="/forecasts" className="small">Forecasts →</Link>}>{rf?.ok ? <LineChart data={rf.expected.map((x, i) => ({ period: x.period, expected: x.value, conservative: rf.conservative[i].value, aggressive: rf.aggressive[i].value }))} series={[{ key: 'conservative', label: 'Conservative', color: 'var(--faint)', dashed: true }, { key: 'expected', label: 'Expected', color: 'var(--brand-2)', dashed: true }, { key: 'aggressive', label: 'Aggressive', color: 'var(--accent)', dashed: true }]} format={(v) => fmtMoney(v, cur)} /> : <p className="muted small">{rf?.reason}</p>}</Card>
          <Card title="Sales intelligence"><div className="small"><b>Best sellers:</b> {d.sales_intel.best.join(', ') || '—'}</div><div className="small" style={{ marginTop: 6 }}><b>Declining:</b> {d.sales_intel.declining.join(', ') || '—'}</div></Card>
        </div>
        <div className="grid g2">
          <Card title="Outstanding management actions" action={<Link to="/plan" className="small">Plan →</Link>}>{d.outstanding_actions.length ? d.outstanding_actions.map((t) => <div key={t.id} className="row between small"><span>{t.title}</span><span className="muted">{fmtDate(t.due_date)}</span></div>) : <span className="muted small">None.</span>}</Card>
          <Card title="Recent AI team activity">{d.recent_agent_runs.length ? d.recent_agent_runs.map((r, i) => <div key={i} className="small" style={{ marginBottom: 6 }}><b>{r.question}</b><div className="muted">{(r.agents || []).join(', ')} · {r.status}</div></div>) : <span className="muted small">No questions yet.</span>}</Card>
        </div>
      </>}
    </div>
  );
}
