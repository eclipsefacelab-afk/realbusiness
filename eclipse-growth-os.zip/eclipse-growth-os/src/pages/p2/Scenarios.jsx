import React, { useEffect, useState } from 'react';
import { api, intel } from '../../lib/api';
import { useApp, useLoad } from '../../lib/store';
import { PageHead, Card, Field, AsyncButton, ErrorBox, Notice, Table, Badge } from '../../components/ui';
import { fmtMoney, fmtDate } from '../../lib/format';

export default function Scenarios() {
  const { businessId, business, notify, can } = useApp();
  const cur = business?.currency;
  const [kinds, setKinds] = useState(null); const [kind, setKind] = useState('sales_change'); const [params, setParams] = useState({}); const [res, setRes] = useState(null); const [err, setErr] = useState(null); const [compare, setCompare] = useState([]);
  const saved = useLoad((bid) => api('list', { business_id: bid, entity: 'Scenario', limit: 100 }).then((r) => r.items));
  useEffect(() => { intel('scenario.kinds', { business_id: businessId }).then((r) => setKinds(r.kinds)).catch(setErr); }, [businessId]);
  useEffect(() => { if (kinds) setParams(Object.fromEntries(kinds[kind].params.map(([k, , v]) => [k, v]))); setRes(null); }, [kind, kinds]);
  const run = async (save) => { setErr(null); try { const r = await intel('scenario.run', { business_id: businessId, kind, params, save, name: kinds[kind].label }); if (!r.ok) setErr(new Error(r.reason)); else { setRes(r); if (save) { notify('Scenario saved'); saved.reload(); } } } catch (e) { setErr(e); } };
  const row = (r, label) => ({ label, revenue: r.revenue, gross_profit: r.gross_profit, opex: r.opex, net: r.net });
  return (
    <div className="stack lg">
      <PageHead title="Scenario Planning" subtitle="Explore 'what if' questions using your own numbers. Every result is an ESTIMATE — change the assumptions to match what you know." />
      <Card title="1. Choose a question">
        <div className="grid g3">
          <Field label="Scenario"><select value={kind} onChange={(e) => setKind(e.target.value)}>{kinds && Object.entries(kinds).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select></Field>
          {kinds?.[kind].params.map(([k, l]) => <Field key={k} label={l}><input type="number" step="any" value={params[k] ?? ''} onChange={(e) => setParams({ ...params, [k]: Number(e.target.value) })} /></Field>)}
        </div>
        <div className="row" style={{ marginTop: 10 }}><AsyncButton className="btn primary" onClick={() => run(false)}>Run scenario</AsyncButton>{can('strategy', 'write') && <AsyncButton className="btn" onClick={() => run(true)}>Run & save</AsyncButton>}</div>
      </Card>
      <ErrorBox error={err} />
      {res && <Card title="2. Estimated effect (monthly, once ramped up)" action={<Badge kind="medium">{res.label}</Badge>}>
        <Table cols={[{ key: 'label', label: '' }, { key: 'revenue', label: 'Revenue', num: true, render: (r) => fmtMoney(r.revenue, cur) }, { key: 'gross_profit', label: 'Gross profit', num: true, render: (r) => fmtMoney(r.gross_profit, cur) }, { key: 'opex', label: 'Running costs', num: true, render: (r) => fmtMoney(r.opex, cur) }, { key: 'net', label: 'Profit', num: true, render: (r) => <b>{fmtMoney(r.net, cur)}</b> }]} rows={[row(res.baseline, 'Today (baseline)'), row(res.scenario, 'Scenario')]} />
        <div className="grid g3" style={{ marginTop: 12 }}><Card className="flat tight" title="One-time cost">{fmtMoney(res.one_time_cost, cur)}</Card><Card className="flat tight" title="Cash needed">{fmtMoney(res.cash_requirement, cur)}</Card><Card className="flat tight" title="Break-even">{res.break_even_note}</Card></div>
        <h3 style={{ marginTop: 12 }}>Assumptions</h3><ul className="small">{res.assumptions.map((a, i) => <li key={i}>{a}</li>)}</ul>
        {res.risks.length > 0 && <><h3>Risks</h3><ul className="small">{res.risks.map((a, i) => <li key={i}>{a}</li>)}</ul></>}
      </Card>}
      <Card title="Saved scenarios — compare">
        <Table cols={[{ key: 'c', label: '', render: (s) => <input type="checkbox" style={{ width: 'auto' }} checked={compare.includes(s.id)} onChange={() => setCompare(compare.includes(s.id) ? compare.filter((x) => x !== s.id) : [...compare, s.id])} aria-label="Compare" /> }, { key: 'name', label: 'Scenario' }, { key: 'created_date', label: 'Saved', render: (s) => fmtDate(s.created_date) }, { key: 'net', label: 'Profit change / month', num: true, render: (s) => fmtMoney(s.results?.change?.net_monthly, cur) }, { key: 'cash', label: 'Cash needed', num: true, render: (s) => fmtMoney(s.results?.cash_requirement, cur) }, { key: 'be', label: 'Break-even', render: (s) => s.results?.break_even_month ? `${s.results.break_even_month} mo` : '—' }]} rows={saved.data || []} empty="No saved scenarios" />
        {compare.length > 1 && <Notice>Comparing {compare.length} scenarios: best monthly profit change is "{(saved.data || []).filter((s) => compare.includes(s.id)).sort((a, b) => (b.results?.change?.net_monthly || 0) - (a.results?.change?.net_monthly || 0))[0]?.name}". All figures are estimates.</Notice>}
      </Card>
    </div>
  );
}
