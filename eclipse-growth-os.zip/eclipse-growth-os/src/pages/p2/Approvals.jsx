import React, { useState } from 'react';
import { api } from '../../lib/api';
import { useApp, useLoad } from '../../lib/store';
import { PageHead, Tabs, Badge, AsyncButton, Empty, Notice, ErrorBox } from '../../components/ui';
import { fmtDateTime, labelize } from '../../lib/format';

export default function Approvals() {
  const { businessId, can, notify } = useApp();
  const [tab, setTab] = useState('pending');
  const list = useLoad((bid) => api('list', { business_id: bid, entity: 'ApprovalRequest', limit: 500 }).then((r) => r.items));
  const [err, setErr] = useState(null);
  const decide = async (r, decision) => { setErr(null); try { const out = await api('approval.decide', { business_id: businessId, id: r.id, decision }); notify(decision === 'approve' ? (out.result || 'Approved') : 'Rejected'); list.reload(); } catch (e) { setErr(e); } };
  const rows = (list.data || []).filter((r) => (tab === 'pending' ? r.status === 'pending' : r.status !== 'pending'));
  return (
    <div className="stack lg">
      <PageHead title="Approvals" subtitle="The AI never pays, purchases, transfers money, changes prices, sends external messages, publishes marketing, deletes records, changes permissions or signs agreements on its own. Those actions wait here for an authorised person." />
      <Tabs tabs={[['pending', 'Pending'], ['history', 'History']]} value={tab} onChange={setTab} />
      <ErrorBox error={err} />
      {rows.length ? rows.map((r) => (
        <div key={r.id} className="rec">
          <div className="row between top"><div><div className="row wrap" style={{ gap: 6 }}><Badge kind="medium">{labelize(r.action_type)}</Badge><Badge kind={r.status === 'pending' ? 'neutral' : ['executed', 'approved'].includes(r.status) ? 'positive' : 'critical'}>{labelize(r.status)}</Badge><span className="small faint">requested by {r.requested_by} ({r.requested_by_type})</span></div><h3 style={{ marginTop: 4 }}>{r.title}</h3></div><span className="small muted">{fmtDateTime(r.created_date)}</span></div>
          <p className="small" style={{ marginTop: 6 }}>{r.description}</p>
          {r.payload?.draft && <div className="card flat tight small" style={{ whiteSpace: 'pre-wrap' }}><b>{r.payload.draft.subject}</b>{'\n'}{r.payload.draft.body}</div>}
          {r.payload?.message && <div className="card flat tight small" style={{ whiteSpace: 'pre-wrap' }}><b>{r.payload.name}</b> — {r.payload.audience}{'\n'}{r.payload.message}{'\n'}<i>Measure: {r.payload.measurement}</i></div>}
          {r.decided_by && <p className="small muted">Decided by {r.decided_by} on {fmtDateTime(r.decided_at)}. {r.execution_result} {r.failure_reason && <span className="delta down">Failed: {r.failure_reason}</span>}</p>}
          {r.status === 'pending' && can('approvals', 'approve') && <div className="row" style={{ gap: 6, marginTop: 8 }}><AsyncButton className="btn primary sm" onClick={() => decide(r, 'approve')}>Approve</AsyncButton><AsyncButton className="btn sm" onClick={() => decide(r, 'reject')}>Reject</AsyncButton></div>}
        </div>)) : <Empty title={tab === 'pending' ? 'Nothing waiting for approval' : 'No decisions yet'} />}
      {!can('approvals', 'approve') && <Notice>Your role can view but not approve requests.</Notice>}
    </div>
  );
}
