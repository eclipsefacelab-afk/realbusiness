import { AutomationTab, UsageTab, AuditTab, MemoryTab } from './p2/AdminTabs';
export const SETTINGS_TABS = [
  { key: 'automation', label: 'AI & automation', component: AutomationTab, perm: ['settings', 'read'] },
  { key: 'usage', label: 'AI usage & cost', component: UsageTab, perm: ['settings', 'read'] },
  { key: 'memory', label: 'AI memory', component: MemoryTab, perm: ['strategy', 'read'] },
  { key: 'audit', label: 'Audit log', component: AuditTab, perm: ['audit', 'read'] },
];
