// Report generators available in the UI. The Prompt 2 layer adds more in reports.kinds.p2.js.
import { P2_REPORT_KINDS } from './reports.kinds.p2';
export const REPORT_KINDS = [
  { kind: 'weekly_review', label: 'Weekly Business Review', fn: 'intelligence', action: 'review.weekly', perm: ['reports', 'write'] },
  { kind: 'monthly_review', label: 'Monthly Business Review', fn: 'intelligence', action: 'review.monthly', perm: ['finance', 'read'] },
  { kind: 'annual_plan', label: 'Annual Business Plan', fn: 'intelligence', action: 'plan.annual', perm: ['strategy', 'write'] },
  ...P2_REPORT_KINDS,
];
