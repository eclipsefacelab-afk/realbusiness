import React, { useState } from 'react';
import { intel } from '../lib/api';
import { useApp } from '../lib/store';
import { AsyncButton, Modal } from '../components/ui';

export function CompetitorSummary({ r, reload }) {
  const { businessId, can } = useApp();
  const [open, setOpen] = useState(false);
  if (!can('competitors', 'write')) return null;
  return <>
    <AsyncButton className="btn sm" onClick={async () => { await intel('competitor.summary', { business_id: businessId, id: r.id }); reload(); setOpen(true); }}>AI summary</AsyncButton>
    {open && <Modal title={`AI interpretation — ${r.name}`} onClose={() => setOpen(false)}><p className="small faint">Generated only from your recorded facts; verified and unverified facts are counted separately.</p><p style={{ whiteSpace: 'pre-wrap' }}>{r.ai_summary || 'Refresh to see the latest summary.'}</p></Modal>}
  </>;
}
