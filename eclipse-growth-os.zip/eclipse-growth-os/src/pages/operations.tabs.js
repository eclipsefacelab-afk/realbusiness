import { Suppliers, Production, PurchaseOrders, Invoices } from './p2/OpsTabs';
export const OPERATIONS_TABS = [
  { key: 'suppliers', label: 'Suppliers', component: Suppliers },
  { key: 'production', label: 'Production', component: Production },
  { key: 'pos', label: 'Purchase orders', component: PurchaseOrders },
  { key: 'invoices', label: 'Invoices / receivables', component: Invoices, perm: ['finance', 'read'] },
];
