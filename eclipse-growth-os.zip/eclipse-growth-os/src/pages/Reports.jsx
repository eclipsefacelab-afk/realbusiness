import React, { useState } from 'react';
import { api, call } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { PageHead, Card, Table, Modal, AsyncButton, Badge, ErrorBox, Notice } from '../components/ui';
import Markdown from '../components/Markdown';
import { fmtDateTime, labelize, download, toCSV } from '../lib/format';
import { REPORT_KINDS } from './reports.kinds';

export default function Reports() {
  const { businessId, can, notify, business } = useApp();
  const list = useLoad((bid) => api('list', { business_id: bid, entity: 'Report', sort: '-generated_at', limit: 300 }).then((r) => r.items));
  const [view, setView] = useState(null);
  const [err, setErr] = useState(null);
  const gen = async (k) => { setErr(null); try { const r = await call(k.fn, k.action, { business_id: businessId, ...(k.args || {}) }); notify(`${k.label} generated`); list.reload(); if (r.report) setView(r.report); } catch (e) { setErr(e); } };
  return (
    <div className="stack lg">
      <PageHead title="Reports" subtitle="Professional reports generated from your data. Each report states its period, generation date and data limitations. Estimates are never presented as audited financial statements." />
      <Card title="Generate a report">
        <div className="row wrap">{REPORT_KINDS.filter((k) => can(...k.perm)).map((k) => <AsyncButton key={k.kind} className="btn" onClick={() => gen(k)}>{k.label}</AsyncButton>)}</div>
        <ErrorBox error={err} />
      </Card>
      <Table cols={[{ key: 'title', label: 'Report' }, { key: 'kind', label: 'Type', render: (r) => labelize(r.kind) }, { key: 'generated_at', label: 'Generated', render: (r) => fmtDateTime(r.generated_at || r.created_date) }, { key: 'status', label: 'Status', render: (r) => <Badge kind={r.status === 'complete' ? 'positive' : r.status === 'partial' ? 'medium' : 'critical'}>{r.status}</Badge> }]} rows={list.data || []} onRow={setView} empty="No reports yet — generate one above. Weekly reviews are also created automatically every Monday." />
      {view && (
        <Modal title={view.title} onClose={() => setView(null)} wide footer={<>
          <button className="btn" onClick={() => download(`${(view.title || 'report').replace(/[^\w]+/g, '_')}.md`, view.content_md || '', 'text/markdown')}>Download .md</button>
          {view.payload?.sections && <button className="btn" onClick={() => download('report_sections.csv', toCSV(view.payload.sections.map(([section, body]) => ({ section, content: Array.isArray(body) ? body.join(' | ') : body }))))}>Download CSV</button>}
          <button className="btn primary" onClick={() => window.print()}>Print / Save as PDF</button>
        </>}>
          <div className="small muted">{business?.name} · Period {view.period_start || '—'} to {view.period_end || '—'} · Generated {fmtDateTime(view.generated_at)}</div>
          {view.status !== 'complete' && <Notice kind="warn">{view.error || 'This report is incomplete.'}</Notice>}
          <Markdown text={view.content_md} />
          {view.data_limitations?.length > 0 && <><h3>Data limitations</h3><ul className="small">{view.data_limitations.map((d, i) => <li key={i}>{d}</li>)}</ul></>}
          <p className="small faint">AI-assisted analysis. Not audited financial statements; not legal, tax or accounting advice.</p>
        </Modal>
      )}
    </div>
  );
}
