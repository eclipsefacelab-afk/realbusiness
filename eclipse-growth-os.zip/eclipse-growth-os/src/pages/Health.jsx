import React, { useState } from 'react';
import { api, intel } from '../lib/api';
import { useLoad, useApp } from '../lib/store';
import { PageHead, Card, ErrorBox, Skeleton, Basis, Notice, AsyncButton } from '../components/ui';
import { ScoreRing, LineChart } from '../components/charts';
import { fmtDate } from '../lib/format';

export default function Health() {
  const { notify, businessId } = useApp();
  const a = useLoad((bid) => intel('analysis', { business_id: bid }));
  const hist = useLoad((bid) => api('list', { business_id: bid, entity: 'BusinessMetric', filter: { metric_key: 'health.overall' }, sort: 'period_end', limit: 365 }).then((r) => r.items));
  const [open, setOpen] = useState(null);
  if (a.error) return <ErrorBox error={a.error} retry={a.reload} />;
  if (!a.data) return <Skeleton n={6} />;
  const h = a.data.health;
  return (
    <div className="stack lg">
      <PageHead title="Business Health" subtitle="Maturity assessment across 17 areas. Scores are only calculated from evidence that exists; areas without data are shown as 'no data' rather than guessed.">
        <AsyncButton className="btn" onClick={async () => { await intel('refresh', { business_id: businessId }); notify('Re-assessed'); a.reload(); hist.reload(); }}>Re-assess now</AsyncButton>
      </PageHead>
      <div className="grid g3">
        <Card className="hero"><div className="row"><ScoreRing score={h.overall_score} size={110} /><div><div className="muted small">OVERALL</div><h2 style={{ fontSize: 22 }}>{h.overall_score ?? 'Not enough data'}</h2><div className="small muted">Basis: {h.overall_basis.replace('_', ' ')} · {h.data_coverage_pct}% of areas scored</div>{h.preliminary && <div className="small" style={{ color: '#ffd98a' }}>Preliminary — fewer than 40% of areas have evidence.</div>}</div></div></Card>
        <Card title="Score over time" className="span2">{(hist.data || []).length > 1 ? <LineChart data={hist.data.map((x) => ({ period: x.period_end, value: x.value }))} /> : <p className="muted small">History builds up as the platform re-assesses (daily).</p>}</Card>
      </div>
      {h.missing_information?.length > 0 && <Notice kind="warn"><b>What would make this more accurate:</b> {h.missing_information.slice(0, 6).join(' · ')}</Notice>}
      <div className="grid g3">
        {h.categories.map((c) => (
          <div key={c.key} className="card" style={{ cursor: 'pointer' }} onClick={() => setOpen(open === c.key ? null : c.key)}>
            <div className="row between"><div><h3>{c.label}</h3><div className="small muted">{c.condition}</div></div><ScoreRing score={c.score} size={56} /></div>
            <div style={{ marginTop: 6 }}><Basis b={c.basis} /></div>
            {open === c.key && (
              <div className="stack sm small" style={{ marginTop: 10 }}>
                <div><b>Evidence:</b> {c.evidence.length ? c.evidence.map((e, i) => <div key={i}>• {e.label}: {e.value} <Basis b={e.basis} /></div>) : 'None yet'}</div>
                {c.strengths.length > 0 && <div><b>Strengths:</b> {c.strengths.join('; ')}</div>}
                {c.weaknesses.length > 0 && <div><b>Weaknesses:</b> {c.weaknesses.join('; ')}</div>}
                <div><b>Risk:</b> {c.risk}</div>
                <div><b>Recommended improvement:</b> {c.recommendation}</div>
                {c.missing.length > 0 && <div className="muted"><b>Missing:</b> {c.missing.join('; ')}</div>}
              </div>
            )}
          </div>
        ))}
      </div>
      <p className="small faint">Benchmarks used (e.g. margin floors) are platform planning assumptions for your industry module, not market research about your market.</p>
    </div>
  );
}
