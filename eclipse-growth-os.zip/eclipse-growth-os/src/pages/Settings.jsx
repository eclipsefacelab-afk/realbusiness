import React, { useState } from 'react';
import { api } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { useRouter } from '../lib/router';
import { PageHead, Card, Tabs, Field, AsyncButton, ErrorBox, Table, Notice, Badge } from '../components/ui';
import { labelize, fmtMoney } from '../lib/format';
import { ROLE_LABELS, INDUSTRY_OPTIONS, HEALTH_CATEGORIES, MATURITY_QUESTIONS } from '../lib/constants';
import { SETTINGS_TABS } from './settings.tabs';

export default function Settings() {
  const app = useApp();
  const tabs = [['profile', 'Business profile'], ['members', 'Team & roles'], ['plan', 'Plan'], ['data', 'Data'], ...SETTINGS_TABS.filter((t) => !t.perm || app.can(...t.perm)).map((t) => [t.key, t.label])];
  const [tab, setTab] = useState('profile');
  const Ext = SETTINGS_TABS.find((t) => t.key === tab)?.component;
  return (
    <div className="stack lg">
      <PageHead title="Settings" subtitle="Business profile, team access, plan and data controls. Changes are permission-checked and recorded in the audit log." />
      <Tabs tabs={tabs} value={tab} onChange={setTab} />
      {tab === 'profile' && <Profile />}{tab === 'members' && <Members />}{tab === 'plan' && <Plan />}{tab === 'data' && <DataTab />}{Ext && <Ext />}
    </div>
  );
}

function Profile() {
  const { businessId, can, notify, reload } = useApp();
  const b = useLoad((bid) => api('business.get', { business_id: bid }).then((r) => r.business));
  const [d, setD] = useState(null); const [err, setErr] = useState(null);
  const v = d || b.data || {};
  const set = (k, x) => setD({ ...v, [k]: x });
  const save = async () => { setErr(null); try { const { id, created_date, updated_date, created_by, created_by_id, health_score, health_score_basis, current_stage, stage_reason, owner_user_id, status, is_demo, ...rest } = v; if (!can('finance', 'write')) for (const k of ['avg_monthly_revenue', 'gross_margin_pct', 'monthly_operating_expenses', 'cash_available', 'debt', 'est_customer_acquisition_cost', 'major_recurring_expenses', 'other_financials', 'financials_basis']) delete rest[k]; await api('business.update', { business_id: businessId, data: rest }); notify('Saved'); reload(businessId); } catch (e) { setErr(e); } };
  if (!b.data) return <ErrorBox error={b.error} />;
  const txt = (k, l) => <Field label={l}><input value={v[k] ?? ''} onChange={(e) => set(k, e.target.value)} disabled={!can('business', 'write')} /></Field>;
  const num = (k, l, h) => <Field label={l} hint={h}><input type="number" step="any" value={v[k] ?? ''} onChange={(e) => set(k, e.target.value === '' ? null : Number(e.target.value))} disabled={!can('finance', 'write')} /></Field>;
  return (
    <div className="stack">
      <Card title="Company"><div className="grid g3">{txt('name', 'Name')}<Field label="Industry module"><select value={v.industry_module || 'general'} onChange={(e) => set('industry_module', e.target.value)} disabled={!can('business', 'write')}>{INDUSTRY_OPTIONS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></Field>{txt('business_type', 'Business type')}{txt('country', 'Country')}{txt('province_state', 'Province/state')}{txt('city', 'City')}{txt('currency', 'Currency')}
        <Field label="Countries of operation"><input value={(v.operating_countries || []).join(', ')} onChange={(e) => set('operating_countries', e.target.value.split(',').map((x) => x.trim()).filter(Boolean))} /></Field></div></Card>
      {can('finance', 'read') && <Card title="Owner estimates (used until real data exists)"><div className="grid g3">{num('avg_monthly_revenue', 'Average monthly revenue')}{num('gross_margin_pct', 'Gross margin %')}{num('monthly_operating_expenses', 'Monthly running costs')}{num('cash_available', 'Cash available')}{num('debt', 'Debt')}{num('avg_transaction_value', 'Average sale')}</div></Card>}
      <Card title="Self-assessment (1–5)"><div className="grid g2">{HEALTH_CATEGORIES.map(([k, l]) => <Field key={k} label={l} hint={MATURITY_QUESTIONS[k]}><select value={v.maturity_answers?.[k] || ''} onChange={(e) => set('maturity_answers', { ...(v.maturity_answers || {}), [k]: e.target.value ? Number(e.target.value) : undefined })}><option value="">Not rated</option>{[1, 2, 3, 4, 5].map((n) => <option key={n}>{n}</option>)}</select></Field>)}</div></Card>
      <ErrorBox error={err} />
      {can('business', 'write') && <div><AsyncButton className="btn primary" onClick={save}>Save changes</AsyncButton></div>}
    </div>
  );
}

function Members() {
  const { businessId, can, notify, role } = useApp();
  const m = useLoad((bid) => api('members.list', { business_id: bid }).then((r) => r.members), []);
  const [email, setEmail] = useState(''); const [r, setR] = useState('employee'); const [err, setErr] = useState(null); const [note, setNote] = useState(null);
  if (m.error) return <ErrorBox error={m.error} />;
  const assignable = Object.keys(ROLE_LABELS).filter((x) => role === 'owner' || !['owner', 'admin'].includes(x));
  return (
    <div className="stack">
      <Notice>Roles control who sees what. <b>Finance</b> data is visible to Owner, Administrator and Accountant by default; customer contact details to Owner, Administrator, Manager and Marketing Manager.</Notice>
      <Table cols={[{ key: 'user_email', label: 'Email' }, { key: 'role', label: 'Role', render: (x) => can('members', 'write') && x.status !== 'removed' ? <select value={x.role} onChange={async (e) => { try { await api('members.update', { business_id: businessId, member_id: x.id, role: e.target.value }); notify('Role updated'); m.reload(); } catch (er) { setErr(er); } }}>{Object.entries(ROLE_LABELS).map(([k, l]) => <option key={k} value={k} disabled={!assignable.includes(k)}>{l}</option>)}</select> : ROLE_LABELS[x.role] }, { key: 'status', label: 'Status', render: (x) => <Badge kind={x.status === 'active' ? 'positive' : x.status === 'invited' ? 'medium' : 'low'}>{x.status}</Badge> }, { key: 'a', label: '', render: (x) => can('members', 'write') && x.status !== 'removed' && <AsyncButton className="btn sm danger" onClick={async () => { try { await api('members.remove', { business_id: businessId, member_id: x.id }); m.reload(); } catch (er) { setErr(er); } }}>Remove</AsyncButton> }]} rows={m.data || []} />
      {can('members', 'write') && <Card title="Invite someone"><div className="grid g3"><Field label="Email"><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} /></Field><Field label="Role"><select value={r} onChange={(e) => setR(e.target.value)}>{assignable.map((k) => <option key={k} value={k}>{ROLE_LABELS[k]}</option>)}</select></Field><div style={{ alignSelf: 'end' }}><AsyncButton className="btn primary" disabled={!email} onClick={async () => { setErr(null); try { const out = await api('members.invite', { business_id: businessId, email, role: r }); setNote(out.note); setEmail(''); m.reload(); } catch (e) { setErr(e); } }}>Invite</AsyncButton></div></div>{note && <Notice>{note}</Notice>}</Card>}
      <ErrorBox error={err} />
    </div>
  );
}

function Plan() {
  const { plans, business } = useApp();
  return (
    <div className="stack">
      <Notice>Current plan: <b>{labelize(business?.plan_key || 'trial')}</b>. Subscription billing is not active yet — plans and prices are configurable data (PlanConfig), not hard-coded.</Notice>
      {plans.length ? <Table cols={[{ key: 'name', label: 'Plan' }, { key: 'monthly_price', label: 'Monthly', render: (p) => fmtMoney(p.monthly_price, p.currency) }, { key: 'max_users', label: 'Users', num: true }, { key: 'max_businesses', label: 'Businesses', num: true }, { key: 'features', label: 'Features', render: (p) => (p.features || []).join(', ') }]} rows={plans} /> : <p className="muted small">No plans configured yet. A platform administrator can add PlanConfig records in the Base44 dashboard.</p>}
    </div>
  );
}

function DataTab() {
  const { businessId, role, reload, business, notify } = useApp();
  const { navigate } = useRouter();
  return (
    <div className="stack">
      <Card title="Sample data"><p className="small muted">Open a separate, clearly-labelled demo business to explore features. It never mixes with your real data.</p><AsyncButton className="btn" onClick={async () => { const r = await api('demo.load'); await reload(r.business.id); navigate('/'); }}>Open demo business</AsyncButton></Card>
      <Card title="Export"><p className="small muted">Every list has an "Export CSV" button. Reports can be printed to PDF or downloaded.</p></Card>
      {role === 'owner' && <Card title="Archive this business"><p className="small muted">Archiving hides {business?.name} for all members. Data is retained.</p><AsyncButton className="btn danger" onClick={async () => { if (!window.confirm(`Archive ${business?.name}?`)) return; await api('business.archive', { business_id: businessId }); notify('Archived'); await reload(); navigate('/'); }}>Archive business</AsyncButton></Card>}
    </div>
  );
}
