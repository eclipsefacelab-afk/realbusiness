import React, { useState } from 'react';
import { intel } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { PageHead, Tabs, Table, Stat, Badge, Notice } from '../components/ui';
import EntityManager from '../components/EntityManager';
import { fmtMoney, fmtNum, labelize } from '../lib/format';

const FLAG = { out_of_stock: 'critical', stockout_risk: 'critical', low_stock: 'high', overstock: 'monitor', slow_moving: 'monitor', fast_moving: 'opportunity' };
export default function Inventory() {
  const { business } = useApp();
  const [tab, setTab] = useState('intel');
  const a = useLoad((bid) => intel('analysis', { business_id: bid }));
  const s = a.data?.snapshot;
  const risky = (s?.inventory || []).filter((i) => i.flags.some((f) => ['out_of_stock', 'stockout_risk', 'low_stock'].includes(f)));
  return (
    <div className="stack lg">
      <PageHead title="Inventory Intelligence" subtitle="Low stock, overstock, slow and fast movers, and cash tied up in stock. Days-left figures are forecasts from the last 30 days of sales." />
      <Tabs tabs={[['intel', 'Alerts & forecasts'], ['records', 'Stock records']]} value={tab} onChange={setTab} />
      {tab === 'intel' && s && (
        <>
          <div className="grid g3"><Stat label="Items at risk" value={risky.length} /><Stat label="Capital in stock" m={s.inventory_capital} format={(v) => fmtMoney(v, business?.currency)} /><Stat label="Overstock / slow items" value={s.inventory.filter((i) => i.flags.includes('overstock') || i.flags.includes('slow_moving')).length} /></div>
          <Table cols={[{ key: 'name', label: 'Item' }, { key: 'on_hand', label: 'On hand', num: true }, { key: 'velocity_per_day', label: 'Sells/day', num: true, render: (r) => fmtNum(r.velocity_per_day, 2) }, { key: 'days_of_cover', label: 'Days left (forecast)', num: true }, { key: 'lead_time_days', label: 'Lead time', num: true }, { key: 'capital', label: 'Value at cost', num: true, render: (r) => fmtMoney(r.capital, business?.currency) }, { key: 'flags', label: 'Status', render: (r) => <span className="chip-list">{r.flags.map((f) => <Badge key={f} kind={FLAG[f]}>{labelize(f)}</Badge>)}</span> }]} rows={[...s.inventory].sort((x, y) => (x.days_of_cover ?? 9999) - (y.days_of_cover ?? 9999))} empty="No stock records yet" />
          <Notice>Forecast: "Days left" = on-hand ÷ average daily sales over the last 30 days. Set lead times and reorder points for earlier warnings.</Notice>
        </>
      )}
      {tab === 'records' && <EntityManager entity="InventoryItem" title="Stock records" onChanged={a.reload}
        columns={[{ key: 'product_id', label: 'Product', type: 'ref' }, { key: 'variant_id', label: 'Variant', type: 'ref' }, { key: 'location_id', label: 'Location', type: 'ref' }, { key: 'on_hand', label: 'On hand', num: true }, { key: 'reorder_point', label: 'Reorder at', num: true }, { key: 'lead_time_days', label: 'Lead time', num: true }]}
        fields={[{ key: 'product_id', label: 'Product', type: 'ref', ref: 'Product' }, { key: 'variant_id', label: 'Variant / shade', type: 'ref', ref: 'ProductVariant', filterRef: (o, v) => !v.product_id || o.product_id === v.product_id }, { key: 'location_id', label: 'Location', type: 'ref', ref: 'BusinessLocation' }, { key: 'on_hand', label: 'On hand', type: 'number', required: true }, { key: 'reserved', label: 'Reserved', type: 'number' }, { key: 'reorder_point', label: 'Reorder point', type: 'number' }, { key: 'safety_stock', label: 'Safety stock', type: 'number' }, { key: 'unit_cost', label: 'Unit cost', type: 'number' }, { key: 'lead_time_days', label: 'Lead time (days)', type: 'number' }, { key: 'last_counted', label: 'Last counted', type: 'date' }]} searchKeys={['id']} />}
    </div>
  );
}
