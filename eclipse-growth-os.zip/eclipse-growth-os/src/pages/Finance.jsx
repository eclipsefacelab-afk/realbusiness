import React, { useState } from 'react';
import { api, intel } from '../lib/api';
import { useApp, useLoad } from '../lib/store';
import { PageHead, Tabs, Stat, Card, Notice } from '../components/ui';
import { BarList } from '../components/charts';
import EntityManager from '../components/EntityManager';
import { fmtMoney, fmtPct, fmtNum } from '../lib/format';

export default function Finance() {
  const { business } = useApp();
  const cur = business?.currency;
  const [tab, setTab] = useState('overview');
  const a = useLoad((bid) => intel('analysis', { business_id: bid }));
  const s = a.data?.snapshot;
  const be = s && s.gross_margin_pct.value && s.opex_monthly.value ? s.opex_monthly.value / (s.gross_margin_pct.value / 100) : null;
  return (
    <div className="stack lg">
      <PageHead title="Financial Intelligence" subtitle="Plain-language view of money in, money out and cash. Every figure is labelled actual, estimated, forecast or assumption. This is not accounting or tax advice — consult your accountant for statements and filings." />
      <Tabs tabs={[['overview', 'Overview'], ['expenses', 'Expenses'], ['statements', 'Monthly summaries']]} value={tab} onChange={setTab} />
      {tab === 'overview' && s && (
        <>
          <div className="grid g4">
            <Stat label="Revenue (30 days)" m={s.revenue_30d} format={(v) => fmtMoney(v, cur)} />
            <Stat label="Gross margin" m={s.gross_margin_pct} format={(v) => fmtPct(v)} sub="Share of sales left after product costs" />
            <Stat label="Running costs / month" m={s.opex_monthly} format={(v) => fmtMoney(v, cur)} />
            <Stat label="Est. monthly profit" m={s.net_profit_monthly} format={(v) => fmtMoney(v, cur)} />
          </div>
          <div className="grid g3">
            <Stat label="Cash" m={s.cash} format={(v) => fmtMoney(v, cur)} />
            <Stat label="Cash runway" m={s.runway_months} format={(v) => `${fmtNum(v, 1)} months`} sub={s.runway_months.note === 'positive' ? 'Cash-flow positive — operations are not using up cash' : 'Months until cash runs out at the current loss rate (estimate)'} />
            <Stat label="Break-even monthly sales" value={be} format={(v) => fmtMoney(v, cur)} sub="Running costs ÷ gross margin (estimate). Sales above this make a profit." />
          </div>
          <Card title="Where the money goes (last 90 days)"><ExpenseBreakdown /></Card>
          <Notice>Cash-flow outlook and scenario modelling are in <b>Forecasts</b> and <b>Scenarios</b>.</Notice>
        </>
      )}
      {tab === 'expenses' && <EntityManager entity="Expense" title="Expenses" sort="-date" onChanged={a.reload}
        columns={[{ key: 'date', label: 'Date', type: 'date' }, { key: 'category', label: 'Category', type: 'select' }, { key: 'vendor', label: 'Vendor' }, { key: 'amount', label: 'Amount', num: true }, { key: 'cost_type', label: 'Fixed/variable', type: 'select' }, { key: 'data_basis', label: 'Basis', type: 'select' }]}
        fields={[{ key: 'date', label: 'Date', type: 'date', required: true }, { key: 'amount', label: 'Amount', type: 'number', required: true }, { key: 'category', label: 'Category', type: 'select', options: ['cogs_materials', 'packaging', 'manufacturing', 'payroll', 'rent', 'marketing', 'events', 'software', 'shipping', 'professional_fees', 'utilities', 'travel', 'loan_payment', 'other'] }, { key: 'cost_type', label: 'Fixed or variable', type: 'select', options: ['variable', 'fixed'], hint: 'Fixed = same every month (rent). Variable = changes with sales (packaging).' }, { key: 'vendor', label: 'Vendor' }, { key: 'location_id', label: 'Location', type: 'ref', ref: 'BusinessLocation' }, { key: 'recurring', label: 'Recurring', type: 'checkbox' }, { key: 'data_basis', label: 'Basis', type: 'select', options: ['actual', 'estimated'] }, { key: 'description', label: 'Description', wide: true }]} searchKeys={['vendor', 'description', 'category']} />}
      {tab === 'statements' && <EntityManager entity="FinancialMetric" title="Monthly summaries" sort="-period_start" onChanged={a.reload} intro="Enter monthly totals from your accounting software or statements (or import a CSV). Cash balance here is used for runway."
        columns={[{ key: 'period_start', label: 'Period', type: 'date' }, { key: 'revenue', label: 'Revenue', num: true }, { key: 'cogs', label: 'Cost of goods', num: true }, { key: 'operating_expenses', label: 'Running costs', num: true }, { key: 'cash_balance', label: 'Cash', num: true }, { key: 'data_basis', label: 'Basis', type: 'select' }]}
        fields={[{ key: 'period_start', label: 'Period start', type: 'date', required: true }, { key: 'period_end', label: 'Period end', type: 'date' }, { key: 'period_type', label: 'Period', type: 'select', options: ['month', 'quarter', 'year'] }, { key: 'revenue', label: 'Revenue', type: 'number' }, { key: 'cogs', label: 'Cost of goods sold', type: 'number' }, { key: 'gross_profit', label: 'Gross profit', type: 'number' }, { key: 'operating_expenses', label: 'Operating expenses', type: 'number' }, { key: 'net_profit', label: 'Net profit', type: 'number' }, { key: 'cash_balance', label: 'Cash balance (end)', type: 'number' }, { key: 'accounts_receivable', label: 'Owed to you (receivables)', type: 'number' }, { key: 'accounts_payable', label: 'You owe (payables)', type: 'number' }, { key: 'inventory_value', label: 'Inventory value', type: 'number' }, { key: 'payroll', label: 'Payroll', type: 'number' }, { key: 'marketing_spend', label: 'Marketing spend', type: 'number' }, { key: 'debt_balance', label: 'Debt balance', type: 'number' }, { key: 'data_basis', label: 'Basis', type: 'select', options: ['actual', 'estimated'] }]} searchKeys={['period_start']} />}
    </div>
  );
}

function ExpenseBreakdown() {
  const { business } = useApp();
  const e = useLoad((bid) => api('list', { business_id: bid, entity: 'Expense', sort: '-date', limit: 5000 }).then((r) => r.items));
  const cutoff = new Date(Date.now() - 90 * 86400000).toISOString().slice(0, 10);
  const by = {};
  for (const x of (e.data || []).filter((r) => r.date >= cutoff)) by[x.category || 'other'] = (by[x.category || 'other'] || 0) + (Number(x.amount) || 0);
  const rows = Object.entries(by).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ label: k.replace(/_/g, ' '), value: v }));
  return rows.length ? <BarList rows={rows} format={(v) => fmtMoney(v, business?.currency)} /> : <p className="muted small">No expenses in the last 90 days.</p>;
}
