import React, { useState } from 'react';
import { Router, Link, usePathname, useRouter } from './lib/router';
import { AppProvider, useApp } from './lib/store';
import { Loading, ErrorBox } from './components/ui';
import { NAV, ROUTES } from './routes';
import { login, logout } from './lib/api';
import Onboarding from './pages/Onboarding';

const INDUSTRY_HIDE = { restaurant: ['/competitors'], professional_services: ['/inventory'], construction: ['/inventory'], transportation: ['/inventory'] };

function Shell() {
  const app = useApp();
  const path = usePathname();
  const { navigate } = useRouter();
  const [open, setOpen] = useState(false);
  if (app.loading) return <Loading label="Loading your workspace…" />;
  if (app.error) return (
    <div className="content stack">
      <ErrorBox error={app.error} retry={() => app.reload()} />
      {app.error.status === 401 && <button className="btn primary" onClick={login}>Sign in</button>}
    </div>
  );
  if (!app.businesses.length || path === '/onboarding') return <Onboarding />;
  const Page = (ROUTES[path] || ROUTES['/']).component;
  const hide = INDUSTRY_HIDE[app.business?.industry_module] || [];
  const visible = NAV.map((sec) => ({ ...sec, items: sec.items.filter((i) => !hide.includes(i.to) && (!i.perm || app.can(...i.perm))) })).filter((s) => s.items.length);
  return (
    <div className="app">
      <aside className={`sidebar ${open ? 'open' : ''}`} onClick={(e) => e.target.closest('a') && setOpen(false)}>
        <div className="brand"><div className="logo" /><div><b>Eclipse Growth OS</b><span>AI Business Growth Platform</span></div></div>
        <div className="biz-switch">
          <select aria-label="Switch business" value={app.businessId || ''} onChange={(e) => { if (e.target.value === '__new') navigate('/onboarding'); else if (e.target.value === '__portfolio') navigate('/portfolio'); else app.select(e.target.value); }}>
            {app.businesses.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
            {app.businesses.length > 1 && <option value="__portfolio">▦ Portfolio overview</option>}
            <option value="__new">＋ Add a business</option>
          </select>
        </div>
        <nav className="nav">
          {visible.map((sec) => (
            <React.Fragment key={sec.label}>
              {sec.label && <div className="sec">{sec.label}</div>}
              {sec.items.map((i) => { const Icon = i.icon; return <Link key={i.to} to={i.to} className={i.cta ? 'cta' : ''}>{Icon && <Icon />}{i.label}</Link>; })}
            </React.Fragment>
          ))}
        </nav>
      </aside>
      <div className="main">
        <header className="topbar">
          <button className="btn sm menu-btn" onClick={() => setOpen(true)} aria-label="Open menu">☰</button>
          <b>{app.business?.name}</b><span className="faint small">{app.role && `· ${app.role.replace('_', ' ')}`}</span>
          <div className="spacer" />
          <span className="small muted">{app.user?.email}</span>
          <button className="btn sm ghost" onClick={logout}>Sign out</button>
        </header>
        {app.business?.is_demo && <div className="demo-banner">⚠ SAMPLE DATA — this is a demonstration business with fictional records. Nothing here is real. Switch to your business in the menu.</div>}
        <main className="content" key={app.businessId}><Page /></main>
      </div>
    </div>
  );
}

export default function App() {
  return <Router><AppProvider><Shell /></AppProvider></Router>;
}
