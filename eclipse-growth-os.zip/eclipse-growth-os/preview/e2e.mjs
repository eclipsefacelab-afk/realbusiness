// End-to-end walkthrough of the real UI against real backend handlers (in-memory DB).
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import fs from 'node:fs';
const BASE = 'http://localhost:5199';
const shots = new URL('./shots/', import.meta.url).pathname; fs.mkdirSync(shots, { recursive: true });
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1400, height: 950 } });
const errors = [];
page.on('pageerror', (e) => errors.push(`pageerror: ${e.message}`));
page.on('console', (m) => { if (m.type() === 'error') errors.push(`console: ${m.text()}`); });
const step = async (name, fn) => { try { await fn(); console.log('✓', name); } catch (e) { console.log('✗', name, e.message.split('\n')[0]); errors.push(`${name}: ${e.message.split('\n')[0]}`); await page.screenshot({ path: shots + 'FAIL_' + name.replace(/\W+/g, '_') + '.png' }); } };

await page.goto(BASE + '/');
await step('onboarding shows', () => page.getByText('Set up your business').waitFor({ timeout: 8000 }));
await page.screenshot({ path: shots + '01_onboarding.png' });
await step('onboarding Eclipse prefill + create', async () => {
  await page.getByRole('button', { name: 'Pre-fill Eclipse basics' }).click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByLabel(/Average monthly sales/).fill('25000');
  await page.getByLabel(/Gross margin/).fill('60');
  await page.getByLabel(/Monthly running costs/).fill('17000');
  await page.getByLabel(/Cash available today/).fill('40000');
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByText('Increase repeat customers').click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: 'Create business' }).click();
  await page.getByText('Good to see you').waitFor({ timeout: 10000 });
});
await page.screenshot({ path: shots + '02_overview_eclipse_estimates.png', fullPage: true });
await step('demo business loads', async () => {
  await page.evaluate(() => { history.pushState({}, '', '/settings'); dispatchEvent(new PopStateEvent('popstate')); }); await page.getByRole('tab', { name: 'Data' }).click();
  await page.getByRole('button', { name: 'Open demo business' }).click();
  await page.getByText('SAMPLE DATA').waitFor({ timeout: 20000 });
  await page.getByRole('button', { name: /Refresh analysis/ }).click();
  await page.waitForTimeout(1500);
});
await page.screenshot({ path: shots + '03_overview_demo.png', fullPage: true });
const routes = ['/next', '/health', '/plan', '/advisor', '/sales', '/customers', '/products', '/inventory', '/marketing', '/finance', '/operations', '/competitors', '/risks', '/goals', '/decisions', '/reports', '/documents', '/import', '/integrations', '/portfolio', '/settings', '/command', '/alerts', '/approvals', '/forecasts', '/scenarios', '/expansion', '/opportunities', '/strategy', '/workflows'];
for (const r of routes) {
  await step(`page ${r}`, async () => {
    await page.evaluate((to) => { history.pushState({}, '', to); dispatchEvent(new PopStateEvent('popstate')); }, r);
    await page.waitForTimeout(1200);
    await page.locator('h1').first().waitFor({ timeout: 5000 });
    if ((await page.locator('h1').first().innerText()).includes('Set up your business')) throw new Error('fell back to onboarding');
    const err = await page.locator('.alert-box.err').count();
    if (err) throw new Error('error box: ' + (await page.locator('.alert-box.err').first().innerText()));
    await page.screenshot({ path: shots + `page_${r.slice(1) || 'home'}.png`, fullPage: true });
  });
}
await step('approve recommendation → task', async () => {
  await page.evaluate(() => { history.pushState({}, '', '/next'); dispatchEvent(new PopStateEvent('popstate')); });
  await page.getByRole('button', { name: /Approve/ }).first().click();
  await page.getByText(/Approved/).first().waitFor({ timeout: 5000 });
});
await step('generate plan', async () => {
  await page.evaluate(() => { history.pushState({}, '', '/plan'); dispatchEvent(new PopStateEvent('popstate')); });
  await page.getByRole('button', { name: 'Generate / update plan' }).click();
  await page.getByText(/Plan updated/).waitFor({ timeout: 8000 });
  await page.screenshot({ path: shots + 'plan_generated.png', fullPage: true });
});
await step('weekly review report', async () => {
  await page.evaluate(() => { history.pushState({}, '', '/reports'); dispatchEvent(new PopStateEvent('popstate')); });
  await page.getByRole('button', { name: 'Weekly Business Review' }).click();
  await page.getByRole('dialog').waitFor({ timeout: 8000 });
  await page.screenshot({ path: shots + 'weekly_review.png', fullPage: true });
  await page.getByRole('button', { name: 'Close' }).click();
});
await step('advisor asks', async () => {
  await page.evaluate(() => { history.pushState({}, '', '/advisor'); dispatchEvent(new PopStateEvent('popstate')); });
  await page.getByRole('button', { name: 'How is my business doing?' }).click();
  await page.getByText('Preview mode').first().waitFor({ timeout: 8000 });
});
await step('CSV import review + commit', async () => {
  await page.evaluate(() => { history.pushState({}, '', '/import'); dispatchEvent(new PopStateEvent('popstate')); });
  const csv = 'date,product,shade,quantity,unit_price,revenue,channel\n2026-11-10,Sample Silk Foundation,Cocoa 550,3,42,126,ecommerce\n03/11/2026,Sample Silk Foundation,Cocoa 550,1,42,42,ecommerce\n';
  await page.setInputFiles('input[type=file]', { name: 'sales.csv', mimeType: 'text/csv', buffer: Buffer.from(csv) });
  await page.getByText('Review — sales.csv').waitFor({ timeout: 5000 });
  await page.screenshot({ path: shots + 'import_review.png', fullPage: true });
  await page.getByRole('button', { name: /Import 1 records/ }).click();
  await page.getByText('Imported 1 records').waitFor({ timeout: 5000 });
});
const go = (to) => page.evaluate((t) => { history.pushState({}, '', t); dispatchEvent(new PopStateEvent('popstate')); }, to);
await step('P2: run checks creates alerts', async () => { await go('/alerts'); await page.getByRole('button', { name: 'Run checks now' }).click(); await page.getByText(/Checked:/).waitFor({ timeout: 10000 }); await page.screenshot({ path: shots + 'p2_alerts.png', fullPage: true }); });
await step('P2: low-stock workflow → approval → approve', async () => { await go('/workflows'); await page.getByRole('button', { name: 'Run now' }).first().click(); await page.getByText(/waiting for approval/).waitFor({ timeout: 10000 }); await go('/approvals'); await page.screenshot({ path: shots + 'p2_approvals.png', fullPage: true }); await page.getByRole('button', { name: 'Approve' }).first().click(); await page.getByText(/Nothing was sent/).first().waitFor({ timeout: 8000 }); });
await step('P2: scenario runs', async () => { await go('/scenarios'); await page.waitForTimeout(800); await page.getByRole('button', { name: 'Run scenario' }).click(); await page.getByText('Estimated effect').waitFor({ timeout: 8000 }); await page.screenshot({ path: shots + 'p2_scenario.png', fullPage: true }); });
await step('P2: command center question (multi-agent)', async () => { await go('/command'); await page.getByLabel('Ask the AI team').fill('Our manufacturing costs increased, what should we do?'); await page.getByRole('button', { name: 'Ask' }).click(); await page.getByText('Coordinated answer').waitFor({ timeout: 10000 }); await page.screenshot({ path: shots + 'p2_command.png', fullPage: true }); });
await step('P2: forecasts render', async () => { await go('/forecasts'); await page.getByText('Revenue (monthly)').waitFor({ timeout: 8000 }); await page.screenshot({ path: shots + 'p2_forecasts.png', fullPage: true }); });
await step('P2: settings automation tab', async () => { await go('/settings'); await page.getByRole('tab', { name: 'AI & automation' }).click(); await page.getByText('Alert thresholds').waitFor({ timeout: 5000 }); await page.getByRole('tab', { name: 'Audit log' }).click(); await page.waitForTimeout(600); await page.screenshot({ path: shots + 'p2_audit.png', fullPage: true }); });
await step('mobile layout', async () => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.evaluate(() => { history.pushState({}, '', '/'); dispatchEvent(new PopStateEvent('popstate')); });
  await page.waitForTimeout(800);
  await page.screenshot({ path: shots + 'mobile_overview.png', fullPage: true });
  await page.getByRole('button', { name: 'Open menu' }).click();
  await page.waitForTimeout(300);
  await page.screenshot({ path: shots + 'mobile_menu.png' });
});
await browser.close();
console.log(errors.length ? `\nERRORS (${errors.length}):\n` + [...new Set(errors)].join('\n') : '\nNo errors');
