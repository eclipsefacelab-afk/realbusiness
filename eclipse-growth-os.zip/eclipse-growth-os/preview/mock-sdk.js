// PREVIEW ONLY: stands in for @base44/sdk so the real UI + real backend handlers run in a browser
// against an in-memory database. Not used in the Base44 build.
import { createMockBase44 } from '../tests/mock-base44.ts';
import { handleApi } from '../shared/api-handler.ts';
import { handleIntelligence } from '../shared/intelligence-handler.ts';
import { handleMonitor } from '../shared/monitor-handler.ts';
import '../shared/register.ts';

const m = createMockBase44();
const params = new URLSearchParams(location.search);
m.setUser({ id: params.get('uid') || 'preview_owner', email: params.get('email') || 'owner@preview.local', full_name: 'Preview Owner', role: 'user' });
m.setLLM((p) => {
  const props = p.response_json_schema?.properties || {};
  if (props.answer) return { answer: '**Preview mode:** the AI model is not connected in this offline preview. In Base44 this answer is generated from your data.', what: 'Connect in Base44', why: 'Preview has no AI provider', evidence: [], expected_impact: 'n/a', risks: 'n/a', next_step: 'Deploy to Base44', confidence: 'low', missing_information: ['Live AI provider'] };
  if (props.findings) return { findings: [{ statement: 'Preview mode: specialist analysis runs in Base44.', basis: 'assumption' }], recommendation: 'Deploy to Base44 for live AI.', uncertainty: ['AI provider not connected in preview'] };
  if (props.items) return { items: [] };
  if (props.subject) return { subject: 'Thank you for visiting us', body: 'Hi {first_name}, (preview draft)' };
  if (props.summary) return { summary: 'Preview mode — AI summary not generated offline.' };
  throw new Error('Preview mode: AI provider not connected');
});
window.__previewDB = m;
const fns = { api: handleApi, intelligence: handleIntelligence, monitor: handleMonitor };
export function createClient() {
  return {
    functions: { invoke: async (name, payload) => { try { return { data: await fns[name](JSON.parse(JSON.stringify(payload)), { client: m.client, svc: m.svc }) }; } catch (e) { const err = new Error(e.message); err.response = { status: e.status || 500, data: { error: e.message } }; throw err; } } },
    auth: { me: () => m.client.auth.me(), logout: () => alert('Preview: sign out'), redirectToLogin: () => {} },
    integrations: { Core: { UploadPrivateFile: async ({ file }) => ({ file_uri: `preview://${file.name}` }) } },
  };
}
