import * as esbuild from '/opt/npm-tools/node_modules/esbuild/lib/main.js';
import fs from 'node:fs';
const out = new URL('./dist/', import.meta.url).pathname;
fs.mkdirSync(out, { recursive: true });
await esbuild.build({
  entryPoints: [new URL('../src/main.jsx', import.meta.url).pathname], bundle: true, outfile: out + 'app.js', format: 'esm', jsx: 'automatic',
  loader: { '.js': 'jsx', '.jsx': 'jsx' }, nodePaths: ['/opt/npm-tools/node_modules'], alias: { '@base44/sdk': new URL('./mock-sdk.js', import.meta.url).pathname },
  define: { 'import.meta.env.VITE_BASE44_APP_ID': '"preview"', 'process.env.NODE_ENV': '"development"' }, logLevel: 'warning', sourcemap: 'inline',
});
fs.writeFileSync(out + 'index.html', '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Eclipse Growth OS (preview)</title><link rel="stylesheet" href="/app.css"></head><body><div id="root"></div><script type="module" src="/app.js"></script></body></html>');
console.log('built');
