import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const root = new URL('./dist/', import.meta.url).pathname;
http.createServer((req, res) => { const p = path.join(root, decodeURIComponent(req.url.split('?')[0])); const f = fs.existsSync(p) && fs.statSync(p).isFile() ? p : path.join(root, 'index.html'); res.setHeader('content-type', f.endsWith('.js') ? 'text/javascript' : f.endsWith('.css') ? 'text/css' : 'text/html'); fs.createReadStream(f).pipe(res); }).listen(5199, () => console.log('serving 5199'));
