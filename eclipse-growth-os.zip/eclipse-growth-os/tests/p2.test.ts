// Master Prompt 2 — agents, orchestration, monitoring, prediction, approvals, governance tests.
import { test, describe } from 'node:test';
import assert from 'node:assert/strict';
import { createMockBase44 } from './mock-base44.ts';
import { handleApi } from '../shared/api-handler.ts';
import { handleIntelligence } from '../shared/intelligence-handler.ts';
import { handleMonitor } from '../shared/monitor-handler.ts';
import { routeQuestion, AGENTS } from '../shared/p2/agents.ts';
import { forecastSeries, simulate } from '../shared/p2/predict.ts';
import { detectExceptions } from '../shared/p2/exceptions.ts';
import { DEFAULT_SETTINGS } from '../shared/p2/settings.ts';
import '../shared/register.ts';

const NOW = new Date('2026-11-16T15:00:00Z');
const OWNER = { id: 'own', email: 'owner@eclipse.test' };
const agentLLM = (p: any) => {
  const props = p.response_json_schema?.properties || {};
  if (props.findings) return { findings: [{ statement: `Finding from ${p.prompt.match(/You are the ([^.]+)\./)?.[1]}`, basis: 'actual' }], recommendation: 'Act on data', uncertainty: ['Limited history'] };
  if (props.answer) return { answer: 'Combined answer', what: 'w', why: 'y', evidence: [{ fact: 'Revenue recorded', basis: 'actual' }], expected_impact: 'Estimate only', risks: 'r', next_step: 'n', confidence: 'moderate', missing_information: [], unresolved_uncertainty: ['Limited history'] };
  if (props.items) return { items: [] };
  if (props.subject) return { subject: 'Thank you', body: 'Hi {first_name}' };
  if (props.what_happened) return Object.fromEntries(Object.keys(props).map((k) => [k, 'See data.']));
  if (props.summary) return { summary: 'ok', threats: [], advantages: [], gaps: [], opportunities: [] };
  return { summary: 'ok' };
};
async function demo() {
  const m = createMockBase44();
  m.setLLM(agentLLM);
  const api = (u: any, b: any, now = NOW) => { m.setUser(u); return handleApi(b, { client: m.client, svc: m.svc, now }); };
  const intel = (u: any, b: any, now = NOW) => { m.setUser(u); return handleIntelligence(b, { client: m.client, svc: m.svc, now }); };
  const { business } = await api(OWNER, { action: 'demo.load' });
  return { m, api, intel, bid: business.id };
}
const addMember = (m: any, bid: string, u: any, role: string) => m.svc.entities.BusinessMember.create({ business_id: bid, user_id: u.id, user_email: u.email, role, status: 'active' });
const rejects = async (p: Promise<any>, status: number) => assert.rejects(p, (e: any) => { assert.equal(e.status, status, e.message); return true; });

describe('Specialised agents & orchestration', () => {
  test('nine agents defined; routing respects role permissions and admin disabling', () => {
    assert.equal(AGENTS.length, 9);
    const all = Object.fromEntries(AGENTS.map((a) => [a.key, true]));
    assert.ok(routeQuestion('Can I afford to expand into Jamaica?', 'owner', all).agents.some((a) => a.key === 'finance'));
    const emp = routeQuestion('Why are my profits declining?', 'employee', all);
    assert.ok(!emp.agents.some((a) => a.key === 'finance') && emp.blocked.some((b) => b.key === 'finance'));
    const off = routeQuestion('Where am I losing money?', 'owner', { ...all, finance: false });
    assert.ok(off.blocked.some((b) => b.key === 'finance' && /disabled/.test(b.reason)));
  });
  test('multi-agent collaboration on rising manufacturing costs produces one coordinated answer + AgentRun', async () => {
    const { m, intel, bid } = await demo();
    const r = await intel(OWNER, { action: 'advisor.ask', business_id: bid, question: 'Our manufacturing costs increased — what should we do?' });
    assert.ok(r.ok);
    assert.equal(r.answer.collaboration, 'Manufacturing cost increase');
    assert.deepEqual(r.answer.agents.length, 4);
    const run = m.rows('AgentRun').find((x) => x.id === r.agent_run_id);
    assert.deepEqual(run.agents, ['manufacturing', 'inventory', 'finance', 'sales']);
    assert.equal(run.agent_findings.length, 4); assert.ok(run.unresolved_uncertainty.length);
    assert.ok(m.rows('AIUsageLog').filter((x) => x.business_id === bid).length >= 5, 'usage logged per agent + synthesis');
  });
  test('partial agent failure is reported, total failure is not silently answered', async () => {
    const { m, intel, bid } = await demo();
    m.setLLM((p) => { if (p.response_json_schema?.properties?.findings && /Sales Intelligence Officer/.test(p.prompt)) throw new Error('timeout'); return agentLLM(p); });
    const r = await intel(OWNER, { action: 'advisor.ask', business_id: bid, question: 'Why are sales down?' });
    assert.equal(r.status, 'partial'); assert.ok(r.answer.partial_note);
    m.setLLM(() => { throw new Error('provider down'); });
    const r2 = await intel(OWNER, { action: 'advisor.ask', business_id: bid, question: 'Why are sales down?' });
    assert.equal(r2.ok, false); assert.equal(r2.answer, null);
  });
  test('employee context excludes finance data', async () => {
    const { m, intel, bid } = await demo();
    const EMP = { id: 'emp', email: 'emp@e.test' }; await addMember(m, bid, EMP, 'employee');
    await intel(EMP, { action: 'advisor.ask', business_id: bid, question: 'How are sales and stock?' });
    const prompts = m.llmCalls.map((c) => c.prompt).join('\n');
    assert.doesNotMatch(prompts, /"cash":\{"value":48500/);
    assert.match(prompts, /Restricted for your role/);
  });
});

describe('Monitoring, exceptions & alerts', () => {
  test('detectors classify severity from configurable thresholds', () => {
    const d: any = { sales: [], expenses: [], inventory: [], products: [], variants: [], productionRuns: [], invoices: [{ id: 'i1', invoice_number: 'W-1', due_date: '2026-09-01', amount: 5000, amount_paid: 0, status: 'open' }] };
    const ex = detectExceptions(d, DEFAULT_SETTINGS.thresholds, NOW);
    const o = ex.find((e) => e.exception_type === 'overdue_payment')!;
    assert.equal(o.severity, 'high'); assert.ok(o.why_it_matters && o.recommended_action && o.supporting_records.length);
  });
  test('alerts are de-duplicated, escalate only on severity increase, and have a lifecycle', async () => {
    const { m, api, intel, bid } = await demo();
    await intel(OWNER, { action: 'monitor.run', business_id: bid });
    const n1 = m.rows('Alert').filter((a) => a.business_id === bid).length; assert.ok(n1 > 0);
    const notes1 = m.rows('Notification').length;
    await intel(OWNER, { action: 'monitor.run', business_id: bid });
    assert.equal(m.rows('Alert').filter((a) => a.business_id === bid).length, n1, 'no duplicate alerts');
    assert.equal(m.rows('Notification').length, notes1, 'no repeated notifications');
    const al = m.rows('Alert').find((a) => a.business_id === bid);
    assert.ok(al.occurrences >= 2);
    for (const op of ['acknowledge', 'assign', 'annotate', 'close']) await api(OWNER, { action: 'alert.update', business_id: bid, id: al.id, op, assigned_to: 'ops', text: 'checking', resolution: 'restocked' });
    const done = m.tables.Alert.get(al.id); assert.equal(done.status, 'closed'); assert.equal(done.notes.length, 1);
    assert.ok(m.rows('AuditLog').some((x) => x.action === 'alert.close'));
  });
  test('event-driven: an overdue invoice write raises an alert immediately (no full scan job)', async () => {
    const { m, api, bid } = await demo();
    await api(OWNER, { action: 'create', business_id: bid, entity: 'Invoice', data: { invoice_number: 'W-77', amount: 1200, due_date: '2026-10-01', status: 'open' } });
    assert.ok(m.rows('Alert').some((a) => a.business_id === bid && a.exception_type === 'overdue_payment'));
  });
  test('admins can change thresholds; changes are audited; others cannot', async () => {
    const { m, api, bid } = await demo();
    const MGR = { id: 'mgr', email: 'm@e.test' }; await addMember(m, bid, MGR, 'manager');
    await rejects(api(MGR, { action: 'settings.update', business_id: bid, data: { thresholds: { sales_decline_pct: 5 } } }), 403);
    const r = await api(OWNER, { action: 'settings.update', business_id: bid, data: { thresholds: { ...DEFAULT_SETTINGS.thresholds, sales_decline_pct: 5 } } });
    assert.equal(r.settings.thresholds.sales_decline_pct, 5);
    assert.ok(m.rows('AuditLog').some((x) => x.action === 'settings.update'));
    await rejects(api(OWNER, { action: 'settings.update', business_id: bid, data: { workflow_modes: { low_stock_purchase: 'automatic' } } }), 422);
  });
  test('scheduled monitoring respects frequency and prevents duplicate runs', async () => {
    const { m, bid } = await demo();
    m.setUser(null);
    const r1 = await handleMonitor({ args: {} }, { client: m.client, svc: m.svc, now: NOW });
    assert.ok(r1.results.some((x: any) => x.health !== undefined));
    const r2 = await handleMonitor({ args: {} }, { client: m.client, svc: m.svc, now: new Date(NOW.getTime() + 3600000) });
    assert.ok(r2.results.every((x: any) => x.skipped === 'not_due'), 'daily frequency honoured');
    assert.ok(m.rows('Opportunity').some((o) => o.business_id === bid));
  });
});

describe('Predictive intelligence', () => {
  test('forecast refuses with <3 months and returns 3 labelled scenarios otherwise', () => {
    assert.equal(forecastSeries([{ period: '2026-01', value: 10 }, { period: '2026-02', value: 12 }], 3, { label: 'revenue' }).ok, false);
    const f: any = forecastSeries([10, 12, 13, 15, 16, 18].map((v, i) => ({ period: `2026-0${i + 1}`, value: v * 1000 })), 3, { label: 'revenue' });
    assert.ok(f.ok && f.conservative.length === 3 && f.assumptions.some((a: string) => /not a guarantee/.test(a)));
    assert.ok(f.conservative[0].value <= f.expected[0].value && f.expected[0].value <= f.aggressive[0].value);
  });
  test('forecast endpoint: revenue, cash outlook, demand & purchase quantities, customer behaviour; saved forecasts compare to actuals', async () => {
    const { m, intel, bid } = await demo();
    const f = await intel(OWNER, { action: 'forecast', business_id: bid, save: true });
    assert.ok(f.revenue.ok && f.cash.ok && f.demand.length > 0);
    assert.ok(f.demand.some((d: any) => d.recommended_order_qty > 0));
    assert.ok(f.customer_behaviour.list.length > 0);
    assert.equal(m.rows('Forecast').length, 1);
  });
  test('scenario simulation math & labels', async () => {
    const { intel, bid } = await demo();
    const base = await intel(OWNER, { action: 'scenario.run', business_id: bid, kind: 'sales_change', params: { sales_change_pct: 20 } });
    assert.match(base.label, /ESTIMATE/);
    assert.ok(Math.abs(base.scenario.revenue - base.baseline.revenue * 1.2) < 1);
    const mat = await intel(OWNER, { action: 'scenario.run', business_id: bid, kind: 'material_cost', params: { cost_change_pct: 15 } });
    assert.ok(mat.scenario.net < mat.baseline.net);
    const jm = await intel(OWNER, { action: 'scenario.run', business_id: bid, kind: 'new_market', params: {}, save: true });
    assert.ok(jm.cash_requirement > 0 && jm.assumptions.length && jm.risks.some((r: string) => /consult/.test(r)));
    assert.ok(jm.scenario_id);
  });
  test('scenario refuses without financial basics; expansion gate can say not yet', async () => {
    const r = simulate({ business: {}, sales: [], orders: [], products: [], variants: [], customers: [], inventory: [], expenses: [], financials: [], campaigns: [], channels: [], events: [], eventResults: [], goals: [], tasks: [], locations: [] } as any, { kind: 'hire', params: {} }, NOW);
    assert.equal(r.ok, false);
    const { intel, bid } = await demo();
    const e = await intel(OWNER, { action: 'expansion.assess', business_id: bid });
    assert.ok(['not_yet', 'conditional', 'insufficient_data', 'ready_to_evaluate'].includes(e.verdict));
    if (e.verdict === 'not_yet') assert.match(e.message, /I would not recommend expanding yet/);
  });
});

describe('Workflows, approvals & governance', () => {
  test('low-stock workflow drafts POs, requires approval, prevents duplicates, never sends', async () => {
    const { m, api, intel, bid } = await demo();
    const r = await intel(OWNER, { action: 'workflow.run', business_id: bid, key: 'low_stock_purchase' });
    assert.equal(r.run.status, 'awaiting_approval'); assert.ok(r.approval);
    assert.ok(m.rows('PurchaseOrder').every((p) => p.status === 'pending_approval' && p.created_by_type === 'ai'));
    const again = await intel(OWNER, { action: 'workflow.run', business_id: bid, key: 'low_stock_purchase' });
    assert.equal(again.duplicate, true);
    const RO = { id: 'ro', email: 'ro@e.test' }; await addMember(m, bid, RO, 'read_only');
    await rejects(api(RO, { action: 'approval.decide', business_id: bid, id: r.approval.id, decision: 'approve' }), 403);
    const d = await api(OWNER, { action: 'approval.decide', business_id: bid, id: r.approval.id, decision: 'approve' });
    assert.equal(d.status, 'executed'); assert.match(d.result, /Nothing was sent/);
    assert.ok(m.rows('PurchaseOrder').every((p) => p.status === 'approved'));
    const ap = m.tables.ApprovalRequest.get(r.approval.id); assert.equal(ap.decided_by, OWNER.email); assert.ok(ap.decided_at);
    await rejects(api(OWNER, { action: 'approval.decide', business_id: bid, id: r.approval.id, decision: 'approve' }), 409);
  });
  test('customer follow-up only targets consenting contacts and requires approval to send', async () => {
    const { intel, bid, m } = await demo();
    const r = await intel(OWNER, { action: 'workflow.run', business_id: bid, key: 'customer_followup' });
    assert.ok(r.run.output.tasks >= 1);
    if (r.approval) assert.equal(r.approval.action_type, 'send_external_message');
    assert.ok(!m.rows('AuditLog').some((x) => /email sent/i.test(x.summary || '')));
  });
  test('deletes by non-owners become approval requests; price changes always need approval', async () => {
    const { m, api, bid } = await demo();
    const MGR = { id: 'mgr2', email: 'mgr2@e.test' }; await addMember(m, bid, MGR, 'admin');
    const prod = m.rows('Product').find((p) => p.business_id === bid);
    const del = await api(MGR, { action: 'delete', business_id: bid, entity: 'Product', id: prod.id });
    assert.equal(del.approval_required, true); assert.ok(m.tables.Product.get(prod.id), 'not deleted yet');
    const pr = await api(MGR, { action: 'price.request', business_id: bid, product_id: prod.id, new_price: 45 });
    assert.equal(m.tables.Product.get(prod.id).price, 42);
    await api(OWNER, { action: 'approval.decide', business_id: bid, id: pr.approval.id, decision: 'approve' });
    assert.equal(m.tables.Product.get(prod.id).price, 45);
  });
  test('integrations cannot be marked connected manually; test reports honestly', async () => {
    const { api, bid } = await demo();
    await rejects(api(OWNER, { action: 'create', business_id: bid, entity: 'Integration', data: { provider: 'Shopify', status: 'connected' } }), 422);
    const { item } = await api(OWNER, { action: 'create', business_id: bid, entity: 'Integration', data: { provider: 'Shopify', status: 'pending' } });
    const t = await api(OWNER, { action: 'integration.test', business_id: bid, id: item.id });
    assert.equal(t.ok, false); assert.equal(t.status, 'not_configured');
  });
  test('AI request cap blocks calls and is logged', async () => {
    const { m, api, intel, bid } = await demo();
    await api(OWNER, { action: 'settings.update', business_id: bid, data: { ai_monthly_request_cap: 1 } });
    await intel(OWNER, { action: 'review.weekly', business_id: bid });
    const r = await intel(OWNER, { action: 'review.weekly', business_id: bid });
    assert.equal(r.report.status, 'partial'); assert.match(r.report.content_md, /limit reached/);
    assert.ok(m.rows('AIUsageLog').some((x) => x.status === 'blocked_cap'));
    const u = await api(OWNER, { action: 'usage.summary', business_id: bid });
    assert.ok(u.requests >= 1 && /estimates/.test(u.note));
  });
  test('learning loop updates LearningStat and memory; admins can correct memory', async () => {
    const { m, api, intel, bid } = await demo();
    const na = await intel(OWNER, { action: 'nextActions', business_id: bid });
    const rec = na.this_week[0];
    await api(OWNER, { action: 'recommendation.decide', business_id: bid, id: rec.id, decision: 'approve' });
    await api(OWNER, { action: 'recommendation.outcome', business_id: bid, id: rec.id, outcome: 'worked', actual_result: 'No stock-out' });
    const ls = m.rows('LearningStat').find((x) => x.business_id === bid);
    assert.equal(ls.total, 1); assert.equal(ls.worked, 1);
    const mem = m.rows('ContextMemory').find((x) => x.business_id === bid && x.kind === 'recommendation_outcome');
    await api(OWNER, { action: 'memory.correct', business_id: bid, id: mem.id, op: 'correct', content: 'Corrected fact' });
    assert.equal(m.tables.ContextMemory.get(mem.id).status, 'corrected');
    const EMP = { id: 'e9', email: 'e9@e.test' }; await addMember(m, bid, EMP, 'employee');
    await rejects(api(EMP, { action: 'memory.correct', business_id: bid, id: mem.id, op: 'retract' }), 403);
  });
  test('reports include business, period, generation date, limitations; command center works', async () => {
    const { intel, bid } = await demo();
    for (const kind of ['financial_overview', 'inventory', 'risk', 'sales', 'manufacturing', 'briefing']) {
      const { report } = await intel(OWNER, { action: 'report.generate', business_id: bid, kind });
      assert.ok(report.title.includes('Sample Cosmetics') && report.period_start && report.generated_at && Array.isArray(report.data_limitations));
      assert.match(report.content_md, /not an audited financial statement/);
    }
    const c = await intel(OWNER, { action: 'command', business_id: bid });
    assert.ok(c.health && Array.isArray(c.alerts) && c.forecast.revenue);
  });
  test('tenant isolation holds for Prompt 2 endpoints', async () => {
    const { m, api, intel, bid } = await demo();
    const X = { id: 'x', email: 'x@other.test' };
    const { business: other } = await api(X, { action: 'createBusiness', data: { name: 'Other Co' } });
    await rejects(intel(X, { action: 'command', business_id: bid }), 403);
    await rejects(intel(X, { action: 'forecast', business_id: bid }), 403);
    const al = m.rows('Alert').find((a) => a.business_id === bid) || (await intel(OWNER, { action: 'monitor.run', business_id: bid }), m.rows('Alert').find((a) => a.business_id === bid));
    await rejects(api(X, { action: 'alert.update', business_id: other.id, id: al.id, op: 'close' }), 404);
  });
});
