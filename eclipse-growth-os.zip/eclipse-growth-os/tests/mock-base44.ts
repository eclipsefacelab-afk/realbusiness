// In-memory stand-in for the Base44 SDK (entities, auth, InvokeLLM) used by automated tests.
let seq = 0;
export function createMockBase44() {
  const tables: Record<string, Map<string, any>> = {};
  const table = (n: string) => (tables[n] ||= new Map());
  const llmCalls: any[] = [];
  let llmImpl: (p: any) => any = () => ({ summary: 'ok' });
  let currentUser: any = null;

  const match = (rec: any, q: any) => Object.entries(q || {}).every(([k, v]) => rec[k] === v);
  const sorter = (sort?: string) => (a: any, b: any) => {
    if (!sort) return 0;
    const desc = sort.startsWith('-'); const k = desc ? sort.slice(1) : sort;
    const x = a[k] ?? '', y = b[k] ?? '';
    return (x > y ? 1 : x < y ? -1 : 0) * (desc ? -1 : 1);
  };
  const entityApi = (name: string) => ({
    async filter(q: any, sort?: string, limit = 5000) { return [...table(name).values()].filter((r) => match(r, q)).sort(sorter(sort)).slice(0, limit).map((r) => ({ ...r })); },
    async list(sort?: string, limit = 5000) { return this.filter({}, sort, limit); },
    async get(id: string) { const r = table(name).get(id); if (!r) { const e: any = new Error('Not found'); e.status = 404; throw e; } return { ...r }; },
    async create(data: any) { const id = `${name.toLowerCase()}_${++seq}`; const now = new Date().toISOString(); const r = { ...data, id, created_date: now, updated_date: now, created_by: currentUser?.email || 'service' }; table(name).set(id, r); return { ...r }; },
    async bulkCreate(rows: any[]) { const out = []; for (const r of rows) out.push(await this.create(r)); return out; },
    async update(id: string, data: any) { const r = table(name).get(id); if (!r) throw new Error('Not found'); const u = { ...r, ...data, updated_date: new Date().toISOString() }; table(name).set(id, u); return { ...u }; },
    async delete(id: string) { table(name).delete(id); return { ok: true }; },
  });
  const entities = new Proxy({}, { get: (_t, name: string) => entityApi(name) });
  const integrations = { Core: { InvokeLLM: async (p: any) => { llmCalls.push(p); return llmImpl(p); } } };
  const svc = { entities, integrations };
  const client = { auth: { me: async () => { if (!currentUser) throw new Error('unauthenticated'); return currentUser; } }, entities, integrations, asServiceRole: svc };
  return {
    client, svc, tables, llmCalls,
    setUser: (u: any) => { currentUser = u; },
    setLLM: (fn: (p: any) => any) => { llmImpl = fn; },
    rows: (n: string) => [...table(n).values()],
  };
}
